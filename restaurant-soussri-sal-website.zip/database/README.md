# 🗄️ /database — La base de données du site

Ce dossier **est** la base de données du projet. Il contient les tables de
contenu au format **JSON**, plus le schéma **SQL** de référence.

```
database/
├── restaurant.json     Fiche établissement (adresse, horaires, réseaux, stats)
├── categories.json     Catégories du menu
├── dishes.json         La carte — 28 plats
├── testimonials.json   Avis clients
├── gallery.json        Photos de la galerie
├── team.json           Équipe du restaurant
├── schema.sql          Schéma relationnel (documentation + future migration)
└── README.md           Ce fichier
```

---

## Comment ça fonctionne

```
  /database/*.json          js/db.js                  Navigateur
 ┌──────────────┐      ┌──────────────────┐      ┌──────────────────┐
 │  Tables JSON │ ───► │ Chargement fetch │ ───► │    IndexedDB     │
 │ (le dépôt)   │      │  + amorçage      │      │  « soussri_db »  │
 └──────────────┘      └──────────────────┘      └────────┬─────────┘
                                                          │
        js/data.js  ◄── repli si fetch indisponible       ▼
                                              Site public + panneau admin
```

1. **Au premier chargement**, `js/db.js` télécharge les fichiers de ce dossier
   avec `fetch()` et les insère dans **IndexedDB** (la base native du
   navigateur).
2. **Ensuite**, tout est lu depuis IndexedDB : instantané et hors ligne.
3. Les données créées par les visiteurs (réservations, comptes, favoris,
   messages) vivent uniquement dans IndexedDB — elles ne touchent jamais
   ces fichiers, qui restent en lecture seule.

### Repli automatique

Si `fetch()` échoue — notamment en ouvrant `index.html` par **double-clic**
(protocole `file://`, bloqué par les navigateurs) — la base s'amorce à partir
de **`js/data.js`**, qui contient une copie des mêmes données. **Le site
fonctionne donc dans tous les cas.**

> 💡 Pour utiliser réellement les fichiers de ce dossier en local, servez le
> projet avec un petit serveur statique (extension « Live Server » de VS Code,
> ou toute autre solution). Sur **GitHub Pages, ça marche directement.**

---

## 📱 Numéro WhatsApp des réservations

Les demandes de réservation sont transmises sur le WhatsApp du restaurant,
défini dans **`restaurant.json`** :

```json
"whatsapp": "212672297256",
"whatsappDisplay": "+212 672-297256",
"bookingsToWhatsApp": true
```

| Clé | Rôle |
|---|---|
| `whatsapp` | Numéro au **format international, sans `+` ni espaces** (requis par `wa.me`) |
| `whatsappDisplay` | Version lisible affichée sur le site |
| `bookingsToWhatsApp` | `false` désactive l'ouverture automatique de WhatsApp |

> ⚠️ Après modification, incrémentez `SEED_VERSION` dans `js/db.js` (ou cliquez
> sur « Recharger depuis /database/ » dans l'admin) pour que les navigateurs
> ayant déjà la base en cache récupèrent le nouveau numéro.

---

## Modifier le contenu du site

### Ajouter un plat

Ouvrez `dishes.json` et ajoutez un objet dans `rows` :

```json
{
  "id": "t6",
  "cat": "tajines",
  "name": "Tajine de poulpe à la chermoula",
  "desc": "Poulpe fondant mijoté à la coriandre, citron confit et olives.",
  "price": 155,
  "tags": ["Nouveauté", "Océan"],
  "rating": 4.8,
  "spicy": 1,
  "available": true,
  "img": "images/tajine-poulpe.jpg"
}
```

Puis, dans le panneau d'administration → onglet **Données** →
**« Recharger depuis /database/ »**. (Ou videz les données du site dans les
outils de développement du navigateur.)

### Champs de la table `dishes`

| Champ | Type | Obligatoire | Description |
|---|---|:---:|---|
| `id` | texte | ✅ | Clé primaire unique (`t6`, `d4`…) |
| `cat` | texte | ✅ | Référence vers `categories.json` → `id` |
| `name` | texte | ✅ | Nom affiché du plat |
| `desc` | texte | ✅ | Description sur la carte |
| `price` | nombre | ✅ | Prix en MAD |
| `rating` | nombre | — | Note de 0 à 5 (défaut 5) |
| `spicy` | entier | — | Piment de 0 à 3 |
| `tags` | tableau | — | Étiquettes (`"Signature"`, `"Végan"`…) |
| `img` | texte | — | URL ou chemin local (`images/mon-plat.jpg`) |
| `available` | booléen | — | `false` masque le plat du site |

---

## Le fichier `schema.sql`

Il **n'est pas exécuté** par le site : celui-ci est 100 % statique et n'a aucun
serveur. Il sert à :

- **documenter** précisément les types, clés primaires, clés étrangères,
  index et contraintes de chaque table ;
- **migrer** un jour vers MySQL / MariaDB / PostgreSQL sans repenser le modèle.

Il contient 11 tables (`restaurant`, `categories`, `dishes`, `users`,
`reservations`, `favorites`, `messages`, `testimonials`, `gallery`, `team`,
`settings`) et 3 vues (`v_menu_public`, `v_dashboard`, `v_upcoming_week`) qui
reproduisent en SQL ce que fait `SoussriDB.stats()`.

Le jour où vous ajoutez un backend, il suffira de remplacer les appels
`SoussriDB.*` par des `fetch('/api/…')` : la forme des données est identique.

---

## Sauvegarder et restaurer

Depuis le panneau d'administration → onglet **Données** :

- **Exporter la base (JSON)** — télécharge la totalité des collections,
  y compris les réservations et comptes clients.
- **Importer un fichier** — restaure une sauvegarde, ou transfère les données
  vers un autre appareil ou navigateur.
- **Réinitialiser** — efface tout et ré-amorce depuis ce dossier.

En console :

```js
await SoussriDB.ready();
SoussriDB.source;                  // "/database/*.json" ou "data.js"
await SoussriDB.reloadFromFiles(); // relit ce dossier
SoussriDB.exportJSON();            // sauvegarde complète
```
