-- ============================================================================
--  Restaurant Soussri Salé — schema.sql
-- ----------------------------------------------------------------------------
--  Schéma relationnel de référence de la base « soussri_db ».
--
--  ⚠️ Ce fichier N'EST PAS exécuté par le site.
--     Le site est 100 % statique : il fonctionne avec IndexedDB dans le
--     navigateur (voir js/db.js) et les tables JSON de ce dossier.
--
--  Ce schéma sert à deux choses :
--     1. Documenter la structure exacte des données (types, clés, contraintes)
--     2. Permettre une MIGRATION ULTÉRIEURE vers un vrai serveur
--        (MySQL / MariaDB / PostgreSQL) sans rien réécrire du modèle.
--
--  Compatible MySQL 8+ / MariaDB 10.4+. Pour PostgreSQL :
--     AUTO_INCREMENT -> GENERATED ALWAYS AS IDENTITY, TINYINT(1) -> BOOLEAN,
--     JSON reste JSON (ou JSONB), supprimer les ENGINE=/CHARSET=.
-- ============================================================================

SET NAMES utf8mb4;
SET time_zone = '+01:00';   -- Heure du Maroc

CREATE DATABASE IF NOT EXISTS soussri_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;
USE soussri_db;

-- ============================================================================
--  1. restaurant — fiche de l'établissement (une seule ligne)
-- ============================================================================
CREATE TABLE IF NOT EXISTS restaurant (
  id            TINYINT UNSIGNED  NOT NULL DEFAULT 1,
  name          VARCHAR(120)      NOT NULL,
  tagline       VARCHAR(200)          NULL,
  since         SMALLINT UNSIGNED     NULL,
  address       VARCHAR(255)      NOT NULL,
  city          VARCHAR(80)       NOT NULL,
  postal_code   VARCHAR(12)           NULL,
  country       CHAR(2)           NOT NULL DEFAULT 'MA',
  latitude      DECIMAL(9,6)          NULL,
  longitude     DECIMAL(9,6)          NULL,
  phone         VARCHAR(30)       NOT NULL,
  whatsapp      VARCHAR(20)           NULL,
  email         VARCHAR(160)      NOT NULL,
  price_range   VARCHAR(6)            NULL DEFAULT '$$',
  capacity      SMALLINT UNSIGNED     NULL,
  currency      CHAR(3)           NOT NULL DEFAULT 'MAD',
  maps_embed    TEXT                  NULL,
  social        JSON                  NULL,  -- [{name,url,icon}]
  hours         JSON                  NULL,  -- [{day,time}]
  updated_at    TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP
                                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_single_row CHECK (id = 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  2. categories — catégories du menu
-- ============================================================================
CREATE TABLE IF NOT EXISTS categories (
  id        VARCHAR(40)       NOT NULL,
  label     VARCHAR(80)       NOT NULL,
  icon      VARCHAR(16)           NULL,
  position  TINYINT UNSIGNED  NOT NULL DEFAULT 0,
  active    TINYINT(1)        NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  KEY idx_categories_position (position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  3. dishes — la carte
-- ============================================================================
CREATE TABLE IF NOT EXISTS dishes (
  id           VARCHAR(40)       NOT NULL,
  cat          VARCHAR(40)       NOT NULL,
  name         VARCHAR(140)      NOT NULL,
  description  TEXT              NOT NULL,
  price        DECIMAL(8,2)      NOT NULL,
  rating       DECIMAL(2,1)      NOT NULL DEFAULT 5.0,
  spicy        TINYINT UNSIGNED  NOT NULL DEFAULT 0,
  tags         JSON                  NULL,   -- ["Signature","Végan"]
  img          VARCHAR(500)          NULL,
  available    TINYINT(1)        NOT NULL DEFAULT 1,
  created_at   TIMESTAMP         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_dishes_cat   (cat),
  KEY idx_dishes_price (price),
  KEY idx_dishes_name  (name),
  CONSTRAINT fk_dishes_cat FOREIGN KEY (cat) REFERENCES categories (id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_dishes_price  CHECK (price >= 0),
  CONSTRAINT chk_dishes_rating CHECK (rating BETWEEN 0 AND 5),
  CONSTRAINT chk_dishes_spicy  CHECK (spicy BETWEEN 0 AND 3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  4. users — comptes clients
--     (le site de démonstration hache le mot de passe en djb2 ; côté serveur
--      utilisez impérativement bcrypt / argon2)
-- ============================================================================
CREATE TABLE IF NOT EXISTS users (
  email       VARCHAR(160)  NOT NULL,
  name        VARCHAR(120)  NOT NULL,
  pass_hash   VARCHAR(255)  NOT NULL,
  phone       VARCHAR(30)       NULL,
  role        ENUM('client','staff','admin') NOT NULL DEFAULT 'client',
  since       TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_login  TIMESTAMP         NULL,
  PRIMARY KEY (email),
  KEY idx_users_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  5. reservations — réservations de tables
-- ============================================================================
CREATE TABLE IF NOT EXISTS reservations (
  ref        VARCHAR(20)   NOT NULL,          -- ex. SSR-A1B2C
  name       VARCHAR(120)  NOT NULL,
  phone      VARCHAR(30)   NOT NULL,
  email      VARCHAR(160)  NOT NULL,
  res_date   DATE          NOT NULL,
  res_time   TIME          NOT NULL,
  guests     VARCHAR(10)   NOT NULL,          -- '1'..'10' ou '12+'
  area       VARCHAR(60)       NULL,          -- Salle, Patio, Terrasse, Salon privé
  notes      TEXT              NULL,
  status     ENUM('confirmed','pending','cancelled') NOT NULL DEFAULT 'confirmed',
  source     VARCHAR(20)   NOT NULL DEFAULT 'site',
  user_email VARCHAR(160)      NULL,
  created_at TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (ref),
  KEY idx_res_date   (res_date),
  KEY idx_res_status (status),
  KEY idx_res_email  (email),
  CONSTRAINT fk_res_user FOREIGN KEY (user_email) REFERENCES users (email)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  6. favorites — plats favoris (relation N-N users <-> dishes)
-- ============================================================================
CREATE TABLE IF NOT EXISTS favorites (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  dish_id    VARCHAR(40)     NOT NULL,
  user_email VARCHAR(160)        NULL,        -- NULL = favori d'appareil (anonyme)
  device_id  VARCHAR(64)         NULL,
  added_at   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_fav (dish_id, user_email, device_id),
  CONSTRAINT fk_fav_dish FOREIGN KEY (dish_id) REFERENCES dishes (id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_fav_user FOREIGN KEY (user_email) REFERENCES users (email)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  7. messages — formulaire de contact
-- ============================================================================
CREATE TABLE IF NOT EXISTS messages (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name       VARCHAR(120)    NOT NULL,
  email      VARCHAR(160)    NOT NULL,
  message    TEXT            NOT NULL,
  is_read    TINYINT(1)      NOT NULL DEFAULT 0,
  created_at TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_msg_read (is_read),
  KEY idx_msg_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  8. testimonials — avis clients
-- ============================================================================
CREATE TABLE IF NOT EXISTS testimonials (
  id        VARCHAR(40)      NOT NULL,
  name      VARCHAR(120)     NOT NULL,
  role      VARCHAR(120)         NULL,
  initials  VARCHAR(4)           NULL,
  stars     TINYINT UNSIGNED NOT NULL DEFAULT 5,
  body      TEXT             NOT NULL,
  published TINYINT(1)       NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  CONSTRAINT chk_stars CHECK (stars BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  9. gallery — photos
-- ============================================================================
CREATE TABLE IF NOT EXISTS gallery (
  id       VARCHAR(40)      NOT NULL,
  src      VARCHAR(500)     NOT NULL,
  alt      VARCHAR(255)     NOT NULL,
  caption  VARCHAR(120)         NULL,
  size     ENUM('','wide','tall') NOT NULL DEFAULT '',
  position TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- 10. team — équipe
-- ============================================================================
CREATE TABLE IF NOT EXISTS team (
  id       VARCHAR(40)      NOT NULL,
  name     VARCHAR(120)     NOT NULL,
  role     VARCHAR(120)         NULL,
  bio      TEXT                 NULL,
  img      VARCHAR(500)         NULL,
  position TINYINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
-- 11. settings — préférences clé/valeur (thème, session, code admin…)
-- ============================================================================
CREATE TABLE IF NOT EXISTS settings (
  setting_key   VARCHAR(60) NOT NULL,
  setting_value JSON            NULL,
  updated_at    TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP
                            ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================================
--  VUES UTILES (équivalent SQL de SoussriDB.stats())
-- ============================================================================
CREATE OR REPLACE VIEW v_menu_public AS
  SELECT d.id, d.name, d.description, d.price, d.rating, d.spicy, d.tags, d.img,
         c.label AS category_label, c.position AS category_position
  FROM dishes d
  JOIN categories c ON c.id = d.cat
  WHERE d.available = 1 AND c.active = 1
  ORDER BY c.position, d.name;

CREATE OR REPLACE VIEW v_dashboard AS
  SELECT
    (SELECT COUNT(*) FROM dishes)                                        AS total_dishes,
    (SELECT COUNT(*) FROM dishes WHERE available = 1)                    AS available_dishes,
    (SELECT ROUND(AVG(price)) FROM dishes)                               AS avg_price,
    (SELECT COUNT(*) FROM reservations)                                  AS total_reservations,
    (SELECT COUNT(*) FROM reservations WHERE res_date = CURDATE())       AS today_reservations,
    (SELECT COUNT(*) FROM reservations WHERE status = 'confirmed')       AS confirmed,
    (SELECT COUNT(*) FROM reservations WHERE status = 'pending')         AS pending,
    (SELECT COUNT(*) FROM reservations WHERE status = 'cancelled')       AS cancelled,
    (SELECT COUNT(*) FROM users)                                         AS total_users,
    (SELECT COUNT(*) FROM messages WHERE is_read = 0)                    AS unread_messages;

CREATE OR REPLACE VIEW v_upcoming_week AS
  SELECT res_date, COUNT(*) AS bookings, SUM(CAST(guests AS UNSIGNED)) AS covers
  FROM reservations
  WHERE status <> 'cancelled'
    AND res_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
  GROUP BY res_date
  ORDER BY res_date;

-- ============================================================================
--  DONNÉES D'AMORÇAGE (extrait — la carte complète est dans dishes.json)
-- ============================================================================
INSERT INTO categories (id, label, icon, position) VALUES
  ('entrees',  'Entrées & Salades', '🥣', 1),
  ('tajines',  'Tajines',           '🍲', 2),
  ('couscous', 'Couscous',          '🌾', 3),
  ('grillades','Grillades',         '🔥', 4),
  ('mer',      'Fruits de mer',     '🐟', 5),
  ('desserts', 'Desserts',          '🍯', 6),
  ('boissons', 'Boissons',          '🫖', 7)
ON DUPLICATE KEY UPDATE label = VALUES(label);

INSERT INTO dishes (id, cat, name, description, price, rating, spicy, tags, img) VALUES
  ('t1', 'tajines', 'Tajine d''agneau aux pruneaux',
   'Épaule d''agneau confite 5 heures, pruneaux, amandes grillées, œufs et sésame.',
   145.00, 5.0, 0, '["Signature","Best-seller"]',
   'https://images.pexels.com/photos/30068445/pexels-photo-30068445.jpeg'),
  ('c1', 'couscous', 'Couscous sept légumes',
   'Semoule roulée à la main, bouillon safrané et sept légumes du jour.',
   115.00, 4.9, 0, '["Vendredi","Végétarien"]',
   'https://images.pexels.com/photos/19162223/pexels-photo-19162223.jpeg')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Fin du schéma.
