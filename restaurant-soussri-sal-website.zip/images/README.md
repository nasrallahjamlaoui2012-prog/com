# /images

This folder is reserved for **local image assets**.

## Current setup

To keep the repository lightweight and the site fast, all photographs
(dishes, interiors, gallery, team) are loaded from the **Pexels CDN** with
`loading="lazy"`, `decoding="async"` and responsive sizing parameters
(`?auto=compress&cs=tinysrgb&fit=crop&w=…&h=…`).

The URLs are centralised in **`/js/data.js`** — nowhere else.

## Using your own photos instead

1. Drop your HD photos here, e.g. `images/tajine-agneau.jpg`.
2. Open `/js/data.js`.
3. Replace the remote URL with the relative path:

```js
img: 'images/tajine-agneau.jpg'
```

That's it — no build step, no configuration.

## Recommendations

| Usage            | Suggested size   | Format          |
|------------------|------------------|-----------------|
| Hero slides      | 1920 × 1100 px   | `.webp` / `.jpg`|
| Dish cards       | 800 × 550 px     | `.webp`         |
| Gallery (wide)   | 1400 × 900 px    | `.webp`         |
| Gallery (tall)   | 900 × 1200 px    | `.webp`         |
| Team portraits   | 400 × 400 px     | `.webp`         |

Keep files under ~250 KB and always fill the `alt` attribute (WCAG 1.1.1).

`placeholder.svg` is a local fallback illustration used when a remote image
cannot be reached.
