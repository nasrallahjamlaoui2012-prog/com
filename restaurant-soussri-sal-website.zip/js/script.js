/* ==========================================================================
   Restaurant Soussri Salé — script.js
   Vanilla JavaScript only. No dependency, no build step, no backend.
   --------------------------------------------------------------------------
   Toute la persistance passe désormais par la BASE DE DONNÉES locale
   définie dans js/db.js (IndexedDB, repli LocalStorage) :

     settings.theme      -> "light" | "dark"
     settings.session    -> e-mail du compte connecté
     settings.newsletter -> inscriptions à la lettre d'information
     favorites           -> plats favoris de l'appareil
     reservations        -> réservations (avec statut géré par l'admin)
     users               -> comptes clients (mot de passe haché)
     messages            -> messages du formulaire de contact

   L'application démarre uniquement lorsque la base est ouverte (voir le
   bloc « boot » en fin de fichier).
   ========================================================================== */
function startSoussriApp() {
  'use strict';

  /* Les données proviennent désormais de la BASE DE DONNÉES locale (js/db.js).
     `DB.data` est une vue vivante : toute modification faite dans le panneau
     d'administration se répercute au prochain rendu. */
  const DB = window.SoussriDB;
  const D = DB.data;
  const $ = (sel, ctx) => (ctx || document).querySelector(sel);
  const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));
  const REDUCED = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ======================================================================
     0. LocalStorage helpers (safe against private-mode / quota errors)
     ====================================================================== */
  /* Adaptateur branché sur la base de données.
     L'API reste identique (get / set / del) mais les données sont écrites
     dans les collections IndexedDB au lieu de clés LocalStorage brutes :
        theme, session, newsletter -> table « settings »
        favorites                  -> table « favorites »
        bookings                   -> table « reservations »
        users                      -> table « users »
        messages                   -> table « messages »          */
  const store = DB.legacyStore;

  /* ======================================================================
     1. Toast notifications
     ====================================================================== */
  const toastBox = $('#toasts');
  function toast(msg, type) {
    const el = document.createElement('div');
    el.className = 'toast ' + (type || '');
    el.setAttribute('role', 'status');
    el.innerHTML = '<span class="dot"></span><span></span>';
    el.lastElementChild.textContent = msg;
    toastBox.appendChild(el);
    setTimeout(() => {
      el.classList.add('out');
      el.addEventListener('animationend', () => el.remove(), { once: true });
    }, 3600);
  }

  /* ======================================================================
     2. Preloader
     ====================================================================== */
  function hidePreloader() {
    const p = $('#preloader');
    if (!p) return;
    p.classList.add('done');
    setTimeout(() => p.remove(), 700);
  }
  window.addEventListener('load', () => setTimeout(hidePreloader, 350));
  // Fail-safe: never block the page for more than 3.5s
  setTimeout(hidePreloader, 3500);

  /* ======================================================================
     3. Theme (dark / light) — respects OS preference on first visit
     ====================================================================== */
  const themeBtn = $('#themeBtn');
  function applyTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    themeBtn.setAttribute('aria-label', t === 'dark' ? 'Activer le mode clair' : 'Activer le mode sombre');
  }
  const savedTheme = store.get('theme', null);
  applyTheme(savedTheme || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  themeBtn.addEventListener('click', () => {
    const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    applyTheme(next); store.set('theme', next);
    toast(next === 'dark' ? 'Mode sombre activé 🌙' : 'Mode clair activé ☀️');
  });

  /* ======================================================================
     4. Header: scroll state, progress bar, active link, back-to-top
     ====================================================================== */
  const header = $('#header');
  const progress = $('#progress');
  const topBtn = $('#topBtn');
  const sections = $$('main section[id]');
  const navLinks = $$('.nav__link');

  let ticking = false;
  function onScroll() {
    const y = window.scrollY;
    const docH = document.documentElement.scrollHeight - window.innerHeight;
    header.classList.toggle('scrolled', y > 60);
    progress.style.width = (docH > 0 ? (y / docH) * 100 : 0) + '%';
    topBtn.classList.toggle('show', y > 600);

    // active nav link
    let current = sections[0] ? sections[0].id : '';
    sections.forEach(s => { if (y >= s.offsetTop - 140) current = s.id; });
    navLinks.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + current));
    ticking = false;
  }
  window.addEventListener('scroll', () => {
    if (!ticking) { ticking = true; requestAnimationFrame(onScroll); }
  }, { passive: true });
  onScroll();

  topBtn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: REDUCED ? 'auto' : 'smooth' }));

  /* ======================================================================
     5. Mobile navigation drawer
     ====================================================================== */
  const burger = $('#burger');
  const mobileNav = $('#mobileNav');
  function setMenu(open) {
    burger.setAttribute('aria-expanded', String(open));
    burger.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu');
    mobileNav.classList.toggle('open', open);
    document.body.classList.toggle('is-locked', open);
    if (open) $$('a', mobileNav).forEach((a, i) => { a.style.animationDelay = (0.05 + i * 0.05) + 's'; });
  }
  burger.addEventListener('click', () => setMenu(burger.getAttribute('aria-expanded') !== 'true'));
  $$('a, button', mobileNav).forEach(el => el.addEventListener('click', () => setMenu(false)));
  window.addEventListener('resize', () => { if (window.innerWidth >= 1024) setMenu(false); });

  /* ======================================================================
     6. Hero: background slideshow + dots + floating particles
     ====================================================================== */
  const heroBg = $('#heroBg');
  const heroDots = $('#heroDots');
  let heroIndex = 0, heroTimer = null;

  D.HERO_SLIDES.forEach((src, i) => {
    const s = document.createElement('div');
    s.className = 'hero__slide' + (i === 0 ? ' active' : '');
    s.style.backgroundImage = 'url("' + src + '")';
    heroBg.appendChild(s);

    const b = document.createElement('button');
    b.type = 'button';
    b.setAttribute('aria-label', 'Afficher l\'image ' + (i + 1));
    b.setAttribute('aria-current', i === 0 ? 'true' : 'false');
    b.addEventListener('click', () => { goHero(i); resetHero(); });
    heroDots.appendChild(b);
    // Preload the following slides quietly
    if (i > 0) { const im = new Image(); im.src = src; }
  });

  function goHero(i) {
    const slides = $$('.hero__slide', heroBg);
    const dots = $$('button', heroDots);
    slides[heroIndex].classList.remove('active');
    dots[heroIndex].setAttribute('aria-current', 'false');
    heroIndex = (i + slides.length) % slides.length;
    slides[heroIndex].classList.add('active');
    dots[heroIndex].setAttribute('aria-current', 'true');
  }
  function resetHero() {
    clearInterval(heroTimer);
    if (!REDUCED) heroTimer = setInterval(() => goHero(heroIndex + 1), 7000);
  }
  resetHero();

  // Particles (spice dust rising)
  if (!REDUCED) {
    const pBox = $('#particles');
    const count = window.innerWidth < 700 ? 14 : 26;
    for (let i = 0; i < count; i++) {
      const p = document.createElement('span');
      p.className = 'particle';
      const size = 3 + Math.random() * 7;
      p.style.cssText =
        'left:' + (Math.random() * 100) + '%;' +
        'width:' + size + 'px;height:' + size + 'px;' +
        '--dx:' + (Math.random() * 160 - 80) + 'px;' +
        'animation-duration:' + (11 + Math.random() * 16) + 's;' +
        'animation-delay:-' + (Math.random() * 22) + 's;';
      pBox.appendChild(p);
    }
  }

  /* ======================================================================
     7. Marquee strip
     ====================================================================== */
  const marqueeItems = ['Spécialité poisson', 'Friture merlan · sole · crevette · calamar', 'Grillades au charbon',
    'Tajine de poisson à la chermoula', 'Arrivage quotidien du port', 'Plats à emporter', 'Depuis 1998 à Salé'];
  const mq = $('#marquee');
  const mqHtml = marqueeItems.map(t => '<span>' + t + '</span>').join('');
  mq.innerHTML = mqHtml + mqHtml; // duplicated for a seamless loop

  /* ======================================================================
     8. Scroll reveal (IntersectionObserver)
     ====================================================================== */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.12, rootMargin: '0px 0px -60px' });
  function observeReveals() { $$('.reveal:not(.in)').forEach(el => io.observe(el)); }
  observeReveals();

  /* ======================================================================
     9. Animated stat counters
     ====================================================================== */
  const statsEl = $('#stats');
  statsEl.innerHTML = D.STATS.map(s =>
    '<li class="stat"><b data-to="' + s.value + '" data-suffix="' + s.suffix + '" data-dec="' + (s.decimal ? 1 : 0) + '">0</b><span>' + s.label + '</span></li>'
  ).join('');

  const statObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      statObserver.unobserve(e.target);
      $$('b', e.target).forEach(el => {
        const to = parseFloat(el.dataset.to), dec = el.dataset.dec === '1', suffix = el.dataset.suffix || '';
        const dur = REDUCED ? 0 : 1500; const t0 = performance.now();
        (function step(now) {
          const k = dur ? Math.min((now - t0) / dur, 1) : 1;
          const eased = 1 - Math.pow(1 - k, 3);
          const val = to * eased;
          el.textContent = (dec ? (val / 10).toFixed(1) : Math.round(val)) + suffix;
          if (k < 1) requestAnimationFrame(step);
        })(t0);
      });
    });
  }, { threshold: 0.4 });
  statObserver.observe(statsEl);

  /* ======================================================================
     10. Team
     ====================================================================== */
  $('#team').innerHTML = D.TEAM.map((m, i) =>
    '<article class="team__card reveal" data-delay="' + (i + 1) + '">' +
      '<img src="' + m.img + '" alt="Portrait de ' + m.name + '" width="130" height="130" loading="lazy" decoding="async">' +
      '<h3>' + m.name + '</h3><p class="role">' + m.role + '</p><p>' + m.bio + '</p>' +
    '</article>'
  ).join('');
  observeReveals();

  /* ======================================================================
     11. Favorites (LocalStorage)
     ====================================================================== */
  let favorites = store.get('favorites', []);
  const favBadge = $('#favBadge');

  function syncFavBadge() {
    favBadge.textContent = favorites.length;
    favBadge.classList.toggle('show', favorites.length > 0);
  }
  function toggleFavorite(id) {
    const i = favorites.indexOf(id);
    if (i > -1) { favorites.splice(i, 1); toast('Retiré des favoris'); }
    else { favorites.push(id); toast('Ajouté à vos favoris ❤️', 'ok'); }
    store.set('favorites', favorites);
    syncFavBadge();
    $$('.fav[data-id="' + id + '"]').forEach(b => b.setAttribute('aria-pressed', String(favorites.includes(id))));
    renderFavModal();
    refreshAccountStats();
  }
  syncFavBadge();

  /* ======================================================================
     12. Menu: categories, rendering, live search
     ====================================================================== */
  const catsEl = $('#cats');
  const gridEl = $('#menuGrid');
  const searchEl = $('#menuSearch');
  const searchClear = $('#searchClear');
  let activeCat = 'all';

  catsEl.innerHTML = D.CATEGORIES.map(c =>
    '<button class="cat" role="tab" type="button" data-cat="' + c.id + '" aria-selected="' + (c.id === 'all') + '">' +
    '<span aria-hidden="true">' + c.icon + '</span>' + c.label + '</button>'
  ).join('');

  const heartSvg = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.6 1.1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>';

  function dishCard(d, i) {
    const isFav = favorites.includes(d.id);
    const tags = d.tags.map(t => '<span class="chip">' + t + '</span>').join('');
    const spicy = d.spicy ? '<span class="spicy" title="Niveau de piment">' + '🌶'.repeat(d.spicy) + '</span>' : '';
    return '<article class="dish" style="animation-delay:' + Math.min(i * 45, 400) + 'ms">' +
      '<div class="dish__media">' +
        '<img src="' + d.img + '" alt="' + d.name + '" width="600" height="412" loading="lazy" decoding="async">' +
        '<span class="dish__price">' + d.price + ' DH</span>' +
        '<button class="fav" type="button" data-id="' + d.id + '" aria-pressed="' + isFav + '" ' +
          'aria-label="' + (isFav ? 'Retirer' : 'Ajouter') + ' ' + d.name + ' des favoris">' + heartSvg + '</button>' +
      '</div>' +
      '<div class="dish__body">' +
        '<div class="dish__top">' +
          '<div><h3>' + d.name + '</h3>' +
            // Nom arabe tel qu'il figure sur la carte du restaurant
            (d.nameAr ? '<p class="dish__ar" lang="ar" dir="rtl">' + d.nameAr + '</p>' : '') +
          '</div>' +
          '<span class="dish__rate" aria-label="Note ' + d.rating + ' sur 5">★ ' + d.rating.toFixed(1) + '</span></div>' +
        '<p class="dish__desc">' + d.desc + '</p>' +
        '<div class="dish__tags">' + tags + spicy + '</div>' +
      '</div></article>';
  }

  function renderMenu() {
    const q = searchEl.value.trim().toLowerCase();
    const list = D.MENU.filter(d => {
      const okCat = activeCat === 'all' || d.cat === activeCat;
      // La recherche couvre aussi le nom arabe figurant sur la carte
      const hay = (d.name + ' ' + (d.nameAr || '') + ' ' + d.desc + ' ' + d.tags.join(' ')).toLowerCase();
      const okQ = !q || hay.includes(q);
      return okCat && okQ;
    });
    gridEl.innerHTML = list.length
      ? list.map(dishCard).join('')
      : '<div class="empty"><b>Aucun plat trouvé</b><p>Essayez « friture », « calamar », « tajine » ou « salade ».</p></div>';
    searchClear.classList.toggle('show', q.length > 0);
  }

  catsEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.cat'); if (!btn) return;
    activeCat = btn.dataset.cat;
    $$('.cat', catsEl).forEach(b => b.setAttribute('aria-selected', String(b === btn)));
    renderMenu();
  });

  let searchTimer;
  searchEl.addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(renderMenu, 160); });
  searchClear.addEventListener('click', () => { searchEl.value = ''; renderMenu(); searchEl.focus(); });

  gridEl.addEventListener('click', (e) => {
    const b = e.target.closest('.fav'); if (b) toggleFavorite(b.dataset.id);
  });

  renderMenu();

  /* ======================================================================
     13. Favorites modal
     ====================================================================== */
  const favList = $('#favList');
  function renderFavModal() {
    if (!favorites.length) {
      favList.innerHTML = '<div class="empty"><b>Aucun favori pour l\'instant</b><p>Touchez le cœur sur un plat de la carte pour l\'enregistrer ici.</p></div>';
      return;
    }
    favList.innerHTML = favorites.map(id => {
      const d = D.MENU.find(x => x.id === id); if (!d) return '';
      return '<div class="fav-row">' +
        '<img src="' + d.img + '" alt="" loading="lazy" width="62" height="56">' +
        '<div class="meta"><b>' + d.name + '</b><small>' + d.price + ' DH</small></div>' +
        '<button class="btn btn--ghost btn--sm" type="button" data-unfav="' + d.id + '">Retirer</button>' +
      '</div>';
    }).join('');
  }
  favList.addEventListener('click', (e) => {
    const b = e.target.closest('[data-unfav]'); if (b) toggleFavorite(b.dataset.unfav);
  });
  renderFavModal();

  /* ======================================================================
     14. Gallery + Lightbox
     ====================================================================== */
  const galleryEl = $('#gallery');
  galleryEl.innerHTML = D.GALLERY.map((g, i) =>
    '<figure class="gal-item ' + g.size + '" tabindex="0" role="button" data-i="' + i + '" ' +
      'aria-label="Agrandir : ' + g.cap + '">' +
      '<img src="' + g.src + '" alt="' + g.alt + '" loading="lazy" decoding="async">' +
      '<figcaption>' + g.cap + '</figcaption>' +
    '</figure>'
  ).join('');

  const lb = $('#lightbox'), lbImg = $('#lbImg'), lbCap = $('#lbCap'), lbCount = $('#lbCount');
  let lbIndex = 0, lastFocused = null;

  function openLightbox(i) {
    lastFocused = document.activeElement;
    lbIndex = (i + D.GALLERY.length) % D.GALLERY.length;
    const g = D.GALLERY[lbIndex];
    lbImg.src = g.src; lbImg.alt = g.alt;
    lbCap.textContent = g.cap;
    lbCount.textContent = (lbIndex + 1) + ' / ' + D.GALLERY.length;
    lb.classList.add('open');
    document.body.classList.add('is-locked');
    $('#lbClose').focus();
  }
  function closeLightbox() {
    lb.classList.remove('open');
    document.body.classList.remove('is-locked');
    if (lastFocused) lastFocused.focus();
  }
  function stepLightbox(n) { openLightbox(lbIndex + n); }

  galleryEl.addEventListener('click', (e) => {
    const f = e.target.closest('.gal-item'); if (f) openLightbox(+f.dataset.i);
  });
  galleryEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const f = e.target.closest('.gal-item'); if (f) { e.preventDefault(); openLightbox(+f.dataset.i); }
  });
  $('#lbClose').addEventListener('click', closeLightbox);
  $('#lbPrev').addEventListener('click', () => stepLightbox(-1));
  $('#lbNext').addEventListener('click', () => stepLightbox(1));
  lb.addEventListener('click', (e) => { if (e.target === lb) closeLightbox(); });

  /* ======================================================================
     15. Testimonials slider (autoplay + swipe + keyboard)
     ====================================================================== */
  const track = $('#tsmTrack'), dotsEl = $('#tsmDots'), viewport = $('#tsmViewport');
  let tIndex = 0, tTimer = null;

  track.innerHTML = D.TESTIMONIALS.map(t =>
    '<div class="tsm__slide"><blockquote class="tsm__card">' +
      '<div class="tsm__stars" aria-label="Note ' + t.stars + ' sur 5">' + '★'.repeat(t.stars) + '☆'.repeat(5 - t.stars) + '</div>' +
      '<p class="tsm__text">' + t.text + '</p>' +
      '<footer class="tsm__who"><span class="tsm__avatar" aria-hidden="true">' + t.initials + '</span>' +
        '<div><b>' + t.name + '</b><small>' + t.role + '</small></div></footer>' +
    '</blockquote></div>'
  ).join('');

  dotsEl.innerHTML = D.TESTIMONIALS.map((_, i) =>
    '<button type="button" data-i="' + i + '" aria-label="Avis ' + (i + 1) + '" aria-current="' + (i === 0) + '"></button>'
  ).join('');

  function goSlide(i) {
    tIndex = (i + D.TESTIMONIALS.length) % D.TESTIMONIALS.length;
    track.style.transform = 'translateX(-' + tIndex * 100 + '%)';
    $$('button', dotsEl).forEach((b, k) => b.setAttribute('aria-current', String(k === tIndex)));
  }
  function autoplay() { clearInterval(tTimer); if (!REDUCED) tTimer = setInterval(() => goSlide(tIndex + 1), 6500); }

  $('#tsmPrev').addEventListener('click', () => { goSlide(tIndex - 1); autoplay(); });
  $('#tsmNext').addEventListener('click', () => { goSlide(tIndex + 1); autoplay(); });
  dotsEl.addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { goSlide(+b.dataset.i); autoplay(); } });
  viewport.addEventListener('mouseenter', () => clearInterval(tTimer));
  viewport.addEventListener('mouseleave', autoplay);

  // Touch swipe
  let x0 = null;
  viewport.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true });
  viewport.addEventListener('touchend', (e) => {
    if (x0 === null) return;
    const dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 45) { goSlide(tIndex + (dx < 0 ? 1 : -1)); autoplay(); }
    x0 = null;
  }, { passive: true });
  autoplay();

  /* ======================================================================
     16. Opening hours, socials, WhatsApp, year
     ====================================================================== */
  const hoursHtml = D.INFO.hours.map(h => '<li><span>' + h.day + '</span><b>' + h.time + '</b></li>').join('');
  $('#hoursList').innerHTML = hoursHtml;
  $('#footerHours').innerHTML = hoursHtml;

  // Today's hours (0 = Sunday)
  const dayMap = [3, 0, 0, 0, 0, 1, 2]; // Sun->Dimanche, Mon-Thu->0, Fri->1, Sat->2
  $('#todayHours').textContent = D.INFO.hours[dayMap[new Date().getDay()]].time;

  const ICONS = {
    facebook: '<path d="M14 9h2.5V6H14c-2 0-3.5 1.6-3.5 3.6V11H8v3h2.5v7h3v-7H16l.5-3h-3V9.6c0-.3.2-.6.5-.6z"/>',
    instagram: '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.2" cy="6.8" r="1.3"/>',
    tripadvisor: '<circle cx="8" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="16" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="8" cy="12" r="1.4"/><circle cx="16" cy="12" r="1.4"/><path d="M8 8c1.5-1.6 6.5-1.6 8 0" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    youtube: '<rect x="2.5" y="5.5" width="19" height="13" rx="4" fill="none" stroke="currentColor" stroke-width="2"/><path d="M10.5 9.5v5l4.2-2.5z"/>'
  };
  const socialHtml = D.INFO.social.map(s =>
    '<a class="social" href="' + s.url + '" target="_blank" rel="noopener noreferrer" aria-label="' + s.name + ' (nouvel onglet)">' +
    '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' + ICONS[s.icon] + '</svg></a>'
  ).join('');
  $('#socials').innerHTML = socialHtml;
  $('#footerSocials').innerHTML = socialHtml;

  /* --- Liens WhatsApp (numéro issu de la base : database/restaurant.json) --- */
  const waNumber = String(D.INFO.whatsapp || '').replace(/[^0-9]/g, '');
  const waDisplay = D.INFO.whatsappDisplay || ('+' + waNumber);

  $('#waBtn').href = 'https://wa.me/' + waNumber +
    '?text=' + encodeURIComponent('Bonjour ' + (D.INFO.name || 'Restaurant Soussri Salé') + ', je souhaite réserver une table.');

  const contactWa = $('#contactWa');
  if (contactWa) {
    contactWa.href = 'https://wa.me/' + waNumber +
      '?text=' + encodeURIComponent('Bonjour, je souhaite réserver une table chez ' + (D.INFO.name || 'Soussri Salé') + '.');
    contactWa.textContent = waDisplay;
  }
  // Numéro affiché dans les textes de la page
  $$('.wa-num').forEach(el => { el.textContent = waDisplay; });

  $('#year').textContent = new Date().getFullYear();

  /* ======================================================================
     17. Form validation helpers
     ====================================================================== */
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
  const PHONE_RE = /^[+0-9][0-9\s().-]{7,}$/;

  function setError(input, msg) {
    const slot = $('[data-err="' + input.id + '"]');
    if (slot) slot.textContent = msg || '';
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    return !msg;
  }
  function validate(rules) {
    let firstBad = null, ok = true;
    rules.forEach(r => {
      const good = setError(r.el, r.test() ? '' : r.msg);
      if (!good) { ok = false; if (!firstBad) firstBad = r.el; }
    });
    if (firstBad) firstBad.focus();
    return ok;
  }

  /* ======================================================================
     18. Reservations (LocalStorage)
     ====================================================================== */
  const resaForm = $('#resaForm');
  const bookingsEl = $('#myBookings');
  const MONTHS = ['JAN', 'FÉV', 'MAR', 'AVR', 'MAI', 'JUIN', 'JUIL', 'AOÛ', 'SEP', 'OCT', 'NOV', 'DÉC'];

  /* ----------------------------------------------------------------------
     18.a Envoi de la réservation sur le WhatsApp du restaurant
     Le numéro provient de la base : INFO.whatsapp (database/restaurant.json).
     Aucun serveur n'est nécessaire : on ouvre simplement un lien wa.me
     pré-rempli, le client n'a plus qu'à appuyer sur « Envoyer ».
     ---------------------------------------------------------------------- */
  function longDate(iso) {
    try {
      return new Date(iso + 'T00:00:00')
        .toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    } catch (e) { return iso; }
  }

  /** Construit le texte de la demande de réservation. */
  function buildWaMessage(b) {
    const L = [];
    L.push('*NOUVELLE RÉSERVATION*');
    L.push('_' + (D.INFO.name || 'Restaurant Soussri Salé') + '_');
    L.push('');
    L.push('🔖 Référence : *' + b.ref + '*');
    L.push('👤 Nom : ' + b.name);
    L.push('📞 Téléphone : ' + b.phone);
    L.push('✉️ E-mail : ' + b.email);
    L.push('');
    L.push('📅 Date : *' + longDate(b.date) + '*');
    L.push('🕐 Heure : *' + b.time + '*');
    L.push('👥 Convives : *' + b.guests + '*');
    L.push('📍 Emplacement : ' + (b.area || 'Salle principale'));
    if (b.notes) { L.push(''); L.push('📝 Demandes particulières :'); L.push(b.notes); }
    L.push('');
    L.push('Merci de me confirmer la disponibilité. 🙏');
    return L.join('\n');
  }

  /** Lien wa.me pré-rempli vers le numéro du restaurant. */
  function waBookingLink(b) {
    const num = String(D.INFO.whatsapp || '').replace(/[^0-9]/g, '');
    return 'https://wa.me/' + num + '?text=' + encodeURIComponent(buildWaMessage(b));
  }

  /**
   * Ouvre WhatsApp. Doit être appelé DANS le geste utilisateur (submit/clic)
   * pour ne pas être bloqué par le navigateur. Renvoie false si bloqué.
   */
  function openWhatsApp(b) {
    const win = window.open(waBookingLink(b), '_blank', 'noopener');
    return !!win;
  }

  /* Fenêtre de confirmation --------------------------------------------- */
  const bookModal = $('#bookModal');
  function showBookingConfirm(b, sent) {
    $('#bookRef').textContent = b.ref;
    $('#bookWa').href = waBookingLink(b);
    $('#bookWaNum').textContent = D.INFO.whatsappDisplay || ('+' + D.INFO.whatsapp);
    $('#bookRecap').innerHTML =
      '<li><span>Date</span><b>' + longDate(b.date) + '</b></li>' +
      '<li><span>Heure</span><b>' + b.time + '</b></li>' +
      '<li><span>Convives</span><b>' + b.guests + ' personne' + (String(b.guests) === '1' ? '' : 's') + '</b></li>' +
      '<li><span>Emplacement</span><b>' + (b.area || 'Salle principale') + '</b></li>' +
      '<li><span>Au nom de</span><b>' + b.name + '</b></li>';
    // Message adapté selon que WhatsApp s'est ouvert ou a été bloqué
    $('#bookModal .modal__sub').textContent = sent
      ? 'WhatsApp s\'est ouvert avec votre demande pré-remplie : appuyez simplement sur « Envoyer » pour la transmettre au restaurant.'
      : 'Dernière étape : envoyez votre demande au restaurant sur WhatsApp pour recevoir la confirmation définitive.';
    openModal('bookModal');
  }

  // Minimum bookable date = today
  const todayISO = new Date().toISOString().split('T')[0];
  $('#rDate').min = todayISO;

  function getBookings() { return store.get('bookings', []); }

  function renderBookings() {
    const list = getBookings().sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
    bookingsEl.innerHTML = list.length ? list.map(b => {
      const d = new Date(b.date + 'T00:00:00');
      return '<div class="booking">' +
        '<div class="booking__date"><b>' + d.getDate() + '</b><small>' + MONTHS[d.getMonth()] + '</small></div>' +
        '<div class="booking__info"><b>' + b.time + ' · ' + b.guests + ' pers.</b>' +
          '<small>' + b.area + ' — ' + b.name + '</small><br>' +
          '<span class="ref">' + b.ref + '</span> ' +
          // Statut piloté depuis le panneau d'administration
          '<span class="st ' + (b.status || 'confirmed') + '">' +
            (b.status === 'pending' ? 'En attente' : b.status === 'cancelled' ? 'Annulée' : 'Confirmée') +
          '</span></div>' +
        // Renvoyer la demande sur le WhatsApp du restaurant
        '<button class="booking__wa" type="button" data-wa="' + b.ref + '" aria-label="Envoyer la réservation ' + b.ref + ' sur WhatsApp" title="Envoyer sur WhatsApp">' +
          '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M17.5 14.4c-.3-.2-1.7-.9-2-1-.3-.1-.5-.1-.7.1-.2.3-.7 1-.9 1.2-.2.2-.3.2-.6.1s-1.3-.5-2.4-1.5c-.9-.8-1.5-1.8-1.6-2.1-.2-.3 0-.4.1-.6l.4-.5c.2-.2.2-.3.3-.5.1-.2 0-.4 0-.5s-.7-1.6-.9-2.2c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5 4.5.7.3 1.3.5 1.7.6.7.2 1.4.2 1.9.1.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.2-.3-.3-.6-.4M12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2m0 18.2c-1.6 0-3.2-.4-4.5-1.2l-.3-.2-3.1.8.8-3-.2-.3A8.2 8.2 0 1 1 12 20.2"/></svg>' +
        '</button>' +
        '<button class="booking__del" type="button" data-del="' + b.ref + '" aria-label="Annuler la réservation ' + b.ref + '">' +
          '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>' +
        '</button></div>';
    }).join('')
      : '<div class="empty" style="padding:1.6rem 0"><b>Aucune réservation</b><p>Remplissez le formulaire pour réserver votre table.</p></div>';
    refreshAccountStats();
  }

  resaForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = $('#rName'), phone = $('#rPhone'), email = $('#rEmail'),
          date = $('#rDate'), time = $('#rTime'), guests = $('#rGuests');

    const ok = validate([
      { el: name,  test: () => name.value.trim().length >= 2,       msg: 'Merci d\'indiquer votre nom (2 caractères min.).' },
      { el: phone, test: () => PHONE_RE.test(phone.value.trim()),   msg: 'Numéro de téléphone invalide.' },
      { el: email, test: () => EMAIL_RE.test(email.value.trim()),   msg: 'Adresse e-mail invalide.' },
      { el: date,  test: () => !!date.value && date.value >= todayISO, msg: 'Choisissez une date à venir.' },
      { el: time,  test: () => !!time.value,                        msg: 'Choisissez une heure.' },
      { el: guests,test: () => !!guests.value,                      msg: 'Indiquez le nombre de convives.' }
    ]);
    if (!ok) { toast('Merci de corriger les champs signalés.', 'err'); return; }

    const booking = {
      ref: 'SSR-' + Math.random().toString(36).slice(2, 7).toUpperCase(),
      name: name.value.trim(), phone: phone.value.trim(), email: email.value.trim(),
      date: date.value, time: time.value, guests: guests.value,
      area: $('#rArea').value, notes: $('#rNotes').value.trim(),
      created: new Date().toISOString()
    };
    const list = getBookings(); list.push(booking);
    if (!store.set('bookings', list)) { toast('Stockage local indisponible.', 'err'); return; }

    renderBookings();
    resaForm.reset();

    // --- Transmission de la demande sur le WhatsApp du restaurant ---------
    // window.open() est appelé ici, directement dans le geste utilisateur,
    // pour ne pas être bloqué par le navigateur.
    let sent = false;
    if (D.INFO.bookingsToWhatsApp !== false && D.INFO.whatsapp) {
      sent = openWhatsApp(booking);
    }

    toast(sent
      ? 'Demande ' + booking.ref + ' ouverte dans WhatsApp — appuyez sur « Envoyer ».'
      : 'Table réservée ! Référence ' + booking.ref, 'ok');

    showBookingConfirm(booking, sent);
  });

  bookingsEl.addEventListener('click', (e) => {
    // Renvoi de la demande sur WhatsApp
    const wa = e.target.closest('[data-wa]');
    if (wa) {
      const booking = getBookings().find(x => x.ref === wa.dataset.wa);
      if (booking) {
        const ok = openWhatsApp(booking);
        toast(ok ? 'Demande ' + booking.ref + ' ouverte dans WhatsApp.' : 'Ouverture bloquée — autorisez les fenêtres pop-up.', ok ? 'ok' : 'err');
      }
      return;
    }
    // Annulation
    const b = e.target.closest('[data-del]'); if (!b) return;
    store.set('bookings', getBookings().filter(x => x.ref !== b.dataset.del));
    renderBookings();
    toast('Réservation annulée.');
  });

  $('#clearResa').addEventListener('click', () => {
    if (!getBookings().length) { toast('Aucune réservation à effacer.'); return; }
    store.del('bookings'); renderBookings(); toast('Toutes vos réservations ont été effacées.');
  });

  renderBookings();

  /* ======================================================================
     19. Contact + newsletter forms (stored locally for the demo)
     ====================================================================== */
  $('#contactForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const n = $('#cName'), em = $('#cEmail'), m = $('#cMsg');
    const ok = validate([
      { el: n,  test: () => n.value.trim().length >= 2,     msg: 'Merci d\'indiquer votre nom.' },
      { el: em, test: () => EMAIL_RE.test(em.value.trim()), msg: 'Adresse e-mail invalide.' },
      { el: m,  test: () => m.value.trim().length >= 10,    msg: 'Votre message est un peu court (10 caractères min.).' }
    ]);
    if (!ok) return;
    const msgs = store.get('messages', []);
    msgs.push({ name: n.value.trim(), email: em.value.trim(), msg: m.value.trim(), at: new Date().toISOString() });
    store.set('messages', msgs);
    e.target.reset();
    toast('Message envoyé ! Nous vous répondons sous 24 h.', 'ok');
  });

  $('#newsForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('#newsEmail').value.trim();
    if (!EMAIL_RE.test(v)) { toast('Adresse e-mail invalide.', 'err'); return; }
    const subs = store.get('newsletter', []);
    if (!subs.includes(v)) subs.push(v);
    store.set('newsletter', subs);
    e.target.reset();
    toast('Merci ! Vous êtes inscrit·e à notre lettre gourmande.', 'ok');
  });

  /* ======================================================================
     20. Modals (generic open/close + focus management)
     ====================================================================== */
  let modalOpener = null;
  function openModal(id) {
    modalOpener = document.activeElement;
    const m = document.getElementById(id);
    m.classList.add('open');
    document.body.classList.add('is-locked');
    const focusable = $$('button, input, a[href], select, textarea', m).filter(el => el.offsetParent !== null);
    if (focusable[0]) setTimeout(() => focusable[0].focus(), 60);
  }
  function closeModal(m) {
    m.classList.remove('open');
    if (!$$('.modal.open').length && !lb.classList.contains('open')) document.body.classList.remove('is-locked');
    if (modalOpener) modalOpener.focus();
  }
  $$('[data-close-modal]').forEach(b => b.addEventListener('click', () => closeModal(b.closest('.modal'))));
  $$('.modal').forEach(m => m.addEventListener('click', (e) => { if (e.target === m) closeModal(m); }));

  // Global keyboard handling
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (lb.classList.contains('open')) closeLightbox();
      $$('.modal.open').forEach(closeModal);
      if (burger.getAttribute('aria-expanded') === 'true') setMenu(false);
    }
    if (lb.classList.contains('open')) {
      if (e.key === 'ArrowLeft') stepLightbox(-1);
      if (e.key === 'ArrowRight') stepLightbox(1);
    }
    // Focus trap inside open modals
    const open = $('.modal.open');
    if (open && e.key === 'Tab') {
      const f = $$('button, input, a[href], select, textarea', open).filter(el => el.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  $('#favBtn').addEventListener('click', () => { renderFavModal(); openModal('favModal'); });

  /* ======================================================================
     21. Authentication simulation (LocalStorage only)
     NOTE: passwords are only lightly hashed — this is a front-end demo,
     never a real security mechanism.
     ====================================================================== */
  function hash(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
    return 'h' + h.toString(36);
  }
  // Declared as hoisted functions: they are used by earlier sections at init time.
  function getUsers() { return store.get('users', []); }
  function currentUser() {
    const email = store.get('session', null);
    return email ? getUsers().find(u => u.email === email) || null : null;
  }

  const authGuest = $('#authGuest'), authUser = $('#authUser');
  const tabLogin = $('#tabLogin'), tabSignup = $('#tabSignup');
  const loginForm = $('#loginForm'), signupForm = $('#signupForm');

  function showTab(which) {
    const login = which === 'login';
    tabLogin.setAttribute('aria-selected', String(login));
    tabSignup.setAttribute('aria-selected', String(!login));
    loginForm.hidden = !login;
    signupForm.hidden = login;
  }
  tabLogin.addEventListener('click', () => showTab('login'));
  tabSignup.addEventListener('click', () => showTab('signup'));

  $$('.pw-toggle').forEach(btn => btn.addEventListener('click', () => {
    const input = document.getElementById(btn.dataset.pw);
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.setAttribute('aria-label', show ? 'Masquer le mot de passe' : 'Afficher le mot de passe');
  }));

  function refreshAccountStats() {
    const u = currentUser();
    if (!u) return;
    $('#uFavs').textContent = favorites.length;
    $('#uResa').textContent = getBookings().length;
  }

  function renderAuth() {
    const u = currentUser();
    authGuest.hidden = !!u;
    authUser.hidden = !u;
    if (u) {
      $('#uAvatar').textContent = u.name.trim().charAt(0).toUpperCase();
      $('#uName').textContent = u.name;
      $('#uEmail').textContent = u.email;
      $('#uSince').textContent = new Date(u.since).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
      refreshAccountStats();
      $('#authBtn').setAttribute('aria-label', 'Mon compte — ' + u.name);
    } else {
      $('#authBtn').setAttribute('aria-label', 'Se connecter ou créer un compte');
    }
  }

  $('#authBtn').addEventListener('click', () => { renderAuth(); openModal('authModal'); });
  $$('[data-open-auth]').forEach(b => b.addEventListener('click', () => { renderAuth(); openModal('authModal'); }));

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const em = $('#lEmail'), pw = $('#lPass');
    if (!validate([
      { el: em, test: () => EMAIL_RE.test(em.value.trim()), msg: 'Adresse e-mail invalide.' },
      { el: pw, test: () => pw.value.length >= 6,           msg: '6 caractères minimum.' }
    ])) return;

    const user = getUsers().find(u => u.email === em.value.trim().toLowerCase());
    if (!user || user.pass !== hash(pw.value)) {
      setError(pw, 'E-mail ou mot de passe incorrect.');
      toast('Identifiants incorrects.', 'err');
      return;
    }
    store.set('session', user.email);
    loginForm.reset(); renderAuth();
    toast('Bienvenue, ' + user.name.split(' ')[0] + ' 👋', 'ok');
  });

  signupForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const n = $('#sName'), em = $('#sEmail'), pw = $('#sPass');
    if (!validate([
      { el: n,  test: () => n.value.trim().length >= 2,      msg: 'Merci d\'indiquer votre nom.' },
      { el: em, test: () => EMAIL_RE.test(em.value.trim()),  msg: 'Adresse e-mail invalide.' },
      { el: pw, test: () => pw.value.length >= 6,            msg: '6 caractères minimum.' }
    ])) return;

    const users = getUsers();
    const email = em.value.trim().toLowerCase();
    if (users.some(u => u.email === email)) {
      setError(em, 'Un compte existe déjà avec cet e-mail.');
      toast('Ce compte existe déjà — connectez-vous.', 'err');
      showTab('login');
      return;
    }
    const user = { name: n.value.trim(), email: email, pass: hash(pw.value), since: new Date().toISOString() };
    users.push(user);
    store.set('users', users);
    store.set('session', email);
    signupForm.reset(); renderAuth();
    toast('Compte créé. Bienvenue chez Soussri ! 🎉', 'ok');
  });

  $('#demoLogin').addEventListener('click', () => {
    const users = getUsers();
    const demo = { name: 'Invité Soussri', email: 'demo@soussri-sale.ma', pass: hash('demo123'), since: new Date().toISOString() };
    if (!users.some(u => u.email === demo.email)) { users.push(demo); store.set('users', users); }
    store.set('session', demo.email);
    renderAuth();
    toast('Connecté avec le compte démo.', 'ok');
  });

  $('#logoutBtn').addEventListener('click', () => {
    store.del('session'); renderAuth(); showTab('login');
    toast('Vous êtes déconnecté·e.');
  });

  renderAuth();

  /* ======================================================================
     22. Hash routes: #login and #signup behave like dedicated pages
     ====================================================================== */
  function handleHash() {
    const h = location.hash.replace('#', '');
    if (h === 'login' || h === 'signup') {
      renderAuth(); showTab(h === 'signup' ? 'signup' : 'login'); openModal('authModal');
    } else if (h === 'favorites') {
      renderFavModal(); openModal('favModal');
    }
  }
  window.addEventListener('hashchange', handleHash);
  handleHash();

  /* ======================================================================
     23. Smooth anchor scrolling (with sticky-header offset)
     ====================================================================== */
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    const id = a.getAttribute('href');
    if (id.length < 2 || ['#login', '#signup', '#favorites'].includes(id)) return;
    const target = document.querySelector(id);
    if (!target) return;
    e.preventDefault();
    const y = target.getBoundingClientRect().top + window.scrollY - (window.innerWidth >= 1024 ? 86 : 76) - 10;
    window.scrollTo({ top: Math.max(y, 0), behavior: REDUCED ? 'auto' : 'smooth' });
    // replaceState can throw on the file:// protocol in some browsers — stay safe.
    try { history.replaceState(null, '', id); } catch (err) { /* no-op */ }
  });

  /* ======================================================================
     24. Console signature
     ====================================================================== */
  console.log('%c Restaurant Soussri Salé ', 'background:#c9962f;color:#1d1710;font-weight:700;padding:4px 8px;border-radius:4px;',
    '\nSite statique — HTML5 · CSS3 · JavaScript vanilla.' +
    '\nBase de données locale : ' + DB.engine.toUpperCase() + ' (' + DB.count('dishes') + ' plats).' +
    '\nAdministration : bouton « base de données » dans l\'en-tête ou #admin (code : soussri2026).');

  /* ======================================================================
     25. Pont avec le panneau d'administration
     Redessine toute l'interface publique après une écriture en base.
     ====================================================================== */
  function refreshAll() {
    DB.refreshView();
    favorites = store.get('favorites', []);
    syncFavBadge();
    renderMenu();
    renderFavModal();
    renderBookings();
    renderAuth();
    // Le menu de catégories peut avoir changé côté admin
    $$('.cat', catsEl).forEach(b => b.setAttribute('aria-selected', String(b.dataset.cat === activeCat)));
  }

  window.SoussriApp = {
    refreshAll: refreshAll,
    toast: toast,
    renderMenu: renderMenu,
    renderBookings: renderBookings,
    renderFavModal: renderFavModal,
    renderAuth: renderAuth
  };
}

/* ==========================================================================
   Démarrage : on attend l'ouverture de la base de données locale, puis on
   lance l'application. En cas d'échec total, le site démarre quand même
   avec les données d'amorçage de js/data.js (aucune page blanche).
   ========================================================================== */
(function boot() {
  let booted = false;
  const launch = () => { if (booted) return; booted = true; startSoussriApp(); };

  const fallback = (err) => {
    if (err) console.error('[Soussri] Base indisponible, démarrage en mode dégradé.', err);
    if (!window.SoussriDB) {
      // Filet de sécurité : db.js absent -> vue minimale basée sur data.js
      window.SoussriDB = {
        data: window.SOUSSRI_DATA, engine: 'memory', count: () => 0,
        refreshView: function () {}, legacyStore: {
          get: (k, f) => { try { const v = localStorage.getItem('soussri.' + k); return v ? JSON.parse(v) : f; } catch (e) { return f; } },
          set: (k, v) => { try { localStorage.setItem('soussri.' + k, JSON.stringify(v)); return true; } catch (e) { return false; } },
          del: (k) => { try { localStorage.removeItem('soussri.' + k); } catch (e) {} }
        }
      };
    }
    launch();
  };

  if (window.SoussriDB && window.SoussriDB.init) {
    window.SoussriDB.init().then(launch).catch(fallback);
    // Filet de sécurité : si la base ne répond pas en 4 s, on démarre quand même
    setTimeout(() => { if (!booted) fallback(new Error('Délai d\'ouverture dépassé.')); }, 4000);
  } else {
    fallback();
  }
})();
