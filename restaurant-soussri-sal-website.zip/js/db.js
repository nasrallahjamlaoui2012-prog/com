/* ==========================================================================
   Restaurant Soussri Salé — db.js
   --------------------------------------------------------------------------
   BASE DE DONNÉES LOCALE (client-side database)

   Moteur : IndexedDB — la base de données native de tous les navigateurs
   modernes. Aucun serveur, aucun MySQL/MongoDB/Firebase : la base vit dans
   le navigateur du visiteur, ce qui reste 100 % compatible GitHub Pages.

   Fonctionnalités :
     • 10 collections (tables) avec clés primaires et index
     • Cache mémoire synchrone -> lecture instantanée pour l'interface
     • Écritures asynchrones + miroir LocalStorage (sauvegarde de secours)
     • Repli automatique sur LocalStorage si IndexedDB est indisponible
       (mode privé, navigateur ancien, protocole file:// restreint…)
     • Amorçage (seed) automatique depuis js/data.js au premier lancement
     • Requêtes : query({ where, sort, limit }), statistiques agrégées
     • Import / export JSON, sauvegarde, restauration, réinitialisation
     • Adaptateur "legacyStore" : conserve l'API simple utilisée par script.js

   Schéma des collections
   ┌───────────────┬──────────────┬─────────────────────────────────────────┐
   │ Collection    │ Clé primaire │ Description                             │
   ├───────────────┼──────────────┼─────────────────────────────────────────┤
   │ settings      │ key          │ Préférences (thème, session, code admin)│
   │ categories    │ id           │ Catégories du menu                      │
   │ dishes        │ id           │ Plats (nom, prix, catégorie, image…)    │
   │ reservations  │ ref          │ Réservations clients + statut           │
   │ users         │ email        │ Comptes clients (mot de passe haché)    │
   │ favorites     │ id           │ Plats favoris de l'appareil             │
   │ messages      │ id           │ Messages du formulaire de contact       │
   │ testimonials  │ id           │ Avis clients                            │
   │ gallery       │ id           │ Photos de la galerie                    │
   │ team          │ id           │ Membres de l'équipe                     │
   └───────────────┴──────────────┴─────────────────────────────────────────┘
   ========================================================================== */
(function (global) {
  'use strict';

  /* ======================================================================
     1. Configuration du schéma
     ====================================================================== */
  const DB_NAME = 'soussri_db';
  const DB_VERSION = 1;
  // Incrémentez après toute mise à jour de /database/ ou js/data.js :
  // les bases déjà installées seront ré-amorcées automatiquement.
  // v2 → numéro WhatsApp de réservation : +212 672-297256
  // v3 → nouvelle carte « Snack Souiri — Spécialité Poisson », prix en DH
  const SEED_VERSION = 3;
  const LS_PREFIX = 'soussri.db.'; // préfixe du miroir LocalStorage

  const SCHEMA = {
    settings:     { key: 'key',   indexes: [] },
    categories:   { key: 'id',    indexes: [] },
    dishes:       { key: 'id',    indexes: ['cat', 'price', 'name'] },
    reservations: { key: 'ref',   indexes: ['date', 'status', 'email'] },
    users:        { key: 'email', indexes: ['name'] },
    favorites:    { key: 'id',    indexes: [] },
    messages:     { key: 'id',    indexes: ['at', 'read'] },
    testimonials: { key: 'id',    indexes: [] },
    gallery:      { key: 'id',    indexes: [] },
    team:         { key: 'id',    indexes: [] }
  };
  const COLLECTIONS = Object.keys(SCHEMA);

  /* ======================================================================
     2. État interne
     ====================================================================== */
  let idb = null;                    // instance IDBDatabase (ou null en repli)
  let engine = 'localstorage';       // moteur réellement utilisé
  const cache = {};                  // { collection: [ ...documents ] }
  const listeners = [];              // abonnés aux changements
  COLLECTIONS.forEach(c => { cache[c] = []; });

  const clone = (v) => JSON.parse(JSON.stringify(v));
  const keyOf = (coll) => SCHEMA[coll].key;
  const uid = (p) => (p || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  /* ======================================================================
     3. Couche LocalStorage (miroir + repli)
     ====================================================================== */
  const LS = {
    read(coll) {
      try { const raw = localStorage.getItem(LS_PREFIX + coll); return raw ? JSON.parse(raw) : null; }
      catch (e) { return null; }
    },
    write(coll, rows) {
      try { localStorage.setItem(LS_PREFIX + coll, JSON.stringify(rows)); return true; }
      catch (e) { console.warn('[SoussriDB] Miroir LocalStorage saturé pour « ' + coll + ' ».'); return false; }
    },
    drop(coll) { try { localStorage.removeItem(LS_PREFIX + coll); } catch (e) {} }
  };

  /* ======================================================================
     4. Couche IndexedDB
     ====================================================================== */
  function openIDB() {
    return new Promise((resolve) => {
      if (!('indexedDB' in global)) return resolve(null);
      let req;
      try { req = indexedDB.open(DB_NAME, DB_VERSION); }
      catch (e) { return resolve(null); }

      // Certains contextes (file:// durci, mode privé) restent bloqués sans erreur
      const guard = setTimeout(() => resolve(null), 2500);

      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        COLLECTIONS.forEach(coll => {
          if (db.objectStoreNames.contains(coll)) return;
          const storeObj = db.createObjectStore(coll, { keyPath: SCHEMA[coll].key });
          SCHEMA[coll].indexes.forEach(ix => {
            try { storeObj.createIndex('by_' + ix, ix, { unique: false }); } catch (err) {}
          });
        });
      };
      req.onsuccess = () => { clearTimeout(guard); resolve(req.result); };
      req.onerror = () => { clearTimeout(guard); resolve(null); };
      req.onblocked = () => { clearTimeout(guard); resolve(null); };
    });
  }

  function tx(coll, mode) {
    return idb.transaction(coll, mode).objectStore(coll);
  }
  function idbAll(coll) {
    return new Promise((resolve) => {
      try {
        const r = tx(coll, 'readonly').getAll();
        r.onsuccess = () => resolve(r.result || []);
        r.onerror = () => resolve([]);
      } catch (e) { resolve([]); }
    });
  }
  function idbPut(coll, doc) {
    return new Promise((resolve) => {
      try {
        const r = tx(coll, 'readwrite').put(doc);
        r.onsuccess = () => resolve(true);
        r.onerror = () => resolve(false);
      } catch (e) { resolve(false); }
    });
  }
  function idbDelete(coll, key) {
    return new Promise((resolve) => {
      try {
        const r = tx(coll, 'readwrite').delete(key);
        r.onsuccess = () => resolve(true);
        r.onerror = () => resolve(false);
      } catch (e) { resolve(false); }
    });
  }
  function idbClear(coll) {
    return new Promise((resolve) => {
      try {
        const r = tx(coll, 'readwrite').clear();
        r.onsuccess = () => resolve(true);
        r.onerror = () => resolve(false);
      } catch (e) { resolve(false); }
    });
  }

  /* ======================================================================
     5. Persistance unifiée (IndexedDB + miroir LocalStorage)
     ====================================================================== */
  function persist(coll) {
    LS.write(coll, cache[coll]);                       // miroir immédiat
    if (engine !== 'indexeddb') return Promise.resolve();
    return idbClear(coll).then(() => {                 // resynchronisation simple et fiable
      return Promise.all(cache[coll].map(doc => idbPut(coll, doc)));
    });
  }

  function emit(coll, action, payload) {
    listeners.forEach(fn => { try { fn({ collection: coll, action: action, payload: payload }); } catch (e) {} });
  }

  /* ======================================================================
     5 bis. CHARGEMENT DES TABLES DU DOSSIER /database/
     Les fichiers JSON de /database/ sont la SOURCE DE VÉRITÉ du contenu.
     Ils sont récupérés par fetch() au premier lancement puis copiés dans
     IndexedDB. Si fetch échoue (protocole file://, fichier absent, hors
     ligne), on retombe automatiquement sur js/data.js : le site fonctionne
     donc aussi bien par double-clic sur index.html que sur GitHub Pages.
     ====================================================================== */
  const DB_DIR = 'database/';
  const FILES = {
    restaurant:   'restaurant.json',
    categories:   'categories.json',
    dishes:       'dishes.json',
    testimonials: 'testimonials.json',
    gallery:      'gallery.json',
    team:         'team.json'
  };
  let sourceUsed = 'data.js';

  function fetchTable(file) {
    if (typeof fetch !== 'function' || location.protocol === 'file:') return Promise.resolve(null);
    return fetch(DB_DIR + file, { cache: 'no-cache' })
      .then(r => (r.ok ? r.json() : null))
      .catch(() => null);
  }

  /**
   * Récupère les tables JSON puis construit un objet identique en forme à
   * SOUSSRI_DATA, afin que le reste du code n'ait rien à savoir de l'origine.
   */
  function loadSeedSource() {
    const fallback = global.SOUSSRI_DATA || {};
    const names = Object.keys(FILES);

    return Promise.all(names.map(n => fetchTable(FILES[n])))
      .then(results => {
        const map = {};
        names.forEach((n, i) => { map[n] = results[i]; });

        const loaded = names.filter(n => map[n]).length;
        if (!loaded) {
          console.info('[SoussriDB] Tables /database/ inaccessibles → amorçage depuis js/data.js.');
          return fallback;
        }
        sourceUsed = loaded === names.length ? '/database/*.json' : '/database/*.json (partiel)';

        const R = map.restaurant;
        const src = {
          INFO: R ? {
            name: R.name, tagline: R.tagline, since: R.since, address: R.address,
            phone: R.phone, phoneHref: R.phoneHref, email: R.email,
            whatsapp: R.whatsapp, whatsappDisplay: R.whatsappDisplay,
            bookingsToWhatsApp: R.bookingsToWhatsApp !== false,
            mapsEmbed: R.mapsEmbed, mapsLink: R.mapsLink, social: R.social, hours: R.hours
          } : fallback.INFO,
          STATS:       R && R.stats      ? R.stats      : fallback.STATS,
          HERO_SLIDES: R && R.heroSlides ? R.heroSlides : fallback.HERO_SLIDES,
          CATEGORIES:  map.categories   ? map.categories.rows   : fallback.CATEGORIES,
          MENU:        map.dishes       ? map.dishes.rows       : fallback.MENU,
          TESTIMONIALS:map.testimonials ? map.testimonials.rows : fallback.TESTIMONIALS,
          GALLERY:     map.gallery      ? map.gallery.rows      : fallback.GALLERY,
          TEAM:        map.team         ? map.team.rows         : fallback.TEAM
        };
        console.info('[SoussriDB] Tables chargées depuis ' + sourceUsed + ' (' + loaded + '/' + names.length + ').');
        return src;
      })
      .catch(() => fallback);
  }

  /* ======================================================================
     6. Amorçage (seed) de la base
     ====================================================================== */
  function seedIfNeeded(SRC) {
    SRC = SRC || global.SOUSSRI_DATA || {};
    const seeded = getSetting('seedVersion', 0);
    const tasks = [];

    // Les informations de l'établissement alimentent la vue publique
    if (SRC.INFO) data.INFO = SRC.INFO;
    if (SRC.STATS) data.STATS = SRC.STATS;
    if (SRC.HERO_SLIDES) data.HERO_SLIDES = SRC.HERO_SLIDES;

    // Données de référence : (ré)amorcées uniquement si la version change
    if (seeded !== SEED_VERSION) {
      cache.categories = clone(SRC.CATEGORIES || []);
      cache.dishes = (SRC.MENU || []).map(d => Object.assign({ available: true, createdAt: new Date().toISOString() }, clone(d)));
      cache.testimonials = (SRC.TESTIMONIALS || []).map((t, i) => Object.assign({ id: 'tsm_' + i, published: true }, clone(t)));
      cache.gallery = (SRC.GALLERY || []).map((g, i) => Object.assign({ id: 'gal_' + i }, clone(g)));
      cache.team = (SRC.TEAM || []).map((m, i) => Object.assign({ id: 'team_' + i }, clone(m)));

      tasks.push(persist('categories'), persist('dishes'), persist('testimonials'),
                 persist('gallery'), persist('team'));

      // La fiche établissement est conservée en base : elle survit aux rechargements
      if (SRC.INFO) setSetting('info', SRC.INFO);
      if (SRC.STATS) setSetting('stats', SRC.STATS);
      if (SRC.HERO_SLIDES) setSetting('heroSlides', SRC.HERO_SLIDES);

      setSetting('seedVersion', SEED_VERSION);
      setSetting('source', sourceUsed);
      setSetting('installedAt', getSetting('installedAt', new Date().toISOString()));
      setSetting('adminCode', getSetting('adminCode', 'soussri2026'));
      console.info('[SoussriDB] Base amorcée depuis ' + sourceUsed + ' (schéma v' + SEED_VERSION + ').');
    }
    return Promise.all(tasks);
  }

  /**
   * Recharge les tables /database/*.json par-dessus la base existante.
   * Les données clients (réservations, comptes, messages) sont préservées.
   */
  function reloadFromFiles() {
    return loadSeedSource().then(SRC => {
      cache.categories = clone(SRC.CATEGORIES || []);
      cache.dishes = (SRC.MENU || []).map(d => Object.assign({ available: true }, clone(d)));
      cache.testimonials = (SRC.TESTIMONIALS || []).map((t, i) => Object.assign({ id: 'tsm_' + i, published: true }, clone(t)));
      cache.gallery = (SRC.GALLERY || []).map((g, i) => Object.assign({ id: 'gal_' + i }, clone(g)));
      cache.team = (SRC.TEAM || []).map((m, i) => Object.assign({ id: 'team_' + i }, clone(m)));
      if (SRC.INFO) setSetting('info', SRC.INFO);
      if (SRC.STATS) setSetting('stats', SRC.STATS);
      if (SRC.HERO_SLIDES) setSetting('heroSlides', SRC.HERO_SLIDES);
      setSetting('source', sourceUsed);
      return Promise.all([persist('categories'), persist('dishes'), persist('testimonials'),
                          persist('gallery'), persist('team')]);
    }).then(() => {
      refreshView();
      emit('*', 'reload', sourceUsed);
      return sourceUsed;
    });
  }

  /* ======================================================================
     6 bis. Migration des anciennes clés LocalStorage (versions < base)
     Les visiteurs qui possédaient déjà des favoris/réservations avant
     l'ajout de la base les retrouvent automatiquement.
     ====================================================================== */
  function migrateLegacy() {
    if (getSetting('migrated', false)) return Promise.resolve();
    const read = (k) => { try { const v = localStorage.getItem('soussri.' + k); return v ? JSON.parse(v) : null; } catch (e) { return null; } };
    const tasks = [];
    let moved = 0;

    const favs = read('favorites');
    if (Array.isArray(favs) && favs.length && !cache.favorites.length) {
      cache.favorites = favs.map(id => ({ id: id, addedAt: new Date().toISOString() }));
      tasks.push(persist('favorites')); moved += favs.length;
    }
    const books = read('bookings');
    if (Array.isArray(books) && books.length && !cache.reservations.length) {
      cache.reservations = books.map(b => Object.assign({ status: 'confirmed', source: 'legacy' }, b));
      tasks.push(persist('reservations')); moved += books.length;
    }
    const users = read('users');
    if (Array.isArray(users) && users.length && !cache.users.length) {
      cache.users = users; tasks.push(persist('users')); moved += users.length;
    }
    const msgs = read('messages');
    if (Array.isArray(msgs) && msgs.length && !cache.messages.length) {
      cache.messages = msgs.map((m, i) => Object.assign({ id: 'msg_legacy_' + i, read: false }, m));
      tasks.push(persist('messages')); moved += msgs.length;
    }
    const theme = read('theme');
    if (theme && getSetting('theme', null) === null) setSetting('theme', theme);
    const session = read('session');
    if (session && getSetting('session', null) === null) setSetting('session', session);

    setSetting('migrated', true);
    if (moved) console.info('[SoussriDB] Migration : ' + moved + ' enregistrement(s) importé(s) depuis l\'ancien stockage.');
    return Promise.all(tasks);
  }

  /* ======================================================================
     7. Vue « data » consommée par script.js
        (les tableaux sont reconstruits à chaque modification admin)
     ====================================================================== */
  const data = {
    INFO: (global.SOUSSRI_DATA && global.SOUSSRI_DATA.INFO) || {},
    HERO_SLIDES: (global.SOUSSRI_DATA && global.SOUSSRI_DATA.HERO_SLIDES) || [],
    STATS: (global.SOUSSRI_DATA && global.SOUSSRI_DATA.STATS) || [],
    CATEGORIES: [], MENU: [], TESTIMONIALS: [], GALLERY: [], TEAM: []
  };

  function refreshView() {
    // Fiche établissement : priorité à la base, repli sur data.js
    const fb = global.SOUSSRI_DATA || {};
    data.INFO = getSetting('info', fb.INFO || {});
    data.STATS = getSetting('stats', fb.STATS || []);
    data.HERO_SLIDES = getSetting('heroSlides', fb.HERO_SLIDES || []);

    data.CATEGORIES = cache.categories.slice();
    data.MENU = cache.dishes.filter(d => d.available !== false);
    data.TESTIMONIALS = cache.testimonials.filter(t => t.published !== false);
    data.GALLERY = cache.gallery.slice();
    data.TEAM = cache.team.slice();
  }

  /* ======================================================================
     8. Réglages (table settings) — accès synchrone
     ====================================================================== */
  function getSetting(key, fallback) {
    const row = cache.settings.find(s => s.key === key);
    return row ? row.value : fallback;
  }
  function setSetting(key, value) {
    const row = cache.settings.find(s => s.key === key);
    if (row) row.value = value;
    else cache.settings.push({ key: key, value: value });
    persist('settings');
    emit('settings', 'set', { key: key, value: value });
    return value;
  }
  function delSetting(key) {
    cache.settings = cache.settings.filter(s => s.key !== key);
    persist('settings');
    emit('settings', 'del', { key: key });
  }

  /* ======================================================================
     9. API CRUD publique
     ====================================================================== */
  function all(coll) { return cache[coll] ? cache[coll].slice() : []; }

  function get(coll, key) {
    const k = keyOf(coll);
    return cache[coll].find(d => d[k] === key) || null;
  }

  function put(coll, doc) {
    const k = keyOf(coll);
    const row = clone(doc);
    if (row[k] === undefined || row[k] === null || row[k] === '') row[k] = uid(coll.slice(0, 3));
    const i = cache[coll].findIndex(d => d[k] === row[k]);
    if (i > -1) cache[coll][i] = Object.assign({}, cache[coll][i], row);
    else cache[coll].push(row);
    refreshView();
    emit(coll, i > -1 ? 'update' : 'insert', row);
    return persist(coll).then(() => row);
  }

  function bulkPut(coll, docs) {
    const k = keyOf(coll);
    docs.forEach(doc => {
      const row = clone(doc);
      if (row[k] === undefined || row[k] === null || row[k] === '') row[k] = uid(coll.slice(0, 3));
      const i = cache[coll].findIndex(d => d[k] === row[k]);
      if (i > -1) cache[coll][i] = Object.assign({}, cache[coll][i], row);
      else cache[coll].push(row);
    });
    refreshView();
    emit(coll, 'bulk', docs);
    return persist(coll);
  }

  function remove(coll, key) {
    const k = keyOf(coll);
    cache[coll] = cache[coll].filter(d => d[k] !== key);
    refreshView();
    emit(coll, 'delete', key);
    return persist(coll);
  }

  function replace(coll, docs) {
    cache[coll] = clone(docs || []);
    refreshView();
    emit(coll, 'replace', cache[coll]);
    return persist(coll);
  }

  function clearColl(coll) { return replace(coll, []); }

  function count(coll) { return cache[coll] ? cache[coll].length : 0; }

  /**
   * Requête façon mini-ORM.
   * query('dishes', { where: d => d.price < 100, sort: 'price', desc: true, limit: 5 })
   */
  function query(coll, opt) {
    opt = opt || {};
    let rows = cache[coll] ? cache[coll].slice() : [];
    if (typeof opt.where === 'function') rows = rows.filter(opt.where);
    if (opt.search) {
      const q = String(opt.search).toLowerCase();
      rows = rows.filter(r => JSON.stringify(r).toLowerCase().indexOf(q) > -1);
    }
    if (opt.sort) {
      rows.sort((a, b) => {
        const x = a[opt.sort], y = b[opt.sort];
        if (typeof x === 'number' && typeof y === 'number') return x - y;
        return String(x === undefined ? '' : x).localeCompare(String(y === undefined ? '' : y), 'fr');
      });
      if (opt.desc) rows.reverse();
    }
    if (opt.limit) rows = rows.slice(0, opt.limit);
    return rows;
  }

  /* ======================================================================
     10. Statistiques agrégées (tableau de bord admin)
     ====================================================================== */
  function stats() {
    const res = cache.reservations;
    const covers = res.reduce((s, r) => s + (parseInt(r.guests, 10) || 0), 0);
    const prices = cache.dishes.map(d => Number(d.price) || 0);
    const avgPrice = prices.length ? prices.reduce((a, b) => a + b, 0) / prices.length : 0;
    const today = new Date().toISOString().split('T')[0];

    const byStatus = { confirmed: 0, pending: 0, cancelled: 0 };
    res.forEach(r => { byStatus[r.status || 'confirmed'] = (byStatus[r.status || 'confirmed'] || 0) + 1; });

    const byCat = {};
    cache.dishes.forEach(d => { byCat[d.cat] = (byCat[d.cat] || 0) + 1; });

    // Réservations sur les 7 prochains jours
    const upcoming = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(); d.setDate(d.getDate() + i);
      const iso = d.toISOString().split('T')[0];
      upcoming.push({
        iso: iso,
        label: d.toLocaleDateString('fr-FR', { weekday: 'short' }),
        day: d.getDate(),
        count: res.filter(r => r.date === iso && r.status !== 'cancelled').length
      });
    }

    return {
      dishes: cache.dishes.length,
      available: cache.dishes.filter(d => d.available !== false).length,
      categories: cache.categories.length,
      reservations: res.length,
      todayReservations: res.filter(r => r.date === today).length,
      covers: covers,
      users: cache.users.length,
      messages: cache.messages.length,
      unread: cache.messages.filter(m => !m.read).length,
      favorites: cache.favorites.length,
      testimonials: cache.testimonials.length,
      avgPrice: Math.round(avgPrice),
      revenue: Math.round(covers * avgPrice), // estimation simple du chiffre d'affaires
      byStatus: byStatus,
      byCat: byCat,
      upcoming: upcoming
    };
  }

  /* ======================================================================
     11. Sauvegarde : export / import / réinitialisation
     ====================================================================== */
  function exportJSON() {
    const dump = { _meta: { app: 'Restaurant Soussri Salé', engine: engine, exportedAt: new Date().toISOString(), dbVersion: DB_VERSION } };
    COLLECTIONS.forEach(c => { dump[c] = cache[c]; });
    return JSON.stringify(dump, null, 2);
  }

  function importJSON(json) {
    let dump;
    try { dump = typeof json === 'string' ? JSON.parse(json) : json; }
    catch (e) { return Promise.reject(new Error('Fichier JSON illisible.')); }

    const known = COLLECTIONS.filter(c => Array.isArray(dump[c]));
    if (!known.length) return Promise.reject(new Error('Aucune collection reconnue dans ce fichier.'));

    return Promise.all(known.map(c => replace(c, dump[c]))).then(() => {
      refreshView();
      return known;
    });
  }

  function resetAll() {
    return Promise.all(COLLECTIONS.map(c => {
      cache[c] = [];
      LS.drop(c);
      return engine === 'indexeddb' ? idbClear(c) : Promise.resolve();
    }))
    // La réinitialisation relit les tables du dossier /database/
    .then(() => loadSeedSource())
    .then(SRC => seedIfNeeded(SRC))
    .then(() => {
      setSetting('migrated', true); // évite de réimporter d'anciennes clés après un reset
      refreshView();
      emit('*', 'reset', null);
    });
  }

  /** Taille approximative occupée par la base (en Ko). */
  function size() {
    let bytes = 0;
    COLLECTIONS.forEach(c => { bytes += JSON.stringify(cache[c]).length; });
    return Math.max(1, Math.round(bytes / 1024));
  }

  /* ======================================================================
     12. Adaptateur de compatibilité pour script.js
         Conserve l'API synchrone { get, set, del } d'origine, mais toutes
         les données transitent désormais par la base.
     ====================================================================== */
  const legacyStore = {
    get(key, fallback) {
      switch (key) {
        case 'theme':      return getSetting('theme', fallback);
        case 'session':    return getSetting('session', fallback);
        case 'newsletter': return getSetting('newsletter', fallback || []);
        case 'favorites':  return cache.favorites.map(f => f.id);
        case 'bookings':   return all('reservations');
        case 'users':      return all('users');
        case 'messages':   return all('messages');
        default:           return getSetting(key, fallback);
      }
    },
    set(key, value) {
      switch (key) {
        case 'theme': case 'session': case 'newsletter':
          setSetting(key, value); return true;
        case 'favorites':
          replace('favorites', (value || []).map(id => ({ id: id, addedAt: new Date().toISOString() })));
          return true;
        case 'bookings':
          // Normalisation : chaque réservation reçoit un statut et un horodatage
          replace('reservations', (value || []).map(b => Object.assign({
            status: 'confirmed', source: 'site', created: new Date().toISOString()
          }, b)));
          return true;
        case 'users':
          replace('users', value || []); return true;
        case 'messages':
          replace('messages', (value || []).map((m, i) => Object.assign({
            id: m.id || 'msg_' + Date.parse(m.at || Date.now()) + '_' + i, read: !!m.read
          }, m)));
          return true;
        default:
          setSetting(key, value); return true;
      }
    },
    del(key) {
      switch (key) {
        case 'bookings':  clearColl('reservations'); break;
        case 'favorites': clearColl('favorites'); break;
        case 'messages':  clearColl('messages'); break;
        case 'users':     clearColl('users'); break;
        default:          delSetting(key);
      }
    }
  };

  /* ======================================================================
     13. Initialisation
     ====================================================================== */
  let readyPromise = null;

  function init() {
    if (readyPromise) return readyPromise;

    readyPromise = openIDB().then(db => {
      idb = db;
      engine = db ? 'indexeddb' : 'localstorage';

      // Chargement du cache mémoire
      if (engine === 'indexeddb') {
        return Promise.all(COLLECTIONS.map(c => idbAll(c).then(rows => {
          // Si IndexedDB est vide mais que le miroir existe, on restaure
          cache[c] = (rows && rows.length) ? rows : (LS.read(c) || []);
        })));
      }
      COLLECTIONS.forEach(c => { cache[c] = LS.read(c) || []; });
      return null;
    })
    // Les tables JSON de /database/ ne sont téléchargées qu'au premier amorçage
    .then(() => (getSetting('seedVersion', 0) !== SEED_VERSION ? loadSeedSource() : (global.SOUSSRI_DATA || {})))
    .then(SRC => seedIfNeeded(SRC))
    .then(() => migrateLegacy())
    .then(() => {
      refreshView();
      console.info('[SoussriDB] Prête — moteur : ' + engine.toUpperCase() +
                   ' · source : ' + getSetting('source', 'data.js') +
                   ' · ' + count('dishes') + ' plats · ' + count('reservations') + ' réservations · ~' + size() + ' Ko');
      return api;
    })
    .catch(err => {
      console.error('[SoussriDB] Échec d\'initialisation, repli mémoire.', err);
      refreshView();
      return api;
    });

    return readyPromise;
  }

  /* ======================================================================
     14. Exposition de l'API
     ====================================================================== */
  const api = {
    // cycle de vie
    init: init,
    ready: () => readyPromise || init(),
    get engine() { return engine; },
    get version() { return DB_VERSION; },
    collections: COLLECTIONS,
    schema: SCHEMA,

    // vue consommée par l'interface publique
    data: data,
    refreshView: refreshView,

    // CRUD
    all: all, get: get, put: put, bulkPut: bulkPut, remove: remove,
    replace: replace, clear: clearColl, count: count, query: query,

    // réglages
    setting: getSetting, setSetting: setSetting, delSetting: delSetting,

    // outils
    stats: stats, size: size, uid: uid,
    exportJSON: exportJSON, importJSON: importJSON, reset: resetAll,
    reloadFromFiles: reloadFromFiles,           // relit /database/*.json
    get source() { return getSetting('source', 'data.js'); },
    files: FILES, dir: DB_DIR,

    // évènements
    on: (fn) => { listeners.push(fn); return () => listeners.splice(listeners.indexOf(fn), 1); },

    // compatibilité
    legacyStore: legacyStore
  };

  global.SoussriDB = api;
})(window);
