/* ==========================================================================
   Restaurant Soussri Salé — admin.js
   --------------------------------------------------------------------------
   PANNEAU D'ADMINISTRATION de la base de données locale (SoussriDB).

   Ouverture : bouton « base de données » dans l'en-tête, ou route #admin.
   Accès protégé par un code (par défaut : soussri2026, modifiable dans
   l'onglet « Données »). Il s'agit d'une protection de démonstration :
   tout est public côté client, ne stockez jamais de secrets réels.

   Onglets :
     • Tableau de bord — statistiques, graphique 7 jours, dernières entrées
     • Plats          — CRUD complet sur la collection « dishes »
     • Réservations   — statut, filtre, suppression, export CSV
     • Clients        — comptes créés via l'inscription
     • Messages       — formulaire de contact, marquage lu/non lu
     • Données        — export / import JSON, réinitialisation, infos moteur
   ========================================================================== */
(function (global) {
  'use strict';

  const DB = global.SoussriDB;
  if (!DB) { console.warn('[Admin] SoussriDB introuvable.'); return; }

  const $ = (s, c) => (c || document).querySelector(s);
  const $$ = (s, c) => Array.from((c || document).querySelectorAll(s));
  const esc = (s) => String(s === undefined || s === null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  let unlocked = false;
  let activeTab = 'dash';
  let editingDish = null;
  let resaFilter = 'all';
  let dishSearch = '';

  function notify(msg, type) {
    if (global.SoussriApp && global.SoussriApp.toast) global.SoussriApp.toast(msg, type);
    else console.log('[Admin]', msg);
  }

  /* ======================================================================
     1. Construction du squelette de la modale
     ====================================================================== */
  const modal = document.createElement('div');
  modal.className = 'modal modal--admin';
  modal.id = 'adminModal';
  modal.setAttribute('role', 'dialog');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('aria-labelledby', 'adminTitle');
  modal.innerHTML = `
    <div class="modal__box admin">
      <header class="admin__head">
        <div>
          <h2 id="adminTitle">Base de données</h2>
          <p class="admin__sub">
            Moteur <b id="admEngine">—</b> · version <b id="admVersion">—</b> · <b id="admSize">—</b>
          </p>
        </div>
        <button class="modal__close" type="button" data-admin-close aria-label="Fermer l'administration">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </header>

      <!-- Écran de déverrouillage -->
      <div class="admin__lock" id="admLock">
        <div class="admin__lock-ico" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
        </div>
        <h3>Espace réservé à l'équipe</h3>
        <p>Saisissez le code d'accès pour gérer la base de données du restaurant.</p>
        <form id="admLockForm" novalidate>
          <div class="field">
            <label for="admCode">Code d'accès</label>
            <input type="password" id="admCode" autocomplete="off" placeholder="••••••••">
            <span class="err" data-err="admCode"></span>
          </div>
          <button class="btn btn--block" type="submit">Déverrouiller</button>
        </form>
        <p class="admin__hint">Démo : le code par défaut est <code>soussri2026</code></p>
      </div>

      <!-- Application d'administration -->
      <div class="admin__app" id="admApp" hidden>
        <nav class="admin__tabs" role="tablist" aria-label="Sections d'administration">
          <button role="tab" type="button" data-tab="dash"  aria-selected="true">Tableau de bord</button>
          <button role="tab" type="button" data-tab="dishes" aria-selected="false">Plats <span class="pill" id="pillDishes">0</span></button>
          <button role="tab" type="button" data-tab="resa"  aria-selected="false">Réservations <span class="pill" id="pillResa">0</span></button>
          <button role="tab" type="button" data-tab="users" aria-selected="false">Clients <span class="pill" id="pillUsers">0</span></button>
          <button role="tab" type="button" data-tab="msgs"  aria-selected="false">Messages <span class="pill" id="pillMsgs">0</span></button>
          <button role="tab" type="button" data-tab="data"  aria-selected="false">Données</button>
        </nav>
        <div class="admin__panel" id="admPanel" role="tabpanel" tabindex="0"></div>
      </div>
    </div>`;
  document.body.appendChild(modal);

  const panel = $('#admPanel', modal);
  const lockView = $('#admLock', modal);
  const appView = $('#admApp', modal);

  /* ======================================================================
     2. Ouverture / fermeture
     ====================================================================== */
  function open() {
    modal.classList.add('open');
    document.body.classList.add('is-locked');
    $('#admEngine', modal).textContent = DB.engine === 'indexeddb' ? 'IndexedDB' : 'LocalStorage';
    $('#admVersion', modal).textContent = 'v' + DB.version;
    $('#admSize', modal).textContent = '~' + DB.size() + ' Ko';
    if (unlocked) { render(); setTimeout(() => $('.admin__tabs button', modal).focus(), 60); }
    else setTimeout(() => $('#admCode', modal).focus(), 60);
  }
  function close() {
    modal.classList.remove('open');
    if (!$$('.modal.open').length) document.body.classList.remove('is-locked');
    if (location.hash === '#admin') { try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {} }
  }
  $('[data-admin-close]', modal).addEventListener('click', close);
  modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal.classList.contains('open')) close(); });

  /* ======================================================================
     3. Déverrouillage
     ====================================================================== */
  $('#admLockForm', modal).addEventListener('submit', (e) => {
    e.preventDefault();
    const input = $('#admCode', modal);
    const expected = DB.setting('adminCode', 'soussri2026');
    if (input.value !== expected) {
      $('[data-err="admCode"]', modal).textContent = 'Code incorrect. Réessayez.';
      input.setAttribute('aria-invalid', 'true');
      input.value = ''; input.focus();
      return;
    }
    unlocked = true;
    input.value = '';
    input.setAttribute('aria-invalid', 'false');
    $('[data-err="admCode"]', modal).textContent = '';
    lockView.hidden = true;
    appView.hidden = false;
    render();
    notify('Administration déverrouillée.', 'ok');
  });

  /* ======================================================================
     4. Navigation par onglets
     ====================================================================== */
  $('.admin__tabs', modal).addEventListener('click', (e) => {
    const b = e.target.closest('button[data-tab]'); if (!b) return;
    activeTab = b.dataset.tab;
    editingDish = null;
    $$('.admin__tabs button', modal).forEach(x => x.setAttribute('aria-selected', String(x === b)));
    render();
    panel.scrollTop = 0;
  });

  /* ======================================================================
     5. Rendu général
     ====================================================================== */
  function render() {
    const s = DB.stats();
    $('#pillDishes', modal).textContent = s.dishes;
    $('#pillResa', modal).textContent = s.reservations;
    $('#pillUsers', modal).textContent = s.users;
    $('#pillMsgs', modal).textContent = s.unread || s.messages;
    $('#admSize', modal).textContent = '~' + DB.size() + ' Ko';

    if (activeTab === 'dash') renderDash(s);
    else if (activeTab === 'dishes') renderDishes();
    else if (activeTab === 'resa') renderResa();
    else if (activeTab === 'users') renderUsers();
    else if (activeTab === 'msgs') renderMsgs();
    else renderData(s);
  }

  /* ---------------------- 5.1 Tableau de bord ---------------------- */
  function renderDash(s) {
    const maxBar = Math.max(1, ...s.upcoming.map(u => u.count));
    const cards = [
      { l: 'Plats à la carte', v: s.available + ' / ' + s.dishes, i: '🍽️' },
      { l: 'Réservations', v: s.reservations, i: '📅' },
      { l: 'Couverts attendus', v: s.covers, i: '👥' },
      { l: 'Panier moyen', v: s.avgPrice + ' DH', i: '💰' },
      { l: 'CA prévisionnel', v: s.revenue.toLocaleString('fr-FR') + ' DH', i: '📈' },
      { l: 'Comptes clients', v: s.users, i: '🧑' },
      { l: 'Messages non lus', v: s.unread, i: '✉️' },
      { l: 'Favoris enregistrés', v: s.favorites, i: '❤️' }
    ];

    const latest = DB.query('reservations', { sort: 'created', desc: true, limit: 5 });

    panel.innerHTML =
      '<div class="adm-cards">' + cards.map(c =>
        '<div class="adm-card"><span class="adm-card__ico" aria-hidden="true">' + c.i + '</span>' +
        '<b>' + esc(c.v) + '</b><span>' + c.l + '</span></div>').join('') + '</div>' +

      '<div class="adm-split">' +
        '<section class="adm-block"><h3>Réservations · 7 prochains jours</h3>' +
          '<div class="adm-chart">' + s.upcoming.map(u =>
            '<div class="adm-bar" title="' + u.count + ' réservation(s) le ' + u.iso + '">' +
              '<span class="adm-bar__val">' + u.count + '</span>' +
              '<i style="height:' + Math.round((u.count / maxBar) * 100) + '%"></i>' +
              '<span class="adm-bar__lbl">' + u.label + '<br>' + u.day + '</span>' +
            '</div>').join('') + '</div>' +
        '</section>' +

        '<section class="adm-block"><h3>Statuts</h3>' +
          '<ul class="adm-list">' +
            '<li><span class="dot-st confirmed"></span>Confirmées <b>' + (s.byStatus.confirmed || 0) + '</b></li>' +
            '<li><span class="dot-st pending"></span>En attente <b>' + (s.byStatus.pending || 0) + '</b></li>' +
            '<li><span class="dot-st cancelled"></span>Annulées <b>' + (s.byStatus.cancelled || 0) + '</b></li>' +
          '</ul>' +
          '<h3 style="margin-top:1.2rem">Plats par catégorie</h3>' +
          '<ul class="adm-list">' + Object.keys(s.byCat).map(k => {
            const cat = DB.get('categories', k);
            return '<li>' + esc(cat ? cat.label : k) + ' <b>' + s.byCat[k] + '</b></li>';
          }).join('') + '</ul>' +
        '</section>' +
      '</div>' +

      '<section class="adm-block"><h3>Dernières réservations</h3>' +
        (latest.length ? tableResa(latest, true) : '<p class="adm-empty">Aucune réservation enregistrée.</p>') +
      '</section>';
  }

  /* ---------------------- 5.2 Plats (CRUD) ---------------------- */
  function dishFormHTML(d) {
    const cats = DB.all('categories').filter(c => c.id !== 'all');
    return '<form class="adm-form" id="dishForm">' +
      '<h3>' + (d ? 'Modifier « ' + esc(d.name) + ' »' : 'Ajouter un plat') + '</h3>' +
      '<input type="hidden" id="dId" value="' + esc(d ? d.id : '') + '">' +
      '<div class="grid-2">' +
        '<div class="field"><label for="dName">Nom du plat *</label>' +
          '<input id="dName" required value="' + esc(d ? d.name : '') + '" placeholder="Plat Calamar"></div>' +
        '<div class="field"><label for="dCat">Catégorie *</label><select id="dCat">' +
          cats.map(c => '<option value="' + c.id + '"' + (d && d.cat === c.id ? ' selected' : '') + '>' + esc(c.label) + '</option>').join('') +
        '</select></div>' +
      '</div>' +
      '<div class="field"><label for="dNameAr">Nom en arabe (facultatif)</label>' +
        '<input id="dNameAr" lang="ar" dir="rtl" value="' + esc(d ? (d.nameAr || '') : '') + '" placeholder="صحن كلامار"></div>' +
      '<div class="grid-2">' +
        '<div class="field"><label for="dPrice">Prix (DH) *</label>' +
          '<input id="dPrice" type="number" min="0" step="5" required value="' + (d ? d.price : '') + '"></div>' +
        '<div class="field"><label for="dRating">Note (0 – 5)</label>' +
          '<input id="dRating" type="number" min="0" max="5" step="0.1" value="' + (d ? d.rating : '4.8') + '"></div>' +
      '</div>' +
      '<div class="field"><label for="dDesc">Description *</label>' +
        '<textarea id="dDesc" required placeholder="Ingrédients, cuisson, accompagnement…">' + esc(d ? d.desc : '') + '</textarea></div>' +
      '<div class="field"><label for="dImg">URL de l\'image</label>' +
        '<input id="dImg" value="' + esc(d ? d.img : '') + '" placeholder="images/mon-plat.jpg ou https://…"></div>' +
      '<div class="grid-2">' +
        '<div class="field"><label for="dTags">Étiquettes (séparées par une virgule)</label>' +
          '<input id="dTags" value="' + esc(d ? (d.tags || []).join(', ') : '') + '" placeholder="Signature, Végan"></div>' +
        '<div class="field"><label for="dSpicy">Niveau de piment (0 – 3)</label>' +
          '<input id="dSpicy" type="number" min="0" max="3" step="1" value="' + (d ? (d.spicy || 0) : 0) + '"></div>' +
      '</div>' +
      '<label class="adm-check"><input type="checkbox" id="dAvail"' + (!d || d.available !== false ? ' checked' : '') + '> Visible sur le site</label>' +
      '<div class="adm-actions">' +
        '<button class="btn" type="submit">' + (d ? 'Enregistrer les modifications' : 'Ajouter à la carte') + '</button>' +
        (d ? '<button class="btn btn--ghost" type="button" id="dCancel">Annuler</button>' : '') +
      '</div>' +
    '</form>';
  }

  function renderDishes() {
    const rows = DB.query('dishes', { search: dishSearch, sort: 'name' });
    panel.innerHTML =
      dishFormHTML(editingDish) +
      '<section class="adm-block">' +
        '<div class="adm-block__head"><h3>Carte (' + rows.length + ')</h3>' +
          '<input class="adm-search" id="dishSearch" type="search" placeholder="Filtrer les plats…" value="' + esc(dishSearch) + '"></div>' +
        (rows.length ? '<div class="adm-table-wrap"><table class="adm-table">' +
          '<thead><tr><th scope="col">Plat</th><th scope="col">Catégorie</th><th scope="col">Prix</th><th scope="col">Statut</th><th scope="col">Actions</th></tr></thead><tbody>' +
          rows.map(d => {
            const cat = DB.get('categories', d.cat);
            return '<tr>' +
              '<td><div class="adm-thumb"><img src="' + esc(d.img) + '" alt="" loading="lazy" width="46" height="40">' +
                '<div><b>' + esc(d.name) + '</b>' +
                  (d.nameAr ? '<small class="ar" lang="ar" dir="rtl">' + esc(d.nameAr) + '</small>' : '') +
                  '<small>' + esc((d.tags || []).join(' · ')) + '</small></div></div></td>' +
              '<td>' + esc(cat ? cat.label : d.cat) + '</td>' +
              '<td class="num">' + d.price + ' DH</td>' +
              '<td><span class="st ' + (d.available !== false ? 'confirmed' : 'cancelled') + '">' +
                (d.available !== false ? 'En ligne' : 'Masqué') + '</span></td>' +
              '<td class="adm-row-actions">' +
                '<button class="btn btn--ghost btn--sm" data-edit="' + esc(d.id) + '">Modifier</button>' +
                '<button class="btn btn--ghost btn--sm" data-toggle="' + esc(d.id) + '">' + (d.available !== false ? 'Masquer' : 'Afficher') + '</button>' +
                '<button class="btn btn--ghost btn--sm danger" data-del-dish="' + esc(d.id) + '">Supprimer</button>' +
              '</td></tr>';
          }).join('') + '</tbody></table></div>'
          : '<p class="adm-empty">Aucun plat ne correspond à ce filtre.</p>') +
      '</section>';
  }

  /* ---------------------- 5.3 Réservations ---------------------- */
  function tableResa(rows, compact) {
    return '<div class="adm-table-wrap"><table class="adm-table">' +
      '<thead><tr><th scope="col">Réf.</th><th scope="col">Client</th><th scope="col">Date</th>' +
      '<th scope="col">Pers.</th><th scope="col">Salle</th><th scope="col">Statut</th>' +
      (compact ? '' : '<th scope="col">Actions</th>') + '</tr></thead><tbody>' +
      rows.map(r => '<tr>' +
        '<td><span class="ref">' + esc(r.ref) + '</span></td>' +
        '<td><b>' + esc(r.name) + '</b><br><small>' + esc(r.phone || r.email || '') + '</small></td>' +
        '<td>' + esc(r.date) + '<br><small>' + esc(r.time) + '</small></td>' +
        '<td class="num">' + esc(r.guests) + '</td>' +
        '<td><small>' + esc(r.area || '—') + '</small></td>' +
        '<td><span class="st ' + esc(r.status || 'confirmed') + '">' + statusLabel(r.status) + '</span></td>' +
        (compact ? '' : '<td class="adm-row-actions">' +
          '<button class="btn btn--ghost btn--sm" data-st="confirmed" data-ref="' + esc(r.ref) + '">Confirmer</button>' +
          '<button class="btn btn--ghost btn--sm" data-st="pending" data-ref="' + esc(r.ref) + '">Attente</button>' +
          '<button class="btn btn--ghost btn--sm" data-st="cancelled" data-ref="' + esc(r.ref) + '">Annuler</button>' +
          '<button class="btn btn--ghost btn--sm danger" data-del-resa="' + esc(r.ref) + '">Suppr.</button></td>') +
      '</tr>').join('') + '</tbody></table></div>';
  }
  function statusLabel(s) {
    return s === 'pending' ? 'En attente' : s === 'cancelled' ? 'Annulée' : 'Confirmée';
  }

  function renderResa() {
    let rows = DB.query('reservations', { sort: 'date' });
    if (resaFilter !== 'all') rows = rows.filter(r => (r.status || 'confirmed') === resaFilter);

    panel.innerHTML =
      '<section class="adm-block">' +
        '<div class="adm-block__head"><h3>Réservations (' + rows.length + ')</h3>' +
          '<div class="adm-filters">' +
            ['all', 'confirmed', 'pending', 'cancelled'].map(f =>
              '<button class="cat" type="button" data-filter="' + f + '" aria-selected="' + (resaFilter === f) + '">' +
              (f === 'all' ? 'Toutes' : statusLabel(f)) + '</button>').join('') +
            '<button class="btn btn--sm" type="button" id="csvBtn">Exporter CSV</button>' +
          '</div></div>' +
        (rows.length ? tableResa(rows, false) : '<p class="adm-empty">Aucune réservation dans cette vue.</p>') +
      '</section>';
  }

  /* ---------------------- 5.4 Clients ---------------------- */
  function renderUsers() {
    const rows = DB.query('users', { sort: 'since', desc: true });
    panel.innerHTML = '<section class="adm-block"><h3>Comptes clients (' + rows.length + ')</h3>' +
      (rows.length ? '<div class="adm-table-wrap"><table class="adm-table">' +
        '<thead><tr><th scope="col">Nom</th><th scope="col">E-mail</th><th scope="col">Inscription</th><th scope="col">Actions</th></tr></thead><tbody>' +
        rows.map(u => '<tr>' +
          '<td><div class="adm-thumb"><span class="adm-av">' + esc(u.name.charAt(0).toUpperCase()) + '</span><b>' + esc(u.name) + '</b></div></td>' +
          '<td>' + esc(u.email) + '</td>' +
          '<td>' + new Date(u.since).toLocaleDateString('fr-FR') + '</td>' +
          '<td class="adm-row-actions"><button class="btn btn--ghost btn--sm danger" data-del-user="' + esc(u.email) + '">Supprimer</button></td>' +
        '</tr>').join('') + '</tbody></table></div>'
        : '<p class="adm-empty">Aucun compte créé pour l\'instant. Utilisez « Inscription » sur le site.</p>') +
      '</section>';
  }

  /* ---------------------- 5.5 Messages ---------------------- */
  function renderMsgs() {
    const rows = DB.query('messages', { sort: 'at', desc: true });
    panel.innerHTML = '<section class="adm-block"><h3>Messages reçus (' + rows.length + ')</h3>' +
      (rows.length ? '<ul class="adm-msgs">' + rows.map(m =>
        '<li class="adm-msg' + (m.read ? ' is-read' : '') + '">' +
          '<div class="adm-msg__head"><b>' + esc(m.name) + '</b>' +
            '<a href="mailto:' + esc(m.email) + '">' + esc(m.email) + '</a>' +
            '<time>' + new Date(m.at).toLocaleString('fr-FR') + '</time></div>' +
          '<p>' + esc(m.msg) + '</p>' +
          '<div class="adm-row-actions">' +
            '<button class="btn btn--ghost btn--sm" data-read="' + esc(m.id) + '">' + (m.read ? 'Marquer non lu' : 'Marquer lu') + '</button>' +
            '<button class="btn btn--ghost btn--sm danger" data-del-msg="' + esc(m.id) + '">Supprimer</button>' +
          '</div></li>').join('') + '</ul>'
        : '<p class="adm-empty">Aucun message. Le formulaire de contact alimente cette boîte.</p>') +
      '</section>';
  }

  /* ---------------------- 5.6 Données ---------------------- */
  function renderData(s) {
    panel.innerHTML =
      '<div class="adm-split">' +
        '<section class="adm-block"><h3>État de la base</h3>' +
          '<ul class="adm-list">' +
            '<li>Moteur de stockage <b>' + (DB.engine === 'indexeddb' ? 'IndexedDB' : 'LocalStorage') + '</b></li>' +
            '<li>Version du schéma <b>v' + DB.version + '</b></li>' +
            '<li>Source d\'amorçage <b>' + esc(DB.source) + '</b></li>' +
            '<li>Taille estimée <b>~' + DB.size() + ' Ko</b></li>' +
            '<li>Installée le <b>' + new Date(DB.setting('installedAt', Date.now())).toLocaleDateString('fr-FR') + '</b></li>' +
          '</ul>' +
          '<h3 style="margin-top:1.2rem">Collections</h3>' +
          '<ul class="adm-list">' + DB.collections.map(c =>
            '<li>' + c + ' <b>' + DB.count(c) + '</b></li>').join('') + '</ul>' +
          '<h3 style="margin-top:1.2rem">Tables du dossier <code>/database/</code></h3>' +
          '<p class="adm-note">Recharge la carte, la galerie, l\'équipe et les avis depuis les fichiers JSON du dépôt. ' +
            'Vos réservations, comptes clients et messages sont conservés.</p>' +
          '<button class="btn btn--sm" type="button" id="reloadBtn">Recharger depuis /database/</button>' +
        '</section>' +

        '<section class="adm-block"><h3>Sauvegarde &amp; restauration</h3>' +
          '<p class="adm-note">Exportez la totalité de la base dans un fichier JSON, puis réimportez-le sur un autre appareil ou après une réinitialisation.</p>' +
          '<div class="adm-actions">' +
            '<button class="btn" type="button" id="expBtn">Exporter la base (JSON)</button>' +
            '<button class="btn btn--ghost" type="button" id="impBtn">Importer un fichier</button>' +
            '<input type="file" id="impFile" accept="application/json,.json" hidden>' +
          '</div>' +
          '<h3 style="margin-top:1.4rem">Code d\'accès administrateur</h3>' +
          '<form id="codeForm"><div class="field">' +
            '<label for="newCode">Nouveau code (4 caractères min.)</label>' +
            '<input id="newCode" type="text" placeholder="Nouveau code d\'accès"></div>' +
            '<button class="btn btn--sm" type="submit">Mettre à jour le code</button></form>' +
          '<h3 style="margin-top:1.4rem">Zone sensible</h3>' +
          '<p class="adm-note">La réinitialisation efface réservations, clients, messages et favoris, puis restaure la carte d\'origine depuis <code>js/data.js</code>.</p>' +
          '<button class="btn btn--ghost danger" type="button" id="resetBtn">Réinitialiser la base</button>' +
        '</section>' +
      '</div>';
  }

  /* ======================================================================
     6. Délégation d'évènements du panneau
     ====================================================================== */
  panel.addEventListener('input', (e) => {
    if (e.target.id === 'dishSearch') {
      dishSearch = e.target.value;
      const pos = e.target.selectionStart;
      renderDishes();
      const el = $('#dishSearch', panel);
      if (el) { el.focus(); el.setSelectionRange(pos, pos); }
    }
  });

  panel.addEventListener('submit', (e) => {
    /* --- Formulaire plat (création / édition) --- */
    if (e.target.id === 'dishForm') {
      e.preventDefault();
      const id = $('#dId', panel).value.trim();
      const name = $('#dName', panel).value.trim();
      const price = parseFloat($('#dPrice', panel).value);
      const desc = $('#dDesc', panel).value.trim();
      if (name.length < 2 || isNaN(price) || desc.length < 5) {
        notify('Nom, prix et description sont obligatoires.', 'err');
        return;
      }
      const dish = {
        id: id || DB.uid('dish'),
        cat: $('#dCat', panel).value,
        name: name,
        nameAr: $('#dNameAr', panel).value.trim(),
        desc: desc,
        price: price,
        rating: Math.min(5, Math.max(0, parseFloat($('#dRating', panel).value) || 4.8)),
        spicy: Math.min(3, Math.max(0, parseInt($('#dSpicy', panel).value, 10) || 0)),
        tags: $('#dTags', panel).value.split(',').map(t => t.trim()).filter(Boolean),
        img: $('#dImg', panel).value.trim() || 'images/placeholder.svg',
        available: $('#dAvail', panel).checked
      };
      DB.put('dishes', dish).then(() => {
        editingDish = null;
        render();
        refreshSite();
        notify(id ? 'Plat mis à jour.' : 'Plat ajouté à la carte.', 'ok');
      });
      return;
    }

    /* --- Changement du code admin --- */
    if (e.target.id === 'codeForm') {
      e.preventDefault();
      const v = $('#newCode', panel).value.trim();
      if (v.length < 4) { notify('Le code doit contenir au moins 4 caractères.', 'err'); return; }
      DB.setSetting('adminCode', v);
      $('#newCode', panel).value = '';
      notify('Code d\'accès mis à jour.', 'ok');
    }
  });

  panel.addEventListener('click', (e) => {
    const t = e.target.closest('button'); if (!t) return;

    /* ---- Plats ---- */
    if (t.dataset.edit) {
      editingDish = DB.get('dishes', t.dataset.edit);
      renderDishes();
      panel.scrollTop = 0;
      $('#dName', panel).focus();
      return;
    }
    if (t.id === 'dCancel') { editingDish = null; renderDishes(); return; }
    if (t.dataset.toggle) {
      const d = DB.get('dishes', t.dataset.toggle);
      DB.put('dishes', { id: d.id, available: d.available === false }).then(() => {
        render(); refreshSite();
        notify(d.available === false ? 'Plat remis en ligne.' : 'Plat masqué du site.');
      });
      return;
    }
    if (t.dataset.delDish) {
      const d = DB.get('dishes', t.dataset.delDish);
      if (!confirm('Supprimer définitivement « ' + d.name + ' » de la base ?')) return;
      DB.remove('dishes', d.id).then(() => { render(); refreshSite(); notify('Plat supprimé.'); });
      return;
    }

    /* ---- Réservations ---- */
    if (t.dataset.filter) { resaFilter = t.dataset.filter; renderResa(); return; }
    if (t.dataset.st && t.dataset.ref) {
      DB.put('reservations', { ref: t.dataset.ref, status: t.dataset.st }).then(() => {
        render(); refreshSite();
        notify('Réservation ' + t.dataset.ref + ' : ' + statusLabel(t.dataset.st).toLowerCase() + '.', 'ok');
      });
      return;
    }
    if (t.dataset.delResa) {
      if (!confirm('Supprimer la réservation ' + t.dataset.delResa + ' ?')) return;
      DB.remove('reservations', t.dataset.delResa).then(() => { render(); refreshSite(); notify('Réservation supprimée.'); });
      return;
    }
    if (t.id === 'csvBtn') { exportCSV(); return; }

    /* ---- Clients ---- */
    if (t.dataset.delUser) {
      if (!confirm('Supprimer le compte ' + t.dataset.delUser + ' ?')) return;
      DB.remove('users', t.dataset.delUser).then(() => {
        if (DB.setting('session') === t.dataset.delUser) DB.delSetting('session');
        render(); refreshSite(); notify('Compte supprimé.');
      });
      return;
    }

    /* ---- Messages ---- */
    if (t.dataset.read) {
      const m = DB.get('messages', t.dataset.read);
      DB.put('messages', { id: m.id, read: !m.read }).then(() => render());
      return;
    }
    if (t.dataset.delMsg) {
      DB.remove('messages', t.dataset.delMsg).then(() => { render(); notify('Message supprimé.'); });
      return;
    }

    /* ---- Données ---- */
    if (t.id === 'expBtn') { download('soussri-db-' + new Date().toISOString().slice(0, 10) + '.json', DB.exportJSON(), 'application/json'); notify('Base exportée.', 'ok'); return; }
    if (t.id === 'impBtn') { $('#impFile', panel).click(); return; }
    if (t.id === 'reloadBtn') {
      t.disabled = true; t.textContent = 'Chargement…';
      DB.reloadFromFiles().then(src => {
        render(); refreshSite();
        notify('Tables rechargées depuis ' + src + '.', 'ok');
      }).catch(() => { render(); notify('Impossible de lire /database/ (ouvrez le site via un serveur).', 'err'); });
      return;
    }
    if (t.id === 'resetBtn') {
      if (!confirm('Réinitialiser toute la base ? Réservations, comptes et messages seront perdus.')) return;
      DB.reset().then(() => { render(); refreshSite(); notify('Base réinitialisée depuis data.js.', 'ok'); });
    }
  });

  panel.addEventListener('change', (e) => {
    if (e.target.id !== 'impFile' || !e.target.files.length) return;
    const reader = new FileReader();
    reader.onload = () => {
      DB.importJSON(reader.result)
        .then(cols => { render(); refreshSite(); notify('Import réussi : ' + cols.length + ' collection(s).', 'ok'); })
        .catch(err => notify(err.message, 'err'));
    };
    reader.readAsText(e.target.files[0]);
  });

  /* ======================================================================
     7. Utilitaires
     ====================================================================== */
  function download(filename, content, mime) {
    const blob = new Blob([content], { type: mime + ';charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function exportCSV() {
    const rows = DB.query('reservations', { sort: 'date' });
    if (!rows.length) { notify('Aucune réservation à exporter.', 'err'); return; }
    const head = ['Reference', 'Nom', 'Telephone', 'Email', 'Date', 'Heure', 'Convives', 'Salle', 'Statut', 'Notes'];
    const cell = (v) => '"' + String(v === undefined || v === null ? '' : v).replace(/"/g, '""') + '"';
    const csv = '\uFEFF' + head.join(';') + '\n' + rows.map(r =>
      [r.ref, r.name, r.phone, r.email, r.date, r.time, r.guests, r.area, statusLabel(r.status), r.notes].map(cell).join(';')
    ).join('\n');
    download('reservations-soussri.csv', csv, 'text/csv');
    notify('Export CSV téléchargé.', 'ok');
  }

  /** Rafraîchit l'interface publique après une modification en base. */
  function refreshSite() {
    DB.refreshView();
    if (global.SoussriApp && global.SoussriApp.refreshAll) global.SoussriApp.refreshAll();
  }

  /* ======================================================================
     8. Points d'entrée : bouton d'en-tête + route #admin
     ====================================================================== */
  function bindTrigger() {
    const btn = document.getElementById('adminBtn');
    if (btn) btn.addEventListener('click', open);
    $$('[data-open-admin]').forEach(b => b.addEventListener('click', open));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bindTrigger);
  else bindTrigger();

  function checkHash() { if (location.hash === '#admin') open(); }
  window.addEventListener('hashchange', checkHash);
  DB.ready().then(checkHash);

  global.SoussriAdmin = { open: open, close: close, refresh: render };
})(window);
