/* ==========================================================================
   Restaurant Soussri Salé — data.js
   --------------------------------------------------------------------------
   COPIE DE REPLI des tables du dossier /database/.
   Utilisée uniquement si fetch() est indisponible (ouverture en file://).
   La source de vérité reste /database/*.json.

   Carte : menu officiel « Snack Souiri — Spécialité Poisson », prix en DH.
   ========================================================================== */
(function (global) {
  'use strict';

  /* --------------------------------------------------------------------
     1. Informations de l'établissement  (miroir de restaurant.json)
     -------------------------------------------------------------------- */
  const INFO = {
    name: 'Restaurant Soussri Salé',
    tagline: 'Spécialité poisson — friture, grillades et tajines de la mer',
    since: 1998,
    address: '12 Avenue Hassan II, Bab Lamrissa, Salé 11000, Maroc',
    phone: '+212 5 37 88 12 40',
    phoneHref: '+212537881240',
    // Numéro WhatsApp du restaurant — format international sans « + » (wa.me)
    // C'est sur ce numéro que sont envoyées les demandes de réservation.
    whatsapp: '212672297256',
    whatsappDisplay: '+212 672-297256',
    bookingsToWhatsApp: true, // false = désactive l'envoi automatique
    email: 'contact@soussri-sale.ma',
    currency: 'DH',
    mapsEmbed:
      'https://www.google.com/maps?q=Bab+Lamrissa,+Sal%C3%A9,+Morocco&output=embed',
    mapsLink: 'https://www.google.com/maps/search/?api=1&query=Bab+Lamrissa+Sal%C3%A9+Maroc',
    social: [
      { name: 'Facebook', url: 'https://facebook.com', icon: 'facebook' },
      { name: 'Instagram', url: 'https://instagram.com', icon: 'instagram' },
      { name: 'TripAdvisor', url: 'https://tripadvisor.com', icon: 'tripadvisor' },
      { name: 'YouTube', url: 'https://youtube.com', icon: 'youtube' }
    ],
    hours: [
      { day: 'Lundi — Jeudi', time: '12:00 – 23:00' },
      { day: 'Vendredi', time: '14:00 – 23:30' },
      { day: 'Samedi', time: '12:00 – 00:30' },
      { day: 'Dimanche', time: '12:00 – 23:00' },
      { day: 'Ramadan', time: 'Ftour – 02:00' }
    ]
  };

  /* --------------------------------------------------------------------
     2. Catégories du menu  (miroir de categories.json)
     -------------------------------------------------------------------- */
  const CATEGORIES = [
    { id: 'all',             label: 'Tout le menu',               icon: '✦' },
    { id: 'poissons',        label: 'Poissons & Fruits de mer',   icon: '🐟' },
    { id: 'tajines',         label: 'Tajines',                    icon: '🍲' },
    { id: 'accompagnements', label: 'Accompagnements',            icon: '🥗' },
    { id: 'boissons',        label: 'Boissons',                   icon: '🥤' }
  ];

  /* --------------------------------------------------------------------
     3. La carte  (miroir de dishes.json) — prix en DH
     -------------------------------------------------------------------- */
  const MENU = [
    /* ---- Poissons & fruits de mer ---- */
    {
      id: 'p1', cat: 'poissons', name: 'Friture de Poisson', nameAr: 'صحن سمك',
      desc: 'Merlan, sole, crevette et calamar frits minute, servis bien croustillants avec citron.',
      price: 70, tags: ['Signature', 'Best-seller'], rating: 4.9, spicy: 0,
      img: 'https://images.pexels.com/photos/4869334/pexels-photo-4869334.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'p2', cat: 'poissons', name: 'Poissons grillés', nameAr: 'سمك مشوي',
      desc: 'Poisson frais du jour grillé au charbon de bois, sel de mer et citron beldi.',
      price: 90, tags: ['Charbon', 'Pêche du jour'], rating: 5.0, spicy: 0,
      img: 'https://images.pexels.com/photos/36378583/pexels-photo-36378583.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'p3', cat: 'poissons', name: 'Plat Calamar', nameAr: 'صحن كلامار',
      desc: 'Calamars tendres préparés à la façon du snack, accompagnés de frites et de sauce maison.',
      price: 70, tags: ['Populaire'], rating: 4.8, spicy: 0,
      img: 'https://images.pexels.com/photos/5041489/pexels-photo-5041489.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'p4', cat: 'poissons', name: 'Plat Crevette', nameAr: 'صحن قمرون',
      desc: 'Crevettes fraîches préparées à la demande, ail et persil, servies bien chaudes.',
      price: 70, tags: ['Populaire'], rating: 4.8, spicy: 0,
      img: 'https://images.pexels.com/photos/37215013/pexels-photo-37215013.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'p5', cat: 'poissons', name: 'Plat Calamar Crevette', nameAr: 'صحن كلامار ـ قمرون',
      desc: 'Le duo de la maison : calamars et crevettes dans une même assiette généreuse.',
      price: 60, tags: ['Mixte', 'Bon plan'], rating: 4.9, spicy: 0,
      img: 'https://images.pexels.com/photos/20067063/pexels-photo-20067063.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },

    /* ---- Tajines ---- */
    {
      id: 't1', cat: 'tajines', name: 'Tajine Poissons', nameAr: 'طاجين حوت',
      desc: 'Poisson mijoté à la chermoula avec tomates, poivrons et pommes de terre.',
      price: 50, tags: ['Signature', 'Mijoté'], rating: 4.9, spicy: 1,
      img: 'https://images.pexels.com/photos/2291603/pexels-photo-2291603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 't2', cat: 'tajines', name: 'Tajine Kefta Sardine', nameAr: 'طاجين كفتة سردين',
      desc: 'Boulettes de sardine hachée aux épices, mijotées dans une sauce tomate parfumée.',
      price: 30, tags: ['Spécialité', 'Bon plan'], rating: 4.8, spicy: 1,
      img: 'https://images.pexels.com/photos/2287528/pexels-photo-2287528.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },

    /* ---- Accompagnements ---- */
    {
      id: 'a1', cat: 'accompagnements', name: 'Plat Riz', nameAr: 'صحن روز',
      desc: 'Riz parfumé préparé maison, l\'accompagnement idéal du poisson.',
      price: 20, tags: ['Accompagnement'], rating: 4.6, spicy: 0,
      img: 'https://images.pexels.com/photos/5041489/pexels-photo-5041489.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'a2', cat: 'accompagnements', name: 'Plat Lentille', nameAr: 'صحن عدس',
      desc: 'Lentilles mijotées aux épices douces. Disponible à emporter.',
      price: 10, tags: ['À emporter', 'Végan'], rating: 4.7, spicy: 0,
      img: 'https://images.pexels.com/photos/2291596/pexels-photo-2291596.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'a3', cat: 'accompagnements', name: 'Plat Loubia', nameAr: 'صحن لوبيا',
      desc: 'Haricots blancs mijotés à la tomate et à l\'ail, un classique marocain. À emporter.',
      price: 10, tags: ['À emporter', 'Végan'], rating: 4.7, spicy: 0,
      img: 'https://images.pexels.com/photos/2291602/pexels-photo-2291602.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'a4', cat: 'accompagnements', name: 'Plat Tktouka', nameAr: 'صحن تكتوكة',
      desc: 'Poivrons grillés et tomates fondues à l\'huile d\'olive, servis tièdes ou froids.',
      price: 10, tags: ['Végan'], rating: 4.6, spicy: 0,
      img: 'https://images.pexels.com/photos/2287524/pexels-photo-2287524.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'a5', cat: 'accompagnements', name: 'Salade', nameAr: 'سلطة',
      desc: 'Salade marocaine fraîche : tomates, concombre, oignon et herbes du jour.',
      price: 10, tags: ['Frais', 'Végan'], rating: 4.6, spicy: 0,
      img: 'https://images.pexels.com/photos/24205807/pexels-photo-24205807.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'a6', cat: 'accompagnements', name: 'Olives', nameAr: 'زيتون',
      desc: 'Olives marocaines marinées, à grignoter en attendant le poisson.',
      price: 10, tags: ['Végan'], rating: 4.5, spicy: 0,
      img: 'https://images.pexels.com/photos/2291596/pexels-photo-2291596.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },

    /* ---- Boissons ---- */
    {
      id: 'b1', cat: 'boissons', name: 'Boisson Grande', nameAr: 'مشروب كبيرة',
      desc: 'Boisson gazeuse ou jus, grand format bien frais.',
      price: 10, tags: ['Frais'], rating: 4.5, spicy: 0,
      img: 'https://images.pexels.com/photos/31497982/pexels-photo-31497982.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'b2', cat: 'boissons', name: 'Boisson Petite', nameAr: 'مشروب صغيرة',
      desc: 'Boisson gazeuse ou jus, petit format.',
      price: 8, tags: ['Frais', 'Bon plan'], rating: 4.5, spicy: 0,
      img: 'https://images.pexels.com/photos/30921221/pexels-photo-30921221.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    },
    {
      id: 'b3', cat: 'boissons', name: 'Eau Minérale', nameAr: 'ماء معدني',
      desc: 'Bouteille d\'eau minérale fraîche.',
      price: 10, tags: ['Frais'], rating: 4.6, spicy: 0,
      img: 'https://images.pexels.com/photos/30906049/pexels-photo-30906049.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200'
    }
  ];

  /* --------------------------------------------------------------------
     4. Diaporama du hero
     -------------------------------------------------------------------- */
  const HERO_SLIDES = [
    'https://images.pexels.com/photos/4869334/pexels-photo-4869334.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1900',
    'https://images.pexels.com/photos/36378583/pexels-photo-36378583.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1900',
    'https://images.pexels.com/photos/7556764/pexels-photo-7556764.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1900',
    'https://images.pexels.com/photos/20067063/pexels-photo-20067063.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1900'
  ];

  /* --------------------------------------------------------------------
     5. Galerie (lightbox)
     -------------------------------------------------------------------- */
  const GALLERY = [
    { src: 'https://images.pexels.com/photos/4869334/pexels-photo-4869334.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400', alt: 'Friture de poisson servie en plateau', cap: 'La friture de poisson', size: 'wide' },
    { src: 'https://images.pexels.com/photos/36378583/pexels-photo-36378583.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900', alt: 'Poisson entier grillé aux herbes', cap: 'Poisson grillé', size: 'tall' },
    { src: 'https://images.pexels.com/photos/20067063/pexels-photo-20067063.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900', alt: 'Plat de calamars et crevettes', cap: 'Calamar & crevette', size: '' },
    { src: 'https://images.pexels.com/photos/7391598/pexels-photo-7391598.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900', alt: 'Décor marocain aux mosaïques zellige', cap: 'La salle', size: 'tall' },
    { src: 'https://images.pexels.com/photos/2291603/pexels-photo-2291603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900', alt: 'Tajine de poisson à la chermoula', cap: 'Tajine de poisson', size: '' },
    { src: 'https://images.pexels.com/photos/37307308/pexels-photo-37307308.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400', alt: 'Terrasse dressée avec vue', cap: 'La terrasse', size: 'wide' },
    { src: 'https://images.pexels.com/photos/37215013/pexels-photo-37215013.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900', alt: 'Crevettes grillées servies avec riz', cap: 'Plat crevette', size: '' },
    { src: 'https://images.pexels.com/photos/24205807/pexels-photo-24205807.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900', alt: 'Salades et entrées marocaines', cap: 'Salade & tktouka', size: '' },
    { src: 'https://images.pexels.com/photos/38147593/pexels-photo-38147593.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=900', alt: 'Intérieur marocain traditionnel', cap: 'L\'ambiance', size: 'tall' },
    { src: 'https://images.pexels.com/photos/5041489/pexels-photo-5041489.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900', alt: 'Assiette de riz aux fruits de mer', cap: 'Plat riz', size: '' },
    { src: 'https://images.pexels.com/photos/2287528/pexels-photo-2287528.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=900', alt: 'Tajine que l\'on découvre à table', cap: 'Tajine kefta sardine', size: '' },
    { src: 'https://images.pexels.com/photos/10573397/pexels-photo-10573397.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400', alt: 'Patio marocain avec bassin', cap: 'Le patio', size: 'wide' }
  ];

  /* --------------------------------------------------------------------
     6. Avis clients
     -------------------------------------------------------------------- */
  const TESTIMONIALS = [
    { name: 'Yasmine El Fassi', role: 'Rabat, Maroc', stars: 5, initials: 'YE',
      text: 'La friture de poisson à 70 DH est imbattable : merlan, sole, crevette et calamar, tout est frais et croustillant. On revient chaque semaine.' },
    { name: 'Thomas Lefèvre', role: 'Lyon, France', stars: 5, initials: 'TL',
      text: 'Découvert par hasard à Salé. Le poisson grillé au charbon est parfait et les prix sont très honnêtes. Une adresse authentique, sans chichi.' },
    { name: 'Amine Berrada', role: 'Casablanca, Maroc', stars: 5, initials: 'AB',
      text: 'Le tajine kefta sardine à 30 DH est une pépite. J\'y emmène tous mes collègues, personne n\'est jamais déçu.' },
    { name: 'Sofia Rinaldi', role: 'Milan, Italie', stars: 4, initials: 'SR',
      text: 'Service rapide et poisson d\'une grande fraîcheur. Le plat calamar-crevette à 60 DH est le meilleur rapport qualité-prix de la ville.' },
    { name: 'Karima Ouazzani', role: 'Salé, Maroc', stars: 5, initials: 'KO',
      text: 'Habituée depuis des années. Les lentilles et la loubia à emporter dépannent toute la famille, et le poisson reste toujours impeccable.' },
    { name: 'David Okoro', role: 'Londres, Royaume-Uni', stars: 5, initials: 'DO',
      text: 'Fresh fish, generous portions and unbeatable prices. The mixed calamari and shrimp plate is a must — booked my table on WhatsApp in seconds.' }
  ];

  /* --------------------------------------------------------------------
     7. Équipe
     -------------------------------------------------------------------- */
  const TEAM = [
    { name: 'Chef Rachid Soussri', role: 'Chef fondateur', img: 'https://images.pexels.com/photos/36378583/pexels-photo-36378583.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=700', bio: 'Il choisit lui-même le poisson au port chaque matin, depuis 1998.' },
    { name: 'Dada Fatima', role: 'Reine des tajines', img: 'https://images.pexels.com/photos/2291603/pexels-photo-2291603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=700', bio: 'Sa chermoula et sa kefta de sardine font la réputation de la maison.' },
    { name: 'Youssef Bennani', role: 'Maître de la friture', img: 'https://images.pexels.com/photos/4869334/pexels-photo-4869334.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=700', bio: 'Vingt ans de tour de main pour une friture toujours dorée et jamais grasse.' }
  ];

  /* --------------------------------------------------------------------
     8. Chiffres clés (compteurs animés)
     -------------------------------------------------------------------- */
  const STATS = [
    { value: 27, suffix: '+', label: 'Années de savoir-faire' },
    { value: 16, suffix: '', label: 'Plats à la carte' },
    { value: 120, suffix: 'k', label: 'Convives accueillis' },
    { value: 49, suffix: '/5', label: 'Note moyenne', decimal: true }
  ];

  global.SOUSSRI_DATA = { INFO, CATEGORIES, MENU, HERO_SLIDES, GALLERY, TESTIMONIALS, TEAM, STATS };
})(window);
