# Restaurant Soussri Salé — Site vitrine statique

Site web professionnel, moderne et 100 % responsive pour un restaurant marocain
situé à Salé (Maroc). **HTML5 + CSS3 + JavaScript vanilla uniquement.**
Aucun framework, aucun backend, aucune base de données.

---

## 🚀 Démarrage

Ouvrez simplement **`index.html`** dans votre navigateur. C'est tout.

> Astuce : pour éviter tout blocage `file://` sur certains navigateurs, vous
> pouvez servir le dossier avec n'importe quel serveur statique
> (extension VS Code « Live Server », par exemple). Ce n'est pas obligatoire.

---

## 🗄️ La base de données

Le projet contient une **vraie base de données** en trois couches, sans aucun
serveur ni configuration.

```
  /database/*.json          js/db.js                  Navigateur
 ┌──────────────┐      ┌──────────────────┐      ┌──────────────────┐
 │  Tables JSON │ ───► │ Chargement fetch │ ───► │    IndexedDB     │
 │  (le dépôt)  │      │   + amorçage     │      │  « soussri_db »  │
 └──────────────┘      └──────────────────┘      └────────┬─────────┘
                                                          │
        js/data.js  ◄── repli si fetch indisponible       ▼
                                              Site public + panneau admin
```

### 1️⃣ Les tables — dossier `/database/`

Le contenu éditorial vit dans des fichiers JSON versionnés avec le code :

| Fichier | Table | Contenu |
|---|---|---|
| `restaurant.json` | `restaurant` | Adresse, horaires, réseaux, chiffres clés, hero |
| `categories.json` | `categories` | 8 catégories du menu |
| `dishes.json` | `dishes` | La carte — 28 plats |
| `testimonials.json` | `testimonials` | Avis clients |
| `gallery.json` | `gallery` | Photos de la galerie |
| `team.json` | `team` | Équipe du restaurant |
| `schema.sql` | — | Schéma relationnel complet (11 tables, 3 vues) |

Pour modifier la carte, il suffit d'éditer `dishes.json` — aucun code à toucher.
Voir **[`database/README.md`](database/README.md)** pour le détail des champs.

### 2️⃣ Le moteur — `js/db.js`

| | |
|---|---|
| **Moteur** | **IndexedDB** (base native du navigateur), repli automatique sur LocalStorage |
| **Nom** | `soussri_db` · schéma v1 |
| **Collections** | `settings`, `categories`, `dishes`, `reservations`, `users`, `favorites`, `messages`, `testimonials`, `gallery`, `team` |
| **Amorçage** | `fetch()` sur `/database/*.json`, repli sur `js/data.js` |
| **Sauvegarde** | miroir LocalStorage + export/import JSON |

> ℹ️ En ouvrant `index.html` par **double-clic** (`file://`), les navigateurs
> bloquent `fetch()` : la base s'amorce alors depuis `js/data.js`, qui contient
> les mêmes données. **Le site fonctionne dans tous les cas.** Sur GitHub Pages,
> les fichiers `/database/` sont utilisés normalement.

### 3️⃣ Le schéma SQL — `database/schema.sql`

Non exécuté par le site (il n'y a pas de serveur), mais il documente les types,
clés primaires, clés étrangères, index et contraintes de chaque table — et
permet une **migration future** vers MySQL / MariaDB / PostgreSQL sans repenser
le modèle. Il inclut les vues `v_menu_public`, `v_dashboard` et
`v_upcoming_week`, équivalents SQL de `SoussriDB.stats()`.

### API (console du navigateur)

```js
await SoussriDB.ready();

SoussriDB.all('dishes');                       // toutes les lignes
SoussriDB.get('dishes', 't1');                 // une ligne par clé primaire
SoussriDB.query('dishes', {                    // requête façon mini-ORM
  where: d => d.price < 100, sort: 'price', desc: true, limit: 5
});
await SoussriDB.put('dishes', { id:'t9', name:'Tajine poulpe', cat:'mer', price:130, desc:'…' });
await SoussriDB.remove('reservations', 'SSR-A1B2C');
SoussriDB.stats();                             // agrégats du tableau de bord
SoussriDB.source;                              // "/database/*.json" ou "data.js"
await SoussriDB.reloadFromFiles();             // relit le dossier /database/
SoussriDB.exportJSON();                        // sauvegarde complète
await SoussriDB.reset();                       // réinitialisation depuis /database/
SoussriDB.on(e => console.log(e));             // écoute des changements
```

### 🛠️ Panneau d'administration

Bouton **« base de données »** dans l'en-tête, lien du pied de page, ou route
**`#admin`**. Code d'accès de démonstration : **`soussri2026`** (modifiable
dans l'onglet *Données*).

| Onglet | Contenu |
|---|---|
| **Tableau de bord** | 8 indicateurs (couverts, panier moyen, CA prévisionnel…), graphique des réservations sur 7 jours, répartition par statut et par catégorie |
| **Plats** | CRUD complet : ajout, édition, masquage, suppression, recherche |
| **Réservations** | Filtres par statut, passage confirmée / en attente / annulée, suppression, **export CSV** |
| **Clients** | Comptes créés via l'inscription, suppression |
| **Messages** | Boîte de réception du formulaire de contact, marquage lu/non lu |
| **Données** | Export & import JSON, taille de la base, changement du code, réinitialisation |

Toute modification faite dans l'admin se répercute **immédiatement** sur le site
public (carte, favoris, réservations) via `SoussriApp.refreshAll()`.

> ⚠️ La base vit dans le navigateur : elle est propre à chaque appareil et
> n'est pas partagée entre visiteurs. Utilisez **Export/Import JSON** pour
> transférer les données d'un poste à l'autre.

---

## 📁 Arborescence

```
/
├── index.html               Page unique (toutes les sections)
├── css/
│   └── style.css            Design system complet, thèmes clair/sombre + admin
├── js/
│   ├── data.js              Données d'amorçage (menu, galerie, avis, infos)
│   ├── db.js                Moteur de base de données IndexedDB + API
│   ├── admin.js             Panneau d'administration de la base
│   └── script.js            Toute l'interactivité du site public
├── database/                ⭐ LA BASE DE DONNÉES
│   ├── restaurant.json      Table « restaurant » (infos, horaires, réseaux)
│   ├── categories.json      Table « categories »
│   ├── dishes.json          Table « dishes » — la carte (28 plats)
│   ├── testimonials.json    Table « testimonials »
│   ├── gallery.json         Table « gallery »
│   ├── team.json            Table « team »
│   ├── schema.sql           Schéma relationnel (11 tables, 3 vues)
│   └── README.md            Documentation des tables et des champs
├── images/
│   ├── placeholder.svg      Illustration de repli
│   └── README.md            Comment utiliser vos propres photos
├── assets/
│   ├── favicon.svg          Favicon vectoriel
│   └── site.webmanifest     Manifeste PWA
├── sitemap.xml              Plan de site (SEO)
├── robots.txt               Directives crawlers
├── .nojekyll                Désactive Jekyll sur GitHub Pages
└── README.md
```

---

## ✨ Fonctionnalités

- **Barre de navigation sticky** avec état au scroll, lien actif automatique et
  tiroir mobile animé.
- **Hero** avec diaporama d'arrière-plan (effet Ken Burns), motif zellige animé
  et particules flottantes.
- **Section À propos** : histoire, valeurs, compteurs animés, équipe.
- **Menu interactif** : 8 catégories, recherche instantanée, notes, tags,
  niveaux de piment, **favoris persistants**.
- **Galerie en mosaïque** + **lightbox** (clavier ← → Échap, clic hors image).
- **Slider d'avis clients** : autoplay, points, flèches, swipe tactile.
- **Formulaire de réservation** → enregistré en base, avec liste
  « Mes réservations », référence unique et annulation.
- **📱 Envoi automatique sur WhatsApp** : à la validation du formulaire, la
  demande s'ouvre dans WhatsApp **pré-remplie** et adressée au restaurant
  (**+212 672-297256**). Le client n'a plus qu'à appuyer sur « Envoyer ».
  Une fenêtre de confirmation récapitule la réservation et propose un bouton
  de secours si le navigateur bloque l'ouverture automatique. Chaque
  réservation de la liste peut être renvoyée d'un clic.
- **Connexion / Inscription simulées** (LocalStorage), compte démo inclus,
  routes `#login` et `#signup`.
- **Contact** : coordonnées, réseaux sociaux, formulaire validé et **Google Maps**.
- **Bouton WhatsApp flottant**, **retour en haut**, **barre de progression**.
- **Mode sombre / clair** mémorisé (suit la préférence système au 1er passage).
- **Animation de chargement** avec sécurité anti-blocage.
- **Notifications toast** accessibles.

---

## ♿ Accessibilité (WCAG 2.1 AA)

- HTML sémantique (`header`, `nav`, `main`, `section`, `article`, `footer`).
- Lien d'évitement « Aller au contenu principal ».
- Tous les contrôles ont un `aria-label` / texte accessible ; états
  `aria-pressed`, `aria-selected`, `aria-current`, `aria-expanded`, `aria-invalid`.
- Piège de focus dans les modales, retour du focus à la fermeture, `Échap` ferme tout.
- Navigation clavier complète (galerie, slider, onglets, formulaires).
- Contrastes conformes en thème clair **et** sombre.
- Respect de `prefers-reduced-motion` et de `prefers-color-scheme`.
- Régions `aria-live` pour les résultats de recherche et les notifications.

---

## 🔍 SEO & performance

- Balises meta complètes, **Open Graph**, **Twitter Card**, `canonical`.
- **JSON-LD schema.org/Restaurant** (horaires, adresse, note, réservations).
- `sitemap.xml`, `robots.txt`, favicon SVG, manifeste PWA.
- `preconnect` vers les CDN, polices chargées en non-bloquant,
  images en `loading="lazy"` + `decoding="async"` avec `width`/`height`.
- Zéro dépendance externe JS/CSS → aucun coût de framework.

---

## 🌍 Déploiement sur GitHub Pages

1. Créez un dépôt et poussez ces fichiers à la racine (branche `main`).
2. **Settings → Pages → Source :** `Deploy from a branch` → `main` / `/ (root)`.
3. Votre site est en ligne sur `https://<utilisateur>.github.io/<dépôt>/`.
4. Remplacez `https://example.github.io/soussri-sale/` par votre URL réelle dans
   `index.html` (canonical + Open Graph), `sitemap.xml` et `robots.txt`.

---

## 🛠️ Personnalisation rapide

| Je veux changer…            | Fichier                        | Où |
|-----------------------------|--------------------------------|----|
| Couleurs, rayons, polices   | `css/style.css`                | Bloc `:root` (§01) |
| Thème sombre                | `css/style.css`                | `html[data-theme="dark"]` |
| **Plats, prix**             | `database/dishes.json`         | tableau `rows` |
| **Catégories**              | `database/categories.json`     | tableau `rows` |
| **Adresse, tél., horaires** | `database/restaurant.json`     | racine du fichier |
| **Numéro WhatsApp**         | `database/restaurant.json`     | clé `whatsapp` |
| **Avis clients**            | `database/testimonials.json`   | tableau `rows` |
| **Photos de la galerie**    | `database/gallery.json`        | tableau `rows` |
| **Équipe**                  | `database/team.json`           | tableau `rows` |
| Carte Google Maps           | `index.html`                   | `<iframe>` section Contact |
| Repli hors-ligne            | `js/data.js`                   | copie miroir des tables |

> Après avoir édité un fichier de `/database/`, ouvrez l'administration →
> onglet **Données** → **« Recharger depuis /database/ »**.

---

## ⚠️ Note de sécurité

L'authentification est une **simulation front-end pédagogique**. Les comptes
sont stockés dans le LocalStorage du navigateur avec un simple hachage djb2.
N'utilisez jamais ce mécanisme pour de vraies données sensibles.

---

© 2026 Restaurant Soussri Salé — Tous droits réservés.
