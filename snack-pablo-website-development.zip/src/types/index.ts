export type CategoryId = 
  | 'all'
  | 'tacos'
  | 'burgers'
  | 'pizzas'
  | 'sandwichs'
  | 'paninis'
  | 'shawarma'
  | 'salades'
  | 'enfants'
  | 'desserts'
  | 'boissons';

export interface Category {
  id: CategoryId;
  name: string;
  iconName: string;
  count: number;
}

export interface Product {
  id: string;
  name: string;
  category: Exclude<CategoryId, 'all'>;
  price: number; // in MAD (Dirham)
  oldPrice?: number;
  description: string;
  image: string;
  badge?: 'Best-Seller' | 'Nouveau' | 'Spécialité' | 'Promo' | 'Halal 100%';
  calories?: number;
  prepTime?: string;
  spiceLevel?: 0 | 1 | 2 | 3; // 0 = non épicé, 3 = très épicé
  availableSauces?: string[];
  availableMeats?: string[];
  isVegetarian?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSauce?: string;
  selectedMeat?: string;
  extraCheese?: boolean;
  notes?: string;
}

export interface Promotion {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  discount: string;
  code: string;
  image: string;
  validUntil: string;
  linkedProductId?: string;
  category: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'tacos' | 'burgers' | 'pizzas' | 'ambiance' | 'desserts';
  image: string;
  description: string;
  likes: number;
}

export interface Review {
  id: string;
  name: string;
  role: string;
  avatar: string;
  rating: number;
  comment: string;
  date: string;
  dish: string;
}

export interface OrderDetails {
  customerName: string;
  phone: string;
  email?: string;
  address: string;
  city: 'Martil Centre' | 'Martil Corniche' | 'Cabo Negro' | 'Mdiq' | 'Tetouan';
  orderType: 'livraison' | 'emporter';
  paymentMethod: 'cash' | 'card_delivery' | 'online_card';
  notes?: string;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  orderId: string;
  createdAt: string;
}
