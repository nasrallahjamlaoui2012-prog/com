import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MenuSection } from './components/MenuSection';
import { PromoSection } from './components/PromoSection';
import { AboutSection } from './components/AboutSection';
import { GallerySection } from './components/GallerySection';
import { ReviewsSection } from './components/ReviewsSection';
import { OnlineOrderSection } from './components/OnlineOrderSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CartItem } from './types';

export function App() {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('pablo_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pablo_theme');
      if (saved !== null) return saved === 'dark';
      return true; // Default to dark mode for sleek fast-food aesthetics
    } catch {
      return true;
    }
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('pablo_sound');
      if (saved !== null) return saved === 'true';
      return true;
    } catch {
      return true;
    }
  });

  const [activeSection, setActiveSection] = useState('accueil');

  // Save cart to local storage
  useEffect(() => {
    try {
      localStorage.setItem('pablo_cart', JSON.stringify(cart));
    } catch {
      // ignore storage errors
    }
  }, [cart]);

  // Apply dark mode class to html tag
  useEffect(() => {
    const html = document.documentElement;
    if (darkMode) {
      html.classList.add('dark');
      try { localStorage.setItem('pablo_theme', 'dark'); } catch { /* ignore */ }
    } else {
      html.classList.remove('dark');
      try { localStorage.setItem('pablo_theme', 'light'); } catch { /* ignore */ }
    }
  }, [darkMode]);

  // Save sound preference
  useEffect(() => {
    try {
      localStorage.setItem('pablo_sound', String(soundEnabled));
    } catch {
      // ignore
    }
  }, [soundEnabled]);

  // Track active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['accueil', 'menu', 'promotions', 'apropos', 'galerie', 'avis', 'commande', 'contact'];
      const scrollPos = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Cart handlers
  const handleAddToCart = (newItem: CartItem) => {
    setCart((prevCart) => {
      // Check if exact same customization already exists
      const existingIndex = prevCart.findIndex(
        (item) =>
          item.product.id === newItem.product.id &&
          item.selectedMeat === newItem.selectedMeat &&
          item.selectedSauce === newItem.selectedSauce &&
          item.extraCheese === newItem.extraCheese &&
          item.notes === newItem.notes
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += newItem.quantity;
        return updated;
      } else {
        return [...prevCart, newItem];
      }
    });
  };

  const handleUpdateQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCart((prevCart) => {
      const updated = [...prevCart];
      updated[index].quantity = newQty;
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setCart((prevCart) => prevCart.filter((_, i) => i !== index));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleOpenSearch = () => {
    const el = document.getElementById('menu');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => {
        const input = el.querySelector('input[type="text"]') as HTMLInputElement;
        if (input) input.focus();
      }, 500);
    }
  };

  const handleOrderNow = () => {
    const el = document.getElementById('menu');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleProceedToCheckout = () => {
    const el = document.getElementById('commande');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100 font-sans transition-colors duration-300 selection:bg-red-600 selection:text-white">
      {/* Navigation Bar */}
      <Navbar
        cartCount={totalCartItemsCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={handleOpenSearch}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        soundEnabled={soundEnabled}
        onToggleSound={() => setSoundEnabled(!soundEnabled)}
        activeSection={activeSection}
      />

      {/* Main Content Sections */}
      <main>
        {/* 1. Hero Section */}
        <Hero
          onOrderNow={handleOrderNow}
          soundEnabled={soundEnabled}
        />

        {/* 2. Menu Section */}
        <MenuSection
          onAddToCart={handleAddToCart}
          soundEnabled={soundEnabled}
        />

        {/* 3. Promotions Section */}
        <PromoSection
          onAddToCart={handleAddToCart}
          soundEnabled={soundEnabled}
        />

        {/* 4. About Section */}
        <AboutSection />

        {/* 5. Gallery Section */}
        <GallerySection
          soundEnabled={soundEnabled}
        />

        {/* 6. Reviews Section */}
        <ReviewsSection
          soundEnabled={soundEnabled}
        />

        {/* 7. Online Order / Checkout Section */}
        <OnlineOrderSection
          cart={cart}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
          onClearCart={handleClearCart}
          soundEnabled={soundEnabled}
        />

        {/* 8. Contact & Maps Section */}
        <ContactSection
          soundEnabled={soundEnabled}
        />
      </main>

      {/* Footer */}
      <Footer
        soundEnabled={soundEnabled}
      />

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={handleProceedToCheckout}
        soundEnabled={soundEnabled}
      />
    </div>
  );
}

export default App;
