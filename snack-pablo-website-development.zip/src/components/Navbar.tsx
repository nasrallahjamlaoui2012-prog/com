import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Sun, 
  Moon, 
  Menu as MenuIcon, 
  X, 
  PhoneCall, 
  Volume2, 
  VolumeX, 
  Flame,
  MapPin
} from 'lucide-react';
import { playSound } from '../utils/sound';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenSearch,
  darkMode,
  onToggleDarkMode,
  soundEnabled,
  onToggleSound,
  activeSection,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Accueil', href: '#accueil', id: 'accueil' },
    { name: 'Menu & Commander', href: '#menu', id: 'menu' },
    { name: 'Promotions', href: '#promotions', id: 'promotions', badge: '-20%' },
    { name: 'À Propos', href: '#apropos', id: 'apropos' },
    { name: 'Galerie', href: '#galerie', id: 'galerie' },
    { name: 'Avis', href: '#avis', id: 'avis' },
    { name: 'Contact & Accès', href: '#contact', id: 'contact' },
  ];

  const handleNavClick = (href: string) => {
    playSound('click', soundEnabled);
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-zinc-950/90 dark:bg-zinc-950/95 backdrop-blur-md shadow-lg shadow-black/20 py-3 border-b border-red-600/30'
            : 'bg-gradient-to-b from-black/80 via-black/40 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a
              href="#accueil"
              onClick={(e) => {
                e.preventDefault();
                handleNavClick('#accueil');
              }}
              className="flex items-center gap-2.5 group focus:outline-none"
            >
              <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-gradient-to-tr from-red-600 via-red-500 to-yellow-400 p-0.5 flex items-center justify-center shadow-md shadow-red-600/40 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-zinc-950 rounded-full flex items-center justify-center">
                  <Flame className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-400 fill-yellow-400 animate-pulse" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-heading font-black text-lg sm:text-xl tracking-tighter text-white uppercase flex items-center gap-1">
                  Snack <span className="text-red-500">Pablo</span>
                </span>
                <span className="text-[10px] tracking-widest text-yellow-400 uppercase font-bold flex items-center gap-0.5 -mt-1">
                  <MapPin className="w-2.5 h-2.5 inline" /> Martil, Maroc
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <nav className="hidden xl:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive = activeSection === link.id;
                return (
                  <a
                    key={link.id}
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      handleNavClick(link.href);
                    }}
                    className={`relative px-3.5 py-2 rounded-full text-sm font-semibold transition-all duration-200 flex items-center gap-1.5 ${
                      isActive
                        ? 'text-yellow-400 bg-red-600/20 border border-red-500/30'
                        : 'text-zinc-200 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    {link.name}
                    {link.badge && (
                      <span className="bg-gradient-to-r from-red-600 to-yellow-500 text-white text-[10px] font-extrabold px-1.5 py-0.2 rounded-full uppercase animate-bounce">
                        {link.badge}
                      </span>
                    )}
                  </a>
                );
              })}
            </nav>

            {/* Right Action Icons */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Phone call button */}
              <a
                href="tel:+212600000000"
                onClick={() => playSound('click', soundEnabled)}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-600/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-600/30 transition-all text-xs font-bold"
                title="Commander par téléphone"
              >
                <PhoneCall className="w-3.5 h-3.5 animate-pulse" />
                <span>+212 600-000000</span>
              </a>

              {/* Search button */}
              <button
                onClick={() => {
                  playSound('click', soundEnabled);
                  onOpenSearch();
                }}
                className="p-2 sm:p-2.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-200 hover:text-white transition-all border border-zinc-700/60 focus:outline-none"
                title="Rechercher un plat"
              >
                <Search className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>

              {/* Sound Toggle */}
              <button
                onClick={() => {
                  onToggleSound();
                  playSound('bell', !soundEnabled);
                }}
                className="p-2 sm:p-2.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-200 hover:text-white transition-all border border-zinc-700/60 focus:outline-none hidden sm:block"
                title={soundEnabled ? "Désactiver les sons" : "Activer les sons"}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" /> : <VolumeX className="w-4 h-4 sm:w-5 sm:h-5 text-zinc-400" />}
              </button>

              {/* Dark/Light mode toggle */}
              <button
                onClick={() => {
                  playSound('click', soundEnabled);
                  onToggleDarkMode();
                }}
                className="p-2 sm:p-2.5 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-zinc-200 hover:text-white transition-all border border-zinc-700/60 focus:outline-none"
                title={darkMode ? "Passer au mode clair" : "Passer au mode sombre"}
              >
                {darkMode ? <Sun className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-400" /> : <Moon className="w-4 h-4 sm:w-5 sm:h-5 text-zinc-200" />}
              </button>

              {/* Cart Button with Counter */}
              <button
                onClick={() => {
                  playSound('pop', soundEnabled);
                  onOpenCart();
                }}
                className="relative px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-bold transition-all shadow-md shadow-red-600/40 flex items-center gap-2 group focus:outline-none"
              >
                <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" />
                <span className="hidden sm:inline text-sm">Panier</span>
                {cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-yellow-400 text-zinc-950 text-xs font-black w-5 h-5 sm:w-6 sm:h-6 rounded-full flex items-center justify-center border-2 border-zinc-950 shadow-sm animate-pulse">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Mobile Hamburger Button */}
              <button
                onClick={() => {
                  playSound('click', soundEnabled);
                  setMobileMenuOpen(!mobileMenuOpen);
                }}
                className="xl:hidden p-2 rounded-lg bg-zinc-800/80 text-white hover:bg-zinc-700 border border-zinc-700/60 focus:outline-none"
                aria-label="Toggle Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6 text-red-500" /> : <MenuIcon className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-zinc-950/95 backdrop-blur-xl flex flex-col pt-24 px-6 pb-8 xl:hidden animate-fade-in border-l border-zinc-800">
          <div className="flex-1 flex flex-col justify-center space-y-4 max-w-sm mx-auto w-full">
            <div className="text-center mb-4">
              <span className="text-xs uppercase tracking-widest text-yellow-400 font-bold">Navigation Snack Pablo</span>
            </div>
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(link.href);
                }}
                className={`py-3 px-6 rounded-2xl text-lg font-heading font-bold flex items-center justify-between transition-all ${
                  activeSection === link.id
                    ? 'bg-red-600 text-white shadow-lg shadow-red-600/30'
                    : 'bg-zinc-900/80 text-zinc-200 hover:bg-zinc-800 border border-zinc-800'
                }`}
              >
                <span>{link.name}</span>
                {link.badge && (
                  <span className="bg-yellow-400 text-zinc-950 text-xs font-black px-2 py-0.5 rounded-full">
                    {link.badge}
                  </span>
                )}
              </a>
            ))}

            <div className="pt-6 border-t border-zinc-800 mt-4 flex flex-col gap-3">
              <a
                href="tel:+212600000000"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30"
              >
                <PhoneCall className="w-5 h-5 animate-bounce" />
                <span>Appeler le +212 600-000000</span>
              </a>

              <button
                onClick={() => {
                  onToggleSound();
                  playSound('bell', !soundEnabled);
                }}
                className="w-full py-3 rounded-2xl bg-zinc-900 text-zinc-300 font-semibold flex items-center justify-center gap-2 border border-zinc-800"
              >
                {soundEnabled ? (
                  <>
                    <Volume2 className="w-5 h-5 text-yellow-400" />
                    <span>Sons activés</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-5 h-5 text-zinc-500" />
                    <span>Sons désactivés</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
