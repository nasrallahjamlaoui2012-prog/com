import React, { useState, useMemo } from 'react';
import { Product, CategoryId, CartItem } from '../types';
import { PRODUCTS, CATEGORIES } from '../data/products';
import { ProductModal } from './ProductModal';
import { 
  Search, 
  Flame, 
  ShoppingBag, 
  Clock, 
  Filter, 
  ArrowUpDown, 
  Utensils,
  Heart,
  Eye
} from 'lucide-react';
import { playSound } from '../utils/sound';

interface MenuSectionProps {
  onAddToCart: (item: CartItem) => void;
  soundEnabled: boolean;
}

export const MenuSection: React.FC<MenuSectionProps> = ({ onAddToCart, soundEnabled }) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc'>('default');
  const [onlyVegetarian, setOnlyVegetarian] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('pop', soundEnabled);
    setFavorites((prev) => 
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      const matchesCat = selectedCategory === 'all' || product.category === selectedCategory;
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            product.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesVeg = !onlyVegetarian || product.isVegetarian === true;
      return matchesCat && matchesSearch && matchesVeg;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      return 0;
    });
  }, [selectedCategory, searchQuery, sortBy, onlyVegetarian]);

  const handleDirectAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('success', soundEnabled);
    onAddToCart({
      product,
      quantity: 1,
      selectedSauce: product.availableSauces ? product.availableSauces[0] : undefined,
      selectedMeat: product.availableMeats ? product.availableMeats[0] : undefined,
    });
  };

  const renderSpicePeppers = (level?: number) => {
    if (!level || level === 0) return null;
    return (
      <div className="flex items-center gap-0.5 bg-red-600/10 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-2 py-0.5 rounded-full text-[10px] font-bold" title={`Piquant niveau ${level}/3`}>
        {Array.from({ length: level }).map((_, i) => (
          <Flame key={i} className="w-3 h-3 fill-red-600" />
        ))}
      </div>
    );
  };

  return (
    <section id="menu" className="py-20 sm:py-28 bg-zinc-50 dark:bg-zinc-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-600/10 dark:bg-red-600/20 text-red-600 dark:text-red-400 text-xs font-black uppercase tracking-wider mb-3">
            <Utensils className="w-3.5 h-3.5" />
            <span>Notre Menu Gourmand</span>
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-zinc-900 dark:text-white uppercase tracking-tight mb-4">
            FAIT MAISON AVEC <span className="text-red-600">PASSION</span>
          </h2>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm sm:text-lg leading-relaxed">
            Parcourez notre carte complète. Du véritable <strong className="text-zinc-900 dark:text-white">Tacos au gratin</strong> au <strong className="text-zinc-900 dark:text-white">Smash Burger</strong> juteux, sélectionnez vos viandes, vos sauces et commandez en ligne pour une livraison rapide sur Martil et Cabo Negro !
          </p>
        </div>

        {/* Search & Filter Bar */}
        <div className="bg-white dark:bg-zinc-900 rounded-3xl p-4 sm:p-6 shadow-xl border border-zinc-200 dark:border-zinc-800 mb-10 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Search Input */}
          <div className="relative w-full md:w-80 lg:w-96">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Rechercher (ex: Gratin, Smash, Pepperoni...)"
              className="w-full pl-12 pr-4 py-3 rounded-2xl bg-zinc-100 dark:bg-zinc-800 border border-transparent focus:border-red-600 text-zinc-900 dark:text-white placeholder-zinc-400 text-sm focus:outline-none transition-all"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-zinc-400 hover:text-zinc-600 dark:hover:text-white bg-zinc-200 dark:bg-zinc-700 px-2 py-0.5 rounded"
              >
                Effacer
              </button>
            )}
          </div>

          {/* Sort & Filter Controls */}
          <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3 w-full md:w-auto">
            {/* Vegetarian Filter */}
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                setOnlyVegetarian(!onlyVegetarian);
              }}
              className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center gap-2 border transition-all ${
                onlyVegetarian
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20'
                  : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-700 hover:border-emerald-500'
              }`}
            >
              <span>🌱 Végétarien</span>
              <span className={`w-2 h-2 rounded-full ${onlyVegetarian ? 'bg-white' : 'bg-zinc-400'}`} />
            </button>

            {/* Sort Dropdown */}
            <div className="relative flex items-center gap-2 bg-zinc-100 dark:bg-zinc-800 px-3.5 py-2.5 rounded-2xl border border-zinc-200 dark:border-zinc-700 text-xs sm:text-sm text-zinc-700 dark:text-zinc-300 font-bold">
              <ArrowUpDown className="w-4 h-4 text-red-600 shrink-0" />
              <span>Trier :</span>
              <select
                value={sortBy}
                onChange={(e) => {
                  playSound('click', soundEnabled);
                  setSortBy(e.target.value as 'default' | 'price-asc' | 'price-desc');
                }}
                className="bg-transparent border-none font-extrabold text-zinc-900 dark:text-white focus:outline-none cursor-pointer"
              >
                <option value="default" className="bg-white dark:bg-zinc-900">Repertorié</option>
                <option value="price-asc" className="bg-white dark:bg-zinc-900">Prix : Croissant</option>
                <option value="price-desc" className="bg-white dark:bg-zinc-900">Prix : Décroissant</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Navigation Tabs */}
        <div className="flex items-center gap-2.5 overflow-x-auto pb-4 mb-10 scrollbar-none snap-x">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  playSound('click', soundEnabled);
                  setSelectedCategory(cat.id);
                }}
                className={`snap-start whitespace-nowrap px-5 py-3 rounded-2xl font-heading font-black text-sm uppercase tracking-wider transition-all flex items-center gap-2.5 shrink-0 shadow-sm ${
                  isSelected
                    ? 'bg-gradient-to-r from-red-600 to-red-700 text-white shadow-lg shadow-red-600/30 scale-105 ring-2 ring-red-400/50'
                    : 'bg-white dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800'
                }`}
              >
                <span>{cat.name}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                  isSelected ? 'bg-yellow-400 text-zinc-950 font-black' : 'bg-zinc-100 dark:bg-zinc-800 text-zinc-500'
                }`}>
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20 bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800">
            <Filter className="w-12 h-12 text-zinc-400 mx-auto mb-4 animate-bounce" />
            <h3 className="font-heading font-bold text-xl text-zinc-900 dark:text-white mb-2">
              Aucun produit ne correspond à votre recherche
            </h3>
            <p className="text-zinc-500 text-sm max-w-md mx-auto mb-6">
              Essayez de modifier vos filtres ou effectuez une recherche plus générale.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setOnlyVegetarian(false);
              }}
              className="px-6 py-2.5 rounded-full bg-red-600 text-white font-bold text-sm shadow-lg shadow-red-600/30"
            >
              Réinitialiser les filtres
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredProducts.map((product) => {
              const isFav = favorites.includes(product.id);
              return (
                <div
                  key={product.id}
                  onClick={() => {
                    playSound('click', soundEnabled);
                    setSelectedProduct(product);
                  }}
                  className="group relative bg-white dark:bg-zinc-900 rounded-3xl overflow-hidden border border-zinc-200 dark:border-zinc-800 hover:border-red-500/50 dark:hover:border-red-500/50 shadow-md hover:shadow-2xl transition-all duration-300 flex flex-col cursor-pointer transform hover:-translate-y-1.5"
                >
                  {/* Image Container */}
                  <div className="relative h-56 sm:h-60 w-full overflow-hidden bg-zinc-100 dark:bg-zinc-800">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 flex flex-col gap-1.5 items-start">
                      {product.badge && (
                        <span className="bg-red-600 text-white font-black text-[11px] uppercase tracking-wider px-3 py-1 rounded-full shadow-md animate-pulse">
                          {product.badge}
                        </span>
                      )}
                      {product.isVegetarian && (
                        <span className="bg-emerald-600 text-white font-bold text-[10px] uppercase px-2.5 py-0.5 rounded-full shadow-md">
                          🌱 Veggie
                        </span>
                      )}
                    </div>

                    {/* Favorite Button */}
                    <button
                      type="button"
                      onClick={(e) => toggleFavorite(product.id, e)}
                      className="absolute top-3 right-3 p-2.5 rounded-full bg-white/80 dark:bg-black/60 backdrop-blur-md text-zinc-700 dark:text-zinc-200 hover:text-red-500 dark:hover:text-red-500 transition-colors shadow-sm"
                      title="Ajouter aux favoris"
                    >
                      <Heart className={`w-4 h-4 ${isFav ? 'fill-red-600 text-red-600' : ''}`} />
                    </button>

                    {/* Quick Preview Hover Overlay */}
                    <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                      <div className="px-4 py-2 rounded-full bg-white/90 text-zinc-950 font-heading font-black text-xs uppercase tracking-wider shadow-lg flex items-center gap-2 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                        <Eye className="w-4 h-4 text-red-600" />
                        <span>Personnaliser le plat</span>
                      </div>
                    </div>

                    {/* Spice Level & Prep Time at bottom of image */}
                    <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white/90 font-semibold">
                      <div className="flex items-center gap-1 bg-black/50 backdrop-blur-sm px-2.5 py-1 rounded-full">
                        <Clock className="w-3.5 h-3.5 text-yellow-400" />
                        <span>{product.prepTime || '10-15 min'}</span>
                      </div>
                      {renderSpicePeppers(product.spiceLevel)}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <h3 className="font-heading font-black text-lg sm:text-xl text-zinc-900 dark:text-white group-hover:text-red-600 dark:group-hover:text-red-500 transition-colors leading-tight line-clamp-1">
                          {product.name}
                        </h3>
                      </div>
                      <p className="text-zinc-500 dark:text-zinc-400 text-xs sm:text-sm leading-relaxed line-clamp-2">
                        {product.description}
                      </p>
                    </div>

                    {/* Price & Direct Add Button */}
                    <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800/80 flex items-center justify-between gap-3">
                      <div className="flex flex-col">
                        <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider">Prix à emporter / livraison</span>
                        <div className="flex items-baseline gap-2">
                          <span className="font-heading font-black text-2xl text-zinc-900 dark:text-white">
                            {product.price} <span className="text-sm font-extrabold text-red-600">DH</span>
                          </span>
                          {product.oldPrice && (
                            <span className="text-xs text-zinc-400 line-through font-semibold">
                              {product.oldPrice} DH
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Add Button */}
                      <button
                        type="button"
                        onClick={(e) => handleDirectAdd(product, e)}
                        className="px-4 py-3 rounded-2xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-heading font-bold text-xs uppercase tracking-wider shadow-lg shadow-red-600/25 hover:shadow-red-600/50 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 shrink-0 group/btn"
                        title="Ajouter au panier rapidement"
                      >
                        <ShoppingBag className="w-4 h-4 group-hover/btn:rotate-12 transition-transform" />
                        <span className="hidden sm:inline">Ajouter</span>
                        <span className="sm:hidden">+</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Customization Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={onAddToCart}
        soundEnabled={soundEnabled}
      />
    </section>
  );
};
