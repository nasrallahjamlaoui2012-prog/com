import React, { useState } from 'react';
import { 
  Flame, 
  MapPin, 
  PhoneCall, 
  Mail, 
  ArrowUp, 
  Send, 
  CheckCircle2, 
  Heart 
} from 'lucide-react';
import { playSound } from '../utils/sound';

interface FooterProps {
  soundEnabled: boolean;
}

export const Footer: React.FC<FooterProps> = ({ soundEnabled }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return;
    
    playSound('success', soundEnabled);
    setSubscribed(true);
    setEmail('');
    setTimeout(() => setSubscribed(false), 4000);
  };

  const scrollToTop = () => {
    playSound('click', soundEnabled);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-zinc-950 text-white border-t border-zinc-800 relative overflow-hidden">
      {/* Background Decorative Gradient */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent opacity-60" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-zinc-800/80">
          
          {/* Col 1: Brand & Bio */}
          <div className="lg:col-span-4 space-y-4">
            <a href="#accueil" className="flex items-center gap-2.5 group">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-red-600 to-yellow-400 p-0.5 flex items-center justify-center">
                <div className="w-full h-full bg-zinc-950 rounded-full flex items-center justify-center">
                  <Flame className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-heading font-black text-xl tracking-tighter text-white uppercase">
                  Snack <span className="text-red-500">Pablo</span>
                </span>
                <span className="text-[10px] tracking-widest text-yellow-400 uppercase font-bold flex items-center gap-0.5 -mt-1">
                  <MapPin className="w-2.5 h-2.5 inline" /> Martil, Maroc
                </span>
              </div>
            </a>

            <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed max-w-sm">
              Le numéro 1 de la restauration rapide sur Martil et Cabo Negro. Des Tacos gratinés au four, des Smash Burgers juteux et des Pizzas artisanales cuisinés avec amour et passion.
            </p>

            {/* Social Links */}
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound('click', soundEnabled)}
                className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-gradient-to-tr hover:from-yellow-500 hover:via-red-500 hover:to-purple-500 text-zinc-300 hover:text-white transition-all flex items-center justify-center border border-zinc-800 font-bold text-xs"
                title="Instagram Snack Pablo"
              >
                IG
              </a>

              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound('click', soundEnabled)}
                className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-blue-600 text-zinc-300 hover:text-white transition-all flex items-center justify-center border border-zinc-800 font-bold text-xs"
                title="Facebook Snack Pablo"
              >
                FB
              </a>

              <a
                href="https://tiktok.com"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound('click', soundEnabled)}
                className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-black text-zinc-300 hover:text-white transition-all flex items-center justify-center border border-zinc-800 font-heading font-black text-xs"
                title="TikTok Snack Pablo"
              >
                TK
              </a>

              <a
                href="https://wa.me/212600000000"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => playSound('click', soundEnabled)}
                className="w-10 h-10 rounded-full bg-zinc-900 hover:bg-emerald-600 text-zinc-300 hover:text-white transition-all flex items-center justify-center border border-zinc-800 font-bold text-xs"
                title="WhatsApp Snack Pablo"
              >
                WA
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-heading font-extrabold text-sm uppercase tracking-wider text-yellow-400">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-zinc-400 font-medium">
              <li><a href="#accueil" onClick={() => playSound('click', soundEnabled)} className="hover:text-white transition-colors">Accueil</a></li>
              <li><a href="#menu" onClick={() => playSound('click', soundEnabled)} className="hover:text-white transition-colors">Notre Menu</a></li>
              <li><a href="#promotions" onClick={() => playSound('click', soundEnabled)} className="hover:text-white transition-colors">Promotions</a></li>
              <li><a href="#apropos" onClick={() => playSound('click', soundEnabled)} className="hover:text-white transition-colors">À Propos</a></li>
              <li><a href="#galerie" onClick={() => playSound('click', soundEnabled)} className="hover:text-white transition-colors">Galerie Photos</a></li>
              <li><a href="#commande" onClick={() => playSound('click', soundEnabled)} className="hover:text-white transition-colors">Commander en ligne</a></li>
            </ul>
          </div>

          {/* Col 3: Spécialités */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-heading font-extrabold text-sm uppercase tracking-wider text-red-500">
              Nos Délices
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-zinc-400 font-medium">
              <li><span className="text-zinc-300 font-semibold">Tacos au Gratin</span></li>
              <li><span className="text-zinc-300 font-semibold">Smash Burgers</span></li>
              <li><span className="text-zinc-300 font-semibold">Pizzas Feu de Bois</span></li>
              <li><span className="text-zinc-300 font-semibold">Bocadillos Nordistes</span></li>
              <li><span className="text-zinc-300 font-semibold">Shawarmas Libanais</span></li>
              <li><span className="text-zinc-300 font-semibold">Milkshakes Gourmet</span></li>
            </ul>
          </div>

          {/* Col 4: Newsletter & Contact Quick */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="font-heading font-extrabold text-sm uppercase tracking-wider text-white">
              Newsletter & Bons Plans
            </h4>
            <p className="text-zinc-400 text-xs leading-relaxed">
              Inscrivez-vous pour recevoir nos codes promos VIP et nos nouvelles recettes exclusives en avant-première !
            </p>

            {subscribed ? (
              <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/40 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Merci ! Vous êtes inscrit(e) à nos bons plans VIP.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="votre@email.com"
                  required
                  className="flex-1 px-4 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-white placeholder-zinc-500 text-xs focus:outline-none focus:border-red-600"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase transition-colors shrink-0 flex items-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Ok</span>
                </button>
              </form>
            )}

            <div className="pt-2 text-xs text-zinc-500 space-y-1">
              <div className="flex items-center gap-2">
                <PhoneCall className="w-3.5 h-3.5 text-emerald-500" />
                <span>Livraison : <strong className="text-zinc-300">Martil, Corniche & Cabo Negro</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-yellow-400" />
                <span>Assistance : <strong className="text-zinc-300">contact@snackpablomartil.ma</strong></span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Copyright & Back to top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <div className="flex items-center gap-1">
            <span>© 2026 Snack Pablo Martil. Tous droits réservés. Cuisiné avec</span>
            <Heart className="w-3.5 h-3.5 fill-red-600 text-red-600 inline" />
            <span>à Martil, Maroc.</span>
          </div>

          <div className="flex items-center gap-6">
            <span className="hover:text-zinc-400 cursor-pointer">Mentions Légales</span>
            <span className="hover:text-zinc-400 cursor-pointer">Politique de Confidentialité</span>
            <span className="hover:text-zinc-400 cursor-pointer">Allergènes</span>

            {/* Back To Top Button */}
            <button
              onClick={scrollToTop}
              className="p-2.5 rounded-full bg-red-600 hover:bg-red-500 text-white transition-all shadow-lg shadow-red-600/30 flex items-center justify-center group focus:outline-none ml-2"
              title="Retour en haut"
              aria-label="Retour en haut"
            >
              <ArrowUp className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
