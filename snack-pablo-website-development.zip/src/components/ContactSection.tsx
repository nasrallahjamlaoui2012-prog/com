import React, { useState } from 'react';
import { 
  MapPin, 
  PhoneCall, 
  Clock, 
  Send, 
  CheckCircle2, 
  Mail, 
  MessageSquare,
  Navigation
} from 'lucide-react';
import { playSound } from '../utils/sound';

interface ContactSectionProps {
  soundEnabled: boolean;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ soundEnabled }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: 'Réservation table / Renseignement',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim() || !formData.message.trim()) {
      playSound('click', soundEnabled);
      return;
    }

    setLoading(true);
    playSound('bell', soundEnabled);

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      playSound('success', soundEnabled);
      setFormData({ name: '', phone: '', email: '', subject: 'Réservation table / Renseignement', message: '' });
      setTimeout(() => setSubmitted(false), 5000);
    }, 1000);
  };

  return (
    <section id="contact" className="py-20 sm:py-28 bg-zinc-50 dark:bg-zinc-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-600/10 dark:bg-red-600/20 text-red-600 dark:text-red-400 text-xs font-black uppercase tracking-wider mb-3">
            <MapPin className="w-3.5 h-3.5" />
            <span>Localisation & Horaires</span>
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-zinc-900 dark:text-white uppercase tracking-tight mb-4">
            VENEZ NOUS VOIR À <span className="text-red-600">MARTIL</span>
          </h2>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm sm:text-lg leading-relaxed">
            Situé en plein centre de Martil près de la Corniche et de la plage. Commandez par téléphone, passez prendre votre plat à emporter ou envoyez-nous un message !
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Left Column: Info Cards & Hours */}
          <div className="lg:col-span-5 space-y-6">
            {/* Direct Contact Card */}
            <div className="bg-white dark:bg-zinc-900 rounded-3xl p-6 sm:p-8 border border-zinc-200 dark:border-zinc-800 shadow-xl space-y-6">
              <h3 className="font-heading font-black text-xl text-zinc-900 dark:text-white flex items-center gap-2.5">
                <Navigation className="w-5 h-5 text-red-600" />
                <span>Coordonnées Snack Pablo</span>
              </h3>

              <div className="space-y-4 text-sm">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-red-600/10 dark:bg-red-900/30 text-red-600 dark:text-red-400 flex items-center justify-center shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-bold text-zinc-900 dark:text-white block">Adresse du restaurant :</span>
                    <span className="text-zinc-600 dark:text-zinc-400">Avenue Hassan II / Proche Corniche de la Plage, 93150 Martil, Maroc</span>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <PhoneCall className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-bold text-zinc-900 dark:text-white block">Téléphone & WhatsApp :</span>
                    <a href="tel:+212600000000" className="text-emerald-600 dark:text-emerald-400 font-extrabold hover:underline block">
                      +212 600-000000
                    </a>
                    <span className="text-[11px] text-zinc-400">Commandes & réservations de groupes</span>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-yellow-500/10 dark:bg-yellow-900/30 text-yellow-600 dark:text-yellow-400 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-bold text-zinc-900 dark:text-white block">Email professionnel :</span>
                    <span className="text-zinc-600 dark:text-zinc-400">contact@snackpablomartil.ma</span>
                  </div>
                </div>
              </div>

              {/* Hours Table */}
              <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 space-y-3">
                <div className="flex items-center gap-2 font-heading font-bold text-zinc-900 dark:text-white">
                  <Clock className="w-5 h-5 text-red-600" />
                  <span>Horaires d&apos;ouverture non-stop</span>
                </div>

                <div className="bg-zinc-50 dark:bg-zinc-950 p-4 rounded-2xl border border-zinc-200 dark:border-zinc-800 space-y-2 text-xs sm:text-sm">
                  <div className="flex justify-between font-semibold">
                    <span className="text-zinc-600 dark:text-zinc-400">Lundi au Vendredi</span>
                    <span className="text-zinc-900 dark:text-white font-black">11h00 – 03h00</span>
                  </div>
                  <div className="flex justify-between font-semibold">
                    <span className="text-zinc-600 dark:text-zinc-400">Samedi & Dimanche</span>
                    <span className="text-zinc-900 dark:text-white font-black">11h00 – 04h00</span>
                  </div>
                  <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                    <span className="text-emerald-600 dark:text-emerald-400 font-extrabold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                      <span>Actuellement Ouvert</span>
                    </span>
                    <span className="text-[10px] text-zinc-400">Service de nuit sur Martil & Cabo</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Contact Form & Map */}
          <div className="lg:col-span-7 space-y-6">
            {/* Contact Form */}
            <div className="bg-white dark:bg-zinc-900 rounded-3xl p-6 sm:p-8 border border-zinc-200 dark:border-zinc-800 shadow-xl relative overflow-hidden">
              <h3 className="font-heading font-black text-xl sm:text-2xl text-zinc-900 dark:text-white mb-6 flex items-center gap-2.5">
                <MessageSquare className="w-6 h-6 text-red-600" />
                <span>Envoyez-nous un Message / Suggestion</span>
              </h3>

              {submitted ? (
                <div className="py-12 text-center space-y-4 animate-fade-in">
                  <div className="w-16 h-16 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10 animate-bounce" />
                  </div>
                  <h4 className="font-heading font-black text-2xl text-zinc-900 dark:text-white">
                    Message transmis avec succès !
                  </h4>
                  <p className="text-zinc-600 dark:text-zinc-400 text-sm max-w-md mx-auto">
                    Merci d&apos;avoir contacté l&apos;équipe Snack Pablo Martil. Notre responsable vous répondra dans les plus brefs délais !
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                        Votre Nom <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Nom complet"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                        Téléphone <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="Ex: 06 00 00 00 00"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                        Email (Optionnel)
                      </label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="votre@email.com"
                        className="w-full px-4 py-3 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                        Sujet de la demande
                      </label>
                      <select
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                      >
                        <option value="Réservation table / Renseignement">Réservation / Renseignement</option>
                        <option value="Suivi commande en cours">Suivi de commande en cours</option>
                        <option value="Réclamation / Suggestion">Suggestion / Avis</option>
                        <option value="Partenariat / Événement">Partenariat / Événement</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                      Votre Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      rows={4}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Comment pouvons-nous vous aider aujourd'hui ?..."
                      className="w-full px-4 py-3 rounded-xl bg-zinc-50 dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-heading font-black text-sm uppercase tracking-wider shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 transition-all active:scale-95"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Envoyer mon message</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Google Maps Embed iframe */}
            <div className="h-64 sm:h-80 w-full rounded-3xl overflow-hidden shadow-xl border border-zinc-200 dark:border-zinc-800 bg-zinc-200 dark:bg-zinc-800 relative">
              <iframe
                title="Localisation Google Maps Snack Pablo Martil"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13000.0!2d-5.283333!3d35.616667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd0b42f2b4c10000%3A0x100000000000000!2sMartil%2C%20Morocco!5e0!3m2!1sen!2sma!4v1700000000000!5m2!1sen!2sma"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full grayscale-[20%] hover:grayscale-0 transition-all duration-500"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 dark:bg-zinc-900/90 backdrop-blur-md p-3 rounded-2xl border border-zinc-200 dark:border-zinc-800 flex items-center justify-between text-xs pointer-events-none">
                <span className="font-bold text-zinc-900 dark:text-white flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-red-600" />
                  <span>Avenue Hassan II, Proche Corniche, Martil</span>
                </span>
                <span className="bg-red-600 text-white px-2 py-0.5 rounded font-black uppercase">Maroc</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
