import React, { useState } from 'react';
import { Product, CartItem } from '../types';
import { X, Flame, Check, Plus, Minus, ShoppingBag, Clock, Utensils } from 'lucide-react';
import { playSound } from '../utils/sound';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
  soundEnabled: boolean;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  soundEnabled,
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState(1);
  const [selectedSauce, setSelectedSauce] = useState(
    product.availableSauces ? product.availableSauces[0] : 'Sauce Fromagère Maison'
  );
  const [selectedMeat, setSelectedMeat] = useState(
    product.availableMeats ? product.availableMeats[0] : undefined
  );
  const [extraCheese, setExtraCheese] = useState(false);
  const [notes, setNotes] = useState('');

  const calculatedPrice = (product.price + (extraCheese ? 5 : 0)) * quantity;

  const handleAdd = () => {
    playSound('success', soundEnabled);
    onAddToCart({
      product,
      quantity,
      selectedSauce: product.availableSauces ? selectedSauce : undefined,
      selectedMeat: product.availableMeats ? selectedMeat : undefined,
      extraCheese,
      notes: notes.trim() ? notes.trim() : undefined,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div 
        className="relative bg-white dark:bg-zinc-900 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-zinc-200 dark:border-zinc-800 transition-colors max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Image */}
        <div className="relative h-60 sm:h-72 w-full overflow-hidden shrink-0">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-500"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          
          <button
            onClick={() => {
              playSound('click', soundEnabled);
              onClose();
            }}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-black/60 hover:bg-red-600 text-white transition-colors backdrop-blur-md"
            title="Fermer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Badges */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            {product.badge && (
              <span className="bg-red-600 text-white font-black text-xs uppercase px-3 py-1 rounded-full shadow-lg">
                {product.badge}
              </span>
            )}
            {product.isVegetarian && (
              <span className="bg-emerald-600 text-white font-bold text-xs uppercase px-3 py-1 rounded-full shadow-lg">
                🌱 Végétarien
              </span>
            )}
          </div>

          <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between">
            <div>
              <h3 className="font-heading font-black text-2xl sm:text-3xl text-white drop-shadow-md">
                {product.name}
              </h3>
              {product.prepTime && (
                <div className="flex items-center gap-1.5 text-xs text-yellow-300 font-semibold mt-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Préparation rapide : {product.prepTime}</span>
                </div>
              )}
            </div>
            <div className="bg-yellow-400 text-zinc-950 font-heading font-black text-2xl px-4 py-1.5 rounded-2xl shadow-lg shrink-0">
              {product.price} <span className="text-sm font-bold">DH</span>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          <p className="text-zinc-600 dark:text-zinc-300 text-sm sm:text-base leading-relaxed">
            {product.description}
          </p>

          {/* Meat Selection (If available) */}
          {product.availableMeats && product.availableMeats.length > 0 && (
            <div className="space-y-3">
              <label className="font-heading font-bold text-base flex items-center gap-2 text-zinc-900 dark:text-white">
                <Utensils className="w-4 h-4 text-red-600" />
                <span>Choisissez votre viande</span>
                <span className="text-xs bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 font-semibold px-2 py-0.5 rounded">Requis</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {product.availableMeats.map((meat) => {
                  const isSelected = selectedMeat === meat;
                  return (
                    <button
                      key={meat}
                      type="button"
                      onClick={() => {
                        playSound('click', soundEnabled);
                        setSelectedMeat(meat);
                      }}
                      className={`p-3 rounded-xl border text-left text-sm font-semibold flex items-center justify-between transition-all ${
                        isSelected
                          ? 'border-red-600 bg-red-600/10 text-red-600 dark:text-red-400 font-bold shadow-sm'
                          : 'border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400'
                      }`}
                    >
                      <span>{meat}</span>
                      {isSelected && <Check className="w-4 h-4 text-red-600 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Sauce Selection (If available) */}
          {product.availableSauces && product.availableSauces.length > 0 && (
            <div className="space-y-3">
              <label className="font-heading font-bold text-base flex items-center gap-2 text-zinc-900 dark:text-white">
                <Flame className="w-4 h-4 text-red-600" />
                <span>Choisissez votre sauce</span>
                <span className="text-xs text-zinc-400 font-normal">Au choix</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {product.availableSauces.map((sauce) => {
                  const isSelected = selectedSauce === sauce;
                  return (
                    <button
                      key={sauce}
                      type="button"
                      onClick={() => {
                        playSound('click', soundEnabled);
                        setSelectedSauce(sauce);
                      }}
                      className={`p-3 rounded-xl border text-left text-sm font-semibold flex items-center justify-between transition-all ${
                        isSelected
                          ? 'border-yellow-500 bg-yellow-500/10 text-zinc-900 dark:text-yellow-400 font-bold shadow-sm'
                          : 'border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400'
                      }`}
                    >
                      <span>{sauce}</span>
                      {isSelected && <Check className="w-4 h-4 text-yellow-500 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Extra Supplements */}
          <div className="space-y-3 pt-2 border-t border-zinc-100 dark:border-zinc-800">
            <label className="font-heading font-bold text-base text-zinc-900 dark:text-white">
              Suppléments Gourmands
            </label>
            <div 
              onClick={() => {
                playSound('click', soundEnabled);
                setExtraCheese(!extraCheese);
              }}
              className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                extraCheese
                  ? 'border-red-600 bg-red-600/10 text-red-600 dark:text-red-400 font-bold'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400'
              }`}
            >
              <div className="flex items-center gap-3">
                <div className={`w-5 h-5 rounded flex items-center justify-center border ${
                  extraCheese ? 'bg-red-600 border-red-600 text-white' : 'border-zinc-400'
                }`}>
                  {extraCheese && <Check className="w-3.5 h-3.5" />}
                </div>
                <div>
                  <div className="text-sm font-semibold">🧀 Supplément Double Cheddar ou Raclette</div>
                  <div className="text-xs text-zinc-500">Pour un fondant incomparable</div>
                </div>
              </div>
              <span className="text-sm font-bold text-red-600 dark:text-yellow-400">+5 DH</span>
            </div>
          </div>

          {/* Special Notes */}
          <div className="space-y-2">
            <label htmlFor="notes" className="font-heading font-bold text-sm text-zinc-900 dark:text-white block">
              Instructions spéciales ou allergies
            </label>
            <input
              type="text"
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Pas d'oignons, bien cuit, sauce à part..."
              className="w-full px-4 py-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-700 text-zinc-900 dark:text-white placeholder-zinc-400 text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
            />
          </div>
        </div>

        {/* Footer Action */}
        <div className="p-4 sm:p-6 bg-zinc-50 dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4 shrink-0">
          {/* Quantity Selector */}
          <div className="flex items-center bg-white dark:bg-zinc-800 rounded-full border border-zinc-200 dark:border-zinc-700 p-1 w-full sm:w-auto justify-between sm:justify-start">
            <button
              type="button"
              onClick={() => {
                playSound('click', soundEnabled);
                setQuantity(Math.max(1, quantity - 1));
              }}
              className="w-10 h-10 rounded-full flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-700 transition-colors"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="w-12 text-center font-heading font-black text-lg text-zinc-900 dark:text-white">
              {quantity}
            </span>
            <button
              type="button"
              onClick={() => {
                playSound('click', soundEnabled);
                setQuantity(quantity + 1);
              }}
              className="w-10 h-10 rounded-full flex items-center justify-center text-zinc-700 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-700 transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Submit Button */}
          <button
            type="button"
            onClick={handleAdd}
            className="w-full sm:flex-1 py-4 px-6 rounded-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-heading font-black text-base sm:text-lg uppercase tracking-wider shadow-xl shadow-red-600/30 flex items-center justify-between gap-2 transition-all active:scale-95"
          >
            <span className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              <span>Ajouter à la commande</span>
            </span>
            <span className="bg-black/30 px-3 py-1 rounded-full text-yellow-400">
              {calculatedPrice} DH
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
