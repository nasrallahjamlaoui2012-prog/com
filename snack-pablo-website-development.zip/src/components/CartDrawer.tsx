import React from 'react';
import { CartItem } from '../types';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Store } from 'lucide-react';
import { playSound } from '../utils/sound';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
  soundEnabled: boolean;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
  soundEnabled,
}) => {
  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => {
    const itemPrice = item.product.price + (item.extraCheese ? 5 : 0);
    return sum + itemPrice * item.quantity;
  }, 0);

  const handleCheckout = () => {
    playSound('pop', soundEnabled);
    onClose();
    onProceedToCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fade-in">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity" 
        onClick={() => {
          playSound('click', soundEnabled);
          onClose();
        }}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-zinc-900 shadow-2xl flex flex-col justify-between border-l border-zinc-200 dark:border-zinc-800 transition-colors z-10">
          
          {/* Header */}
          <div className="p-6 bg-zinc-900 text-white flex items-center justify-between border-b border-zinc-800">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-6 h-6 text-red-500" />
              <h2 className="font-heading font-black text-xl uppercase tracking-wider">
                Mon Panier ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => {
                playSound('click', soundEnabled);
                onClose();
              }}
              className="p-2 rounded-full bg-zinc-800 hover:bg-red-600 text-white transition-colors focus:outline-none"
              title="Fermer le panier"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Items Body */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-20">
                <ShoppingBag className="w-16 h-16 text-zinc-300 dark:text-zinc-700 mx-auto mb-4" />
                <h3 className="font-heading font-bold text-lg text-zinc-800 dark:text-zinc-200 mb-1">
                  Votre panier est vide
                </h3>
                <p className="text-zinc-500 text-xs sm:text-sm max-w-xs mx-auto mb-8">
                  Ajoutez nos succulents Tacos au gratin, Smash Burgers ou Pizzas cuites au feu de bois !
                </p>
                <button
                  onClick={() => {
                    playSound('click', soundEnabled);
                    onClose();
                    document.querySelector('#menu')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-6 py-3 rounded-full bg-red-600 text-white font-heading font-bold text-sm uppercase tracking-wider shadow-lg shadow-red-600/30"
                >
                  Découvrir le menu
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between pb-2 border-b border-zinc-200 dark:border-zinc-800 text-xs text-zinc-500 font-semibold">
                  <span>Plats sélectionnés</span>
                  <button
                    onClick={() => {
                      playSound('pop', soundEnabled);
                      onClearCart();
                    }}
                    className="text-red-500 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Tout vider</span>
                  </button>
                </div>

                {cart.map((item, index) => {
                  const itemPrice = item.product.price + (item.extraCheese ? 5 : 0);
                  return (
                    <div
                      key={index}
                      className="p-3.5 rounded-2xl bg-zinc-50 dark:bg-zinc-800/60 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-14 h-14 rounded-xl object-cover shrink-0"
                      />

                      <div className="flex-1 min-w-0">
                        <h4 className="font-heading font-black text-xs sm:text-sm text-zinc-900 dark:text-white truncate">
                          {item.product.name}
                        </h4>
                        <div className="text-[11px] text-zinc-500 dark:text-zinc-400 space-y-0.5 mt-0.5">
                          {item.selectedMeat && <div className="truncate">Viande: {item.selectedMeat}</div>}
                          {item.selectedSauce && <div className="truncate">Sauce: {item.selectedSauce}</div>}
                          {item.extraCheese && <div className="text-red-500 font-bold">+ Double Cheddar (+5 DH)</div>}
                        </div>
                        <div className="font-heading font-extrabold text-sm text-red-600 dark:text-yellow-400 mt-1">
                          {itemPrice * item.quantity} DH
                        </div>
                      </div>

                      {/* Controls */}
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            playSound('pop', soundEnabled);
                            onRemoveItem(index);
                          }}
                          className="text-zinc-400 hover:text-red-500 transition-colors p-1"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>

                        <div className="flex items-center bg-white dark:bg-zinc-900 rounded-full border border-zinc-200 dark:border-zinc-700 p-0.5">
                          <button
                            type="button"
                            onClick={() => {
                              playSound('click', soundEnabled);
                              onUpdateQuantity(index, item.quantity - 1);
                            }}
                            className="w-6 h-6 rounded-full flex items-center justify-center text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs font-bold"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center font-heading font-black text-xs text-zinc-900 dark:text-white">
                            {item.quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              playSound('click', soundEnabled);
                              onUpdateQuantity(index, item.quantity + 1);
                            }}
                            className="w-6 h-6 rounded-full flex items-center justify-center text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs font-bold"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>

          {/* Footer Subtotal & Actions */}
          {cart.length > 0 && (
            <div className="p-6 bg-zinc-50 dark:bg-zinc-950 border-t border-zinc-200 dark:border-zinc-800 space-y-4">
              <div className="flex justify-between items-baseline">
                <span className="text-sm font-bold text-zinc-600 dark:text-zinc-400">Sous-total :</span>
                <span className="font-heading font-black text-2xl text-zinc-900 dark:text-white">{subtotal} <span className="text-sm text-red-600">DH</span></span>
              </div>

              <div className="text-xs text-zinc-500 dark:text-zinc-400 bg-yellow-400/10 p-2.5 rounded-xl border border-yellow-400/20 flex items-center gap-2">
                <Store className="w-4 h-4 text-yellow-600 dark:text-yellow-400 shrink-0" />
                <span>Livraison ou retrait sur place calculés à l&apos;étape suivante.</span>
              </div>

              <button
                type="button"
                onClick={handleCheckout}
                className="w-full py-4 px-6 rounded-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-heading font-black text-base uppercase tracking-wider shadow-xl shadow-red-600/30 flex items-center justify-center gap-2 transition-all active:scale-95"
              >
                <span>Commander Maintenant</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
