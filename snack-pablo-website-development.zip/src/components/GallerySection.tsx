import React, { useState, useMemo } from 'react';
import { GALLERY_ITEMS } from '../data/gallery';
import { Camera, Eye, Heart, X, ChevronLeft, ChevronRight, ZoomIn, ZoomOut } from 'lucide-react';
import { playSound } from '../utils/sound';

interface GallerySectionProps {
  soundEnabled: boolean;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ soundEnabled }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [zoomed, setZoomed] = useState(false);
  const [likes, setLikes] = useState<{ [key: string]: number }>(
    GALLERY_ITEMS.reduce((acc, item) => ({ ...acc, [item.id]: item.likes }), {})
  );

  const filters = [
    { id: 'all', label: 'Tout voir' },
    { id: 'tacos', label: 'Tacos Gratinés' },
    { id: 'burgers', label: 'Smash Burgers' },
    { id: 'pizzas', label: 'Pizzas Feu de Bois' },
    { id: 'ambiance', label: 'Notre Ambiance' },
    { id: 'desserts', label: 'Desserts & Drinks' },
  ];

  const filteredItems = useMemo(() => {
    if (selectedFilter === 'all') return GALLERY_ITEMS;
    return GALLERY_ITEMS.filter((item) => item.category === selectedFilter);
  }, [selectedFilter]);

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('pop', soundEnabled);
    setLikes((prev) => ({ ...prev, [id]: prev[id] + 1 }));
  };

  const openLightbox = (index: number) => {
    playSound('click', soundEnabled);
    setLightboxIndex(index);
    setZoomed(false);
  };

  const nextSlide = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (lightboxIndex !== null && filteredItems.length > 0) {
      playSound('click', soundEnabled);
      setLightboxIndex((lightboxIndex + 1) % filteredItems.length);
      setZoomed(false);
    }
  };

  const prevSlide = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (lightboxIndex !== null && filteredItems.length > 0) {
      playSound('click', soundEnabled);
      setLightboxIndex((lightboxIndex - 1 + filteredItems.length) % filteredItems.length);
      setZoomed(false);
    }
  };

  return (
    <section id="galerie" className="py-20 sm:py-28 bg-zinc-50 dark:bg-zinc-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-600/10 dark:bg-red-600/20 text-red-600 dark:text-red-400 text-xs font-black uppercase tracking-wider mb-3">
            <Camera className="w-3.5 h-3.5" />
            <span>Galerie Photo Authentique</span>
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-zinc-900 dark:text-white uppercase tracking-tight mb-4">
            PLONGEZ AU COEUR DE <span className="text-red-600">NOTRE CUISINE</span>
          </h2>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm sm:text-lg leading-relaxed">
            De vraies photos de nos plats à la sortie de la plancha et du four ! Cliquez sur une image pour l&apos;agrandir en haute définition ou likez vos créations préférées.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-10">
          {filters.map((f) => {
            const isSelected = selectedFilter === f.id;
            return (
              <button
                key={f.id}
                onClick={() => {
                  playSound('click', soundEnabled);
                  setSelectedFilter(f.id);
                }}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-heading font-extrabold uppercase tracking-wider transition-all shadow-sm ${
                  isSelected
                    ? 'bg-zinc-900 dark:bg-white text-white dark:text-zinc-950 shadow-md scale-105'
                    : 'bg-white dark:bg-zinc-900 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-800'
                }`}
              >
                {f.label}
              </button>
            );
          })}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => openLightbox(idx)}
              className="group relative h-64 sm:h-72 rounded-3xl overflow-hidden bg-zinc-900 cursor-pointer shadow-md hover:shadow-2xl transition-all transform hover:-translate-y-1"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700 ease-out"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-5">
                <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
                  <span className="text-[10px] font-extrabold text-yellow-400 uppercase tracking-widest block mb-1">
                    {item.category}
                  </span>
                  <h3 className="font-heading font-black text-white text-base leading-snug mb-2">
                    {item.title}
                  </h3>
                  <p className="text-zinc-300 text-xs line-clamp-2">
                    {item.description}
                  </p>
                </div>
              </div>

              {/* Top Icons on Hover */}
              <div className="absolute top-3 left-3 right-3 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <span className="p-2 rounded-full bg-black/50 backdrop-blur-md text-white">
                  <Eye className="w-4 h-4 text-yellow-400" />
                </span>
                <button
                  type="button"
                  onClick={(e) => handleLike(item.id, e)}
                  className="px-3 py-1.5 rounded-full bg-black/60 hover:bg-red-600/80 backdrop-blur-md text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Heart className="w-3.5 h-3.5 fill-red-500 text-red-500" />
                  <span>{likes[item.id] || item.likes}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {lightboxIndex !== null && filteredItems[lightboxIndex] && (
        <div
          onClick={() => setLightboxIndex(null)}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-8 animate-fade-in"
        >
          {/* Close Button */}
          <button
            onClick={() => setLightboxIndex(null)}
            className="absolute top-6 right-6 p-3 rounded-full bg-zinc-800/80 hover:bg-red-600 text-white transition-colors z-50 focus:outline-none"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Zoom toggle button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setZoomed(!zoomed);
            }}
            className="absolute top-6 right-20 p-3 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-white transition-colors z-50 focus:outline-none hidden sm:block"
            title={zoomed ? "Dézoomer" : "Zoomer au maximum"}
          >
            {zoomed ? <ZoomOut className="w-6 h-6 text-yellow-400" /> : <ZoomIn className="w-6 h-6 text-yellow-400" />}
          </button>

          {/* Prev Button */}
          <button
            onClick={prevSlide}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 p-3 sm:p-4 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-white transition-colors z-50 focus:outline-none"
          >
            <ChevronLeft className="w-6 h-6 sm:w-8 sm:h-8" />
          </button>

          {/* Next Button */}
          <button
            onClick={nextSlide}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 p-3 sm:p-4 rounded-full bg-zinc-800/80 hover:bg-zinc-700 text-white transition-colors z-50 focus:outline-none"
          >
            <ChevronRight className="w-6 h-6 sm:w-8 sm:h-8" />
          </button>

          {/* Content Container */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-w-5xl max-h-[85vh] w-full flex flex-col items-center justify-center relative rounded-3xl overflow-hidden bg-zinc-900 border border-zinc-800 shadow-2xl"
          >
            <div className={`w-full overflow-hidden flex items-center justify-center bg-black transition-all ${
              zoomed ? 'max-h-[70vh] sm:max-h-[80vh] overflow-auto cursor-zoom-out' : 'max-h-[60vh] sm:max-h-[65vh] cursor-zoom-in'
            }`} onClick={() => setZoomed(!zoomed)}>
              <img
                src={filteredItems[lightboxIndex].image}
                alt={filteredItems[lightboxIndex].title}
                className={`object-contain transition-all duration-300 ${
                  zoomed ? 'scale-150 max-w-none' : 'max-h-[60vh] sm:max-h-[65vh] w-auto'
                }`}
              />
            </div>

            {/* Bottom Info Bar */}
            <div className="w-full p-4 sm:p-6 bg-zinc-900/90 border-t border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-black text-red-500 uppercase tracking-widest block mb-1">
                  {filteredItems[lightboxIndex].category} — Photo {lightboxIndex + 1} sur {filteredItems.length}
                </span>
                <h3 className="font-heading font-black text-xl sm:text-2xl text-white">
                  {filteredItems[lightboxIndex].title}
                </h3>
                <p className="text-zinc-400 text-xs sm:text-sm mt-1 max-w-2xl">
                  {filteredItems[lightboxIndex].description}
                </p>
              </div>

              <button
                type="button"
                onClick={(e) => handleLike(filteredItems[lightboxIndex].id, e)}
                className="px-5 py-2.5 rounded-full bg-red-600/20 hover:bg-red-600 text-red-500 hover:text-white border border-red-500/30 text-sm font-bold flex items-center gap-2 transition-all shrink-0"
              >
                <Heart className="w-4 h-4 fill-current" />
                <span>J&apos;adore ({likes[filteredItems[lightboxIndex].id] || filteredItems[lightboxIndex].likes})</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
