import React, { useState } from 'react';
import { CartItem, OrderDetails } from '../types';
import { 
  ShoppingBag, 
  Trash2, 
  Plus, 
  Minus, 
  Truck, 
  Store, 
  CreditCard, 
  Banknote, 
  CheckCircle, 
  PhoneCall, 
  MapPin, 
  Send,
  AlertCircle,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { playSound } from '../utils/sound';

interface OnlineOrderSectionProps {
  cart: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
  soundEnabled: boolean;
}

export const OnlineOrderSection: React.FC<OnlineOrderSectionProps> = ({
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  soundEnabled,
}) => {
  const [orderType, setOrderType] = useState<'livraison' | 'emporter'>('livraison');
  const [city, setCity] = useState<'Martil Centre' | 'Martil Corniche' | 'Cabo Negro' | 'Mdiq' | 'Tetouan'>('Martil Centre');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card_delivery' | 'online_card'>('cash');
  
  // Form fields
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  
  // Order completed state
  const [completedOrder, setCompletedOrder] = useState<OrderDetails | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Calculations
  const subtotal = cart.reduce((sum, item) => {
    const itemPrice = item.product.price + (item.extraCheese ? 5 : 0);
    return sum + itemPrice * item.quantity;
  }, 0);

  const deliveryFee = (() => {
    if (orderType === 'emporter') return 0;
    if (subtotal >= 150) return 0; // Livraison gratuite à partir de 150 DH
    if (city === 'Martil Centre' || city === 'Martil Corniche') return 10;
    if (city === 'Cabo Negro') return 15;
    return 20; // Mdiq ou Tetouan
  })();

  const total = subtotal + deliveryFee;

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!name.trim()) newErrors.name = 'Veuillez indiquer votre nom complet';
    if (!phone.trim() || phone.length < 9) newErrors.phone = 'Numéro de téléphone marocain valide requis';
    if (orderType === 'livraison' && !address.trim()) newErrors.address = 'Adresse de livraison requise';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    
    if (!validateForm()) {
      playSound('click', soundEnabled);
      return;
    }

    setIsSubmitting(true);
    playSound('bell', soundEnabled);

    setTimeout(() => {
      const orderId = `PABLO-${Math.floor(100000 + Math.random() * 900000)}`;
      const orderData: OrderDetails = {
        customerName: name,
        phone,
        address: orderType === 'livraison' ? `${address}, ${city}` : 'À emporter (Snack Pablo Martil)',
        city,
        orderType,
        paymentMethod,
        notes: notes.trim() ? notes.trim() : undefined,
        items: [...cart],
        subtotal,
        deliveryFee,
        total,
        orderId,
        createdAt: new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      };

      setCompletedOrder(orderData);
      setIsSubmitting(false);
      onClearCart();
      playSound('success', soundEnabled);

      // Trigger Confetti
      try {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#dc2626', '#facc15', '#ffffff', '#000000'],
        });
      } catch {
        // ignore if canvas confetti fails
      }
    }, 1200);
  };

  const handleWhatsAppOrder = (order: OrderDetails) => {
    playSound('pop', soundEnabled);
    const itemsList = order.items
      .map(
        (i) =>
          `▪️ ${i.quantity}x *${i.product.name}* (${i.product.price * i.quantity} DH)\n` +
          `${i.selectedMeat ? `   Viande: ${i.selectedMeat}\n` : ''}` +
          `${i.selectedSauce ? `   Sauce: ${i.selectedSauce}\n` : ''}` +
          `${i.extraCheese ? `   +Supplément Fromage (+5 DH)\n` : ''}` +
          `${i.notes ? `   Notes: ${i.notes}\n` : ''}`
      )
      .join('');

    const text = 
      `🚨 *NOUVELLE COMMANDE EN LIGNE - SNACK PABLO MARTIL* 🚨\n\n` +
      `📌 *N° Commande:* #${order.orderId}\n` +
      `👤 *Client:* ${order.customerName}\n` +
      `📞 *Téléphone:* ${order.phone}\n` +
      `🛵 *Type:* ${order.orderType === 'livraison' ? `Livraison (${order.city})` : 'À Emporter'}\n` +
      `${order.orderType === 'livraison' ? `📍 *Adresse:* ${order.address}\n` : ''}` +
      `💳 *Paiement:* ${
        order.paymentMethod === 'cash' ? 'Espèces à la réception' : order.paymentMethod === 'card_delivery' ? 'TPE Carte à la livraison' : 'Paiement en ligne'
      }\n\n` +
      `🛒 *DÉTAIL DU PANIER :*\n${itemsList}\n` +
      `-----------------------------\n` +
      `💵 *Sous-total:* ${order.subtotal} DH\n` +
      `🚚 *Frais de livraison:* ${order.deliveryFee === 0 ? 'GRATUIT' : `${order.deliveryFee} DH`}\n` +
      `💰 *TOTAL À PAYER:* *${order.total} DH*\n\n` +
      `🙏 Merci de valider la préparation de ma commande !`;

    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/212600000000?text=${encoded}`, '_blank');
  };

  return (
    <section id="commande" className="py-20 sm:py-28 bg-white dark:bg-zinc-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-600/10 dark:bg-red-600/20 text-red-600 dark:text-red-400 text-xs font-black uppercase tracking-wider mb-3">
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Commande en ligne directe</span>
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-zinc-900 dark:text-white uppercase tracking-tight mb-4">
            VOTRE PANIER & <span className="text-red-600">VALIDATION</span>
          </h2>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm sm:text-lg leading-relaxed">
            Configurez votre livraison ou votre commande à emporter. Calcul automatique en temps réel et validation instantanée !
          </p>
        </div>

        {completedOrder ? (
          /* SUCCESS ORDER SCREEN */
          <div className="max-w-2xl mx-auto bg-zinc-900 text-white rounded-3xl p-6 sm:p-10 shadow-2xl border-2 border-emerald-500 animate-slide-up text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="w-20 h-20 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-500/40">
              <CheckCircle className="w-12 h-12 animate-bounce" />
            </div>

            <span className="bg-yellow-400 text-zinc-950 text-xs font-black uppercase tracking-widest px-4 py-1 rounded-full inline-block mb-3">
              Commande Confirmée
            </span>
            <h3 className="font-heading font-black text-2xl sm:text-4xl mb-2">
              Merci, {completedOrder.customerName} !
            </h3>
            <p className="text-zinc-300 text-sm sm:text-base mb-6">
              Votre commande <strong className="text-white font-bold">#{completedOrder.orderId}</strong> a été enregistrée avec succès à {completedOrder.createdAt}. Notre cuisine prépare votre festin !
            </p>

            {/* Order Summary Receipt Box */}
            <div className="bg-zinc-950/80 rounded-2xl p-5 border border-zinc-800 text-left mb-8 space-y-3 text-sm">
              <div className="flex justify-between pb-3 border-b border-zinc-800">
                <span className="text-zinc-400">Type de commande :</span>
                <span className="font-bold text-yellow-400 uppercase">
                  {completedOrder.orderType === 'livraison' ? `🛵 Livraison (${completedOrder.city})` : '🛍️ À emporter sur place'}
                </span>
              </div>
              <div className="flex justify-between pb-3 border-b border-zinc-800">
                <span className="text-zinc-400">Téléphone de contact :</span>
                <span className="font-bold text-white">{completedOrder.phone}</span>
              </div>
              {completedOrder.orderType === 'livraison' && (
                <div className="flex justify-between pb-3 border-b border-zinc-800">
                  <span className="text-zinc-400">Adresse de livraison :</span>
                  <span className="font-bold text-white text-right max-w-xs">{completedOrder.address}</span>
                </div>
              )}
              <div className="flex justify-between pb-3 border-b border-zinc-800">
                <span className="text-zinc-400">Mode de paiement :</span>
                <span className="font-bold text-white">
                  {completedOrder.paymentMethod === 'cash' && '💵 Espèces à la livraison/réception'}
                  {completedOrder.paymentMethod === 'card_delivery' && '💳 Carte bancaire (TPE au livreur)'}
                  {completedOrder.paymentMethod === 'online_card' && '🔒 Paiement en ligne (Simulé Validé)'}
                </span>
              </div>

              {/* Items */}
              <div className="pt-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 block mb-2">Articles commandés :</span>
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-2">
                  {completedOrder.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-xs sm:text-sm">
                      <span className="text-zinc-300">
                        <strong className="text-white font-bold">{item.quantity}x</strong> {item.product.name}
                        {item.extraCheese && ' (+Fromage)'}
                      </span>
                      <span className="font-bold text-white">{(item.product.price + (item.extraCheese ? 5 : 0)) * item.quantity} DH</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total */}
              <div className="pt-3 border-t border-zinc-700 flex justify-between items-baseline font-heading font-black text-lg">
                <span className="text-yellow-400">TOTAL PAYÉ :</span>
                <span className="text-2xl text-white">{completedOrder.total} DH</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => handleWhatsAppOrder(completedOrder)}
                className="py-4 px-8 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white font-heading font-black text-sm uppercase tracking-wider shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2.5 transition-all hover:scale-105"
              >
                <Send className="w-5 h-5" />
                <span>Envoyer au WhatsApp du Restaurant</span>
              </button>

              <button
                onClick={() => {
                  playSound('click', soundEnabled);
                  setCompletedOrder(null);
                }}
                className="py-4 px-6 rounded-full bg-zinc-800 hover:bg-zinc-700 text-white font-heading font-bold text-sm uppercase tracking-wider transition-all"
              >
                Passer une autre commande
              </button>
            </div>
          </div>
        ) : (
          /* ACTIVE CHECKOUT GRID */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
            
            {/* Left Side: Cart Items Review */}
            <div className="lg:col-span-6 space-y-6">
              <div className="bg-zinc-50 dark:bg-zinc-900 rounded-3xl p-6 sm:p-8 border border-zinc-200 dark:border-zinc-800 shadow-lg">
                <div className="flex items-center justify-between pb-4 border-b border-zinc-200 dark:border-zinc-800 mb-6">
                  <h3 className="font-heading font-black text-xl sm:text-2xl text-zinc-900 dark:text-white flex items-center gap-2.5">
                    <ShoppingBag className="w-6 h-6 text-red-600" />
                    <span>Récapitulatif ({cart.reduce((a, b) => a + b.quantity, 0)})</span>
                  </h3>
                  {cart.length > 0 && (
                    <button
                      onClick={() => {
                        playSound('click', soundEnabled);
                        onClearCart();
                      }}
                      className="text-xs font-bold text-red-500 hover:text-red-700 dark:hover:text-red-400 flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Vider le panier</span>
                    </button>
                  )}
                </div>

                {cart.length === 0 ? (
                  <div className="text-center py-12">
                    <ShoppingBag className="w-16 h-16 text-zinc-300 dark:text-zinc-700 mx-auto mb-4" />
                    <h4 className="font-heading font-bold text-lg text-zinc-700 dark:text-zinc-300 mb-1">
                      Votre panier est vide pour le moment
                    </h4>
                    <p className="text-zinc-500 text-xs sm:text-sm max-w-sm mx-auto mb-6">
                      Rendez-vous dans la section Menu pour ajouter nos délicieux Tacos gratinés ou Smash Burgers !
                    </p>
                    <a
                      href="#menu"
                      onClick={(e) => {
                        e.preventDefault();
                        document.querySelector('#menu')?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-red-600 text-white font-heading font-bold text-sm uppercase tracking-wider shadow-lg shadow-red-600/30"
                    >
                      <span>Consulter le menu</span>
                      <ArrowRight className="w-4 h-4" />
                    </a>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
                    {cart.map((item, index) => {
                      const itemPrice = item.product.price + (item.extraCheese ? 5 : 0);
                      return (
                        <div
                          key={index}
                          className="p-4 rounded-2xl bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm"
                        >
                          <div className="flex items-center gap-3.5 flex-1">
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-16 h-16 rounded-xl object-cover shrink-0"
                            />
                            <div className="space-y-0.5">
                              <h4 className="font-heading font-black text-sm sm:text-base text-zinc-900 dark:text-white line-clamp-1">
                                {item.product.name}
                              </h4>
                              <div className="text-xs text-zinc-500 dark:text-zinc-400 space-y-0.5">
                                {item.selectedMeat && <div>Viande: <span className="font-semibold text-zinc-700 dark:text-zinc-300">{item.selectedMeat}</span></div>}
                                {item.selectedSauce && <div>Sauce: <span className="font-semibold text-zinc-700 dark:text-zinc-300">{item.selectedSauce}</span></div>}
                                {item.extraCheese && <div className="text-red-500 font-bold">+ Supplément Double Cheddar (+5 DH)</div>}
                                {item.notes && <div className="italic text-zinc-400">&quot;{item.notes}&quot;</div>}
                              </div>
                            </div>
                          </div>

                          {/* Controls & Price */}
                          <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-0 border-zinc-100 dark:border-zinc-800">
                            {/* Quantity */}
                            <div className="flex items-center bg-zinc-100 dark:bg-zinc-900 rounded-full border border-zinc-200 dark:border-zinc-800 p-1">
                              <button
                                type="button"
                                onClick={() => {
                                  playSound('click', soundEnabled);
                                  onUpdateQuantity(index, item.quantity - 1);
                                }}
                                className="w-7 h-7 rounded-full flex items-center justify-center text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-800"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-8 text-center font-heading font-black text-sm text-zinc-900 dark:text-white">
                                {item.quantity}
                              </span>
                              <button
                                type="button"
                                onClick={() => {
                                  playSound('click', soundEnabled);
                                  onUpdateQuantity(index, item.quantity + 1);
                                }}
                                className="w-7 h-7 rounded-full flex items-center justify-center text-zinc-600 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-800"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>

                            <div className="text-right shrink-0">
                              <div className="font-heading font-black text-base text-zinc-900 dark:text-white">
                                {itemPrice * item.quantity} <span className="text-xs text-red-600">DH</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  playSound('pop', soundEnabled);
                                  onRemoveItem(index);
                                }}
                                className="text-[11px] text-red-500 hover:underline flex items-center gap-0.5 ml-auto mt-0.5"
                              >
                                <span>Supprimer</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Subtotal & Delivery Breakdown */}
                {cart.length > 0 && (
                  <div className="mt-6 pt-6 border-t border-zinc-200 dark:border-zinc-800 space-y-3">
                    <div className="flex justify-between text-sm text-zinc-600 dark:text-zinc-400">
                      <span>Sous-total des plats :</span>
                      <span className="font-bold text-zinc-900 dark:text-white">{subtotal} DH</span>
                    </div>
                    
                    <div className="flex justify-between text-sm text-zinc-600 dark:text-zinc-400 items-center">
                      <span className="flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-yellow-500" />
                        <span>Frais de livraison ({orderType === 'livraison' ? city : 'À emporter'}) :</span>
                      </span>
                      <span className="font-bold text-zinc-900 dark:text-white">
                        {deliveryFee === 0 ? (
                          <span className="text-emerald-500 uppercase font-black">GRATUIT</span>
                        ) : (
                          `${deliveryFee} DH`
                        )}
                      </span>
                    </div>

                    {subtotal < 150 && orderType === 'livraison' && (
                      <div className="text-xs bg-yellow-400/10 text-yellow-600 dark:text-yellow-400 p-3 rounded-xl border border-yellow-400/20 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 shrink-0 animate-spin text-yellow-500" />
                        <span>Ajoutez encore <strong className="font-bold">{150 - subtotal} DH</strong> pour bénéficier de la <strong>livraison gratuite</strong> sur Martil & Cabo !</span>
                      </div>
                    )}

                    <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 flex justify-between items-baseline font-heading font-black">
                      <span className="text-lg text-zinc-900 dark:text-white">TOTAL À PAYER :</span>
                      <span className="text-3xl text-red-600 dark:text-yellow-400">{total} DH</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Right Side: Checkout Form & Payment */}
            <div className="lg:col-span-6">
              <form onSubmit={handleSubmitOrder} className="bg-zinc-50 dark:bg-zinc-900 rounded-3xl p-6 sm:p-8 border border-zinc-200 dark:border-zinc-800 shadow-lg space-y-6">
                <h3 className="font-heading font-black text-xl sm:text-2xl text-zinc-900 dark:text-white pb-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2.5">
                  <Store className="w-6 h-6 text-red-600" />
                  <span>1. Mode de réception</span>
                </h3>

                {/* Delivery vs Takeaway Selector */}
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      playSound('click', soundEnabled);
                      setOrderType('livraison');
                    }}
                    className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all ${
                      orderType === 'livraison'
                        ? 'bg-red-600 text-white border-red-600 shadow-lg shadow-red-600/30 font-bold scale-[1.02]'
                        : 'bg-white dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 font-semibold'
                    }`}
                  >
                    <Truck className="w-6 h-6" />
                    <span className="text-sm">🛵 Livraison Rapide</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playSound('click', soundEnabled);
                      setOrderType('emporter');
                    }}
                    className={`p-4 rounded-2xl border flex flex-col items-center justify-center gap-2 transition-all ${
                      orderType === 'emporter'
                        ? 'bg-red-600 text-white border-red-600 shadow-lg shadow-red-600/30 font-bold scale-[1.02]'
                        : 'bg-white dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 font-semibold'
                    }`}
                  >
                    <Store className="w-6 h-6" />
                    <span className="text-sm">🛍️ À Emporter (Sur place)</span>
                  </button>
                </div>

                {/* City Selection if Delivery */}
                {orderType === 'livraison' && (
                  <div className="space-y-2 pt-2 animate-fade-in">
                    <label className="font-heading font-bold text-sm text-zinc-900 dark:text-white flex items-center gap-1.5">
                      <MapPin className="w-4 h-4 text-red-600" />
                      <span>Zone de livraison dans la région</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {(['Martil Centre', 'Martil Corniche', 'Cabo Negro', 'Mdiq', 'Tetouan'] as const).map((c) => (
                        <button
                          key={c}
                          type="button"
                          onClick={() => {
                            playSound('click', soundEnabled);
                            setCity(c);
                          }}
                          className={`p-2.5 rounded-xl text-xs font-bold border transition-all ${
                            city === c
                              ? 'bg-yellow-400 text-zinc-950 border-yellow-400 shadow-sm font-black'
                              : 'bg-white dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400'
                          }`}
                        >
                          {c} {c === 'Martil Centre' || c === 'Martil Corniche' ? '(10 DH)' : c === 'Cabo Negro' ? '(15 DH)' : '(20 DH)'}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 2: Customer Information */}
                <h3 className="font-heading font-black text-xl sm:text-2xl text-zinc-900 dark:text-white pt-4 pb-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2.5">
                  <PhoneCall className="w-6 h-6 text-red-600" />
                  <span>2. Vos Coordonnées</span>
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                      Nom complet <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => {
                        setName(e.target.value);
                        if (errors.name) setErrors({ ...errors, name: '' });
                      }}
                      placeholder="Ex: Youssef El Alami"
                      className={`w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-950 border ${
                        errors.name ? 'border-red-500' : 'border-zinc-200 dark:border-zinc-800'
                      } text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600`}
                    />
                    {errors.name && <span className="text-xs text-red-500 font-semibold mt-1 block">{errors.name}</span>}
                  </div>

                  <div>
                    <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                      Téléphone Marocain <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => {
                        setPhone(e.target.value);
                        if (errors.phone) setErrors({ ...errors, phone: '' });
                      }}
                      placeholder="Ex: 06 00 00 00 00 ou +212 6..."
                      className={`w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-950 border ${
                        errors.phone ? 'border-red-500' : 'border-zinc-200 dark:border-zinc-800'
                      } text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600`}
                    />
                    {errors.phone && <span className="text-xs text-red-500 font-semibold mt-1 block">{errors.phone}</span>}
                  </div>

                  {orderType === 'livraison' && (
                    <div className="animate-fade-in">
                      <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                        Adresse précise de livraison <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={address}
                        onChange={(e) => {
                          setAddress(e.target.value);
                          if (errors.address) setErrors({ ...errors, address: '' });
                        }}
                        placeholder="Ex: Quartier Ahlam, Rue 4, Immeuble 12, Appt 3"
                        className={`w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-950 border ${
                          errors.address ? 'border-red-500' : 'border-zinc-200 dark:border-zinc-800'
                        } text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600`}
                      />
                      {errors.address && <span className="text-xs text-red-500 font-semibold mt-1 block">{errors.address}</span>}
                    </div>
                  )}

                  <div>
                    <label className="text-xs font-bold text-zinc-700 dark:text-zinc-300 uppercase block mb-1">
                      Note pour le livreur / cuisine (Optionnel)
                    </label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Ex: Appeler en arrivant en bas de l'immeuble, code porte..."
                      className="w-full px-4 py-3 rounded-xl bg-white dark:bg-zinc-950 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-600"
                    />
                  </div>
                </div>

                {/* Step 3: Payment Method */}
                <h3 className="font-heading font-black text-xl sm:text-2xl text-zinc-900 dark:text-white pt-4 pb-4 border-b border-zinc-200 dark:border-zinc-800 flex items-center gap-2.5">
                  <Banknote className="w-6 h-6 text-red-600" />
                  <span>3. Mode de paiement</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      playSound('click', soundEnabled);
                      setPaymentMethod('cash');
                    }}
                    className={`p-3.5 rounded-xl border flex items-center gap-3 text-left transition-all ${
                      paymentMethod === 'cash'
                        ? 'border-yellow-500 bg-yellow-500/10 text-zinc-900 dark:text-yellow-400 font-bold'
                        : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400'
                    }`}
                  >
                    <Banknote className="w-5 h-5 text-emerald-500 shrink-0" />
                    <div className="text-xs">
                      <div className="font-bold">Espèces</div>
                      <div className="text-[10px] text-zinc-400">À la livraison / caisse</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playSound('click', soundEnabled);
                      setPaymentMethod('card_delivery');
                    }}
                    className={`p-3.5 rounded-xl border flex items-center gap-3 text-left transition-all ${
                      paymentMethod === 'card_delivery'
                        ? 'border-yellow-500 bg-yellow-500/10 text-zinc-900 dark:text-yellow-400 font-bold'
                        : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-blue-500 shrink-0" />
                    <div className="text-xs">
                      <div className="font-bold">Carte Bancaire</div>
                      <div className="text-[10px] text-zinc-400">TPE au livreur</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      playSound('click', soundEnabled);
                      setPaymentMethod('online_card');
                    }}
                    className={`p-3.5 rounded-xl border flex items-center gap-3 text-left transition-all ${
                      paymentMethod === 'online_card'
                        ? 'border-yellow-500 bg-yellow-500/10 text-zinc-900 dark:text-yellow-400 font-bold'
                        : 'border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-950 text-zinc-700 dark:text-zinc-300 hover:border-zinc-400'
                    }`}
                  >
                    <Store className="w-5 h-5 text-purple-500 shrink-0" />
                    <div className="text-xs">
                      <div className="font-bold">Paiement Web</div>
                      <div className="text-[10px] text-zinc-400">Simulé Sécurisé</div>
                    </div>
                  </button>
                </div>

                {/* Submit Button */}
                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={cart.length === 0 || isSubmitting}
                    className={`w-full py-5 px-8 rounded-full font-heading font-black text-lg uppercase tracking-wider shadow-2xl flex items-center justify-center gap-3 transition-all duration-300 ${
                      cart.length === 0 || isSubmitting
                        ? 'bg-zinc-400 dark:bg-zinc-800 text-zinc-200 dark:text-zinc-600 cursor-not-allowed'
                        : 'bg-gradient-to-r from-red-600 via-red-600 to-yellow-500 hover:from-red-500 hover:to-yellow-400 text-white shadow-red-600/40 hover:scale-105 active:scale-95 animate-pulse-glow'
                    }`}
                  >
                    {isSubmitting ? (
                      <div className="flex items-center gap-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Transmission à la cuisine...</span>
                      </div>
                    ) : (
                      <>
                        <CheckCircle className="w-6 h-6" />
                        <span>Valider ma Commande ({total} DH)</span>
                      </>
                    )}
                  </button>
                  <p className="text-[11px] text-center text-zinc-400 mt-3 flex items-center justify-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>En cliquant, vous confirmez votre commande. Un SMS ou message WhatsApp de confirmation sera envoyé.</span>
                  </p>
                </div>
              </form>
            </div>

          </div>
        )}
      </div>
    </section>
  );
};
