import React, { useState } from 'react';
import { PROMOTIONS } from '../data/promotions';
import { PRODUCTS } from '../data/products';
import { CartItem } from '../types';
import { Tag, Clock, Copy, Check, Sparkles, ArrowRight } from 'lucide-react';
import { playSound } from '../utils/sound';

interface PromoSectionProps {
  onAddToCart: (item: CartItem) => void;
  soundEnabled: boolean;
}

export const PromoSection: React.FC<PromoSectionProps> = ({ onAddToCart, soundEnabled }) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    playSound('pop', soundEnabled);
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 3000);
  };

  const handleApplyPromo = (linkedProductId?: string) => {
    if (!linkedProductId) return;
    const product = PRODUCTS.find((p) => p.id === linkedProductId);
    if (product) {
      playSound('success', soundEnabled);
      onAddToCart({
        product,
        quantity: 1,
        notes: 'Offre promotionnelle appliquée',
      });
    }
  };

  return (
    <section id="promotions" className="py-20 sm:py-28 bg-zinc-900 text-white relative overflow-hidden">
      {/* Background Decorative Gradients */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-yellow-400/20 text-yellow-400 text-xs font-black uppercase tracking-wider mb-3">
            <Tag className="w-3.5 h-3.5" />
            <span>Bons Plans & Réductions</span>
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl uppercase tracking-tight mb-4">
            PROMOTIONS EXCLUSIVES <span className="text-yellow-400">MARTIL</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-lg leading-relaxed">
            Économisez sur vos plats préférés ! Profitez de notre Happy Hour, de nos formules étudiantes et des packs familiaux pour vos soirées sur la plage de Martil.
          </p>
        </div>

        {/* Promo Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {PROMOTIONS.map((promo) => {
            const isCopied = copiedCode === promo.code;
            return (
              <div
                key={promo.id}
                className="group bg-gradient-to-br from-zinc-800 to-zinc-900/90 rounded-3xl overflow-hidden border border-zinc-700/80 hover:border-yellow-500/60 shadow-xl hover:shadow-2xl transition-all duration-300 flex flex-col sm:flex-row"
              >
                {/* Left Image */}
                <div className="relative sm:w-2/5 h-48 sm:h-auto overflow-hidden shrink-0">
                  <img
                    src={promo.image}
                    alt={promo.title}
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-black/60 sm:from-transparent to-black/30" />
                  
                  <div className="absolute top-3 left-3 bg-red-600 text-white font-black text-xs uppercase px-3 py-1 rounded-full shadow-lg">
                    {promo.discount}
                  </div>
                </div>

                {/* Right Details */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-bold text-yellow-400 mb-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Valable jusqu'au {promo.validUntil}</span>
                    </div>
                    <h3 className="font-heading font-black text-xl text-white group-hover:text-yellow-400 transition-colors leading-tight mb-1">
                      {promo.title}
                    </h3>
                    <h4 className="text-xs font-extrabold text-red-500 uppercase tracking-wide mb-3">
                      {promo.subtitle}
                    </h4>
                    <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed">
                      {promo.description}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="pt-4 border-t border-zinc-700/60 flex flex-wrap items-center justify-between gap-3">
                    {/* Copy Code */}
                    <button
                      type="button"
                      onClick={() => handleCopyCode(promo.code)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all border ${
                        isCopied
                          ? 'bg-emerald-600 text-white border-emerald-500'
                          : 'bg-zinc-800 text-yellow-400 border-yellow-400/40 hover:bg-zinc-700'
                      }`}
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isCopied ? 'Code copié !' : `Code: ${promo.code}`}</span>
                    </button>

                    {/* Direct Add / Order button */}
                    {promo.linkedProductId && (
                      <button
                        type="button"
                        onClick={() => handleApplyPromo(promo.linkedProductId)}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-heading font-bold text-xs uppercase tracking-wider shadow-md hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5"
                      >
                        <span>Profiter</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer Guarantee */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-zinc-800/80 border border-zinc-700 text-zinc-300 text-xs sm:text-sm font-medium">
            <Sparkles className="w-4 h-4 text-yellow-400 animate-spin" />
            <span>Les codes promo sont à communiquer à notre livreur ou à appliquer directement lors de votre commande en ligne !</span>
          </div>
        </div>
      </div>
    </section>
  );
};
