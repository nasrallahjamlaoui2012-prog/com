import React, { useState } from 'react';
import { REVIEWS } from '../data/reviews';
import { Star, MessageSquare, ChevronLeft, ChevronRight, CheckCircle2, ThumbsUp } from 'lucide-react';
import { playSound } from '../utils/sound';

interface ReviewsSectionProps {
  soundEnabled: boolean;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ soundEnabled }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextReview = () => {
    playSound('click', soundEnabled);
    setCurrentIndex((prev) => (prev + 1) % REVIEWS.length);
  };

  const prevReview = () => {
    playSound('click', soundEnabled);
    setCurrentIndex((prev) => (prev - 1 + REVIEWS.length) % REVIEWS.length);
  };

  return (
    <section id="avis" className="py-20 sm:py-28 bg-white dark:bg-zinc-950 transition-colors relative overflow-hidden">
      {/* Decorative Blob */}
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-80 h-80 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-yellow-400/20 text-yellow-500 dark:text-yellow-400 text-xs font-black uppercase tracking-wider mb-3">
            <Star className="w-3.5 h-3.5 fill-yellow-400" />
            <span>4.9 / 5 sur +650 Avis Google & TripAdvisor</span>
          </div>
          <h2 className="font-heading font-black text-3xl sm:text-5xl lg:text-6xl text-zinc-900 dark:text-white uppercase tracking-tight mb-4">
            CE QUE DISENT NOS <span className="text-red-600">CLIENTS</span>
          </h2>
          <p className="text-zinc-600 dark:text-zinc-400 text-sm sm:text-lg leading-relaxed">
            Habitués de Martil, étudiants de la faculté ou vacanciers à Cabo Negro, découvrez pourquoi Snack Pablo est leur adresse incontournable !
          </p>
        </div>

        {/* Carousel Container */}
        <div className="max-w-4xl mx-auto relative">
          <div className="bg-zinc-50 dark:bg-zinc-900 rounded-3xl p-6 sm:p-12 border border-zinc-200 dark:border-zinc-800 shadow-xl relative overflow-hidden transition-all">
            <div className="absolute top-6 right-6 text-red-600/10 dark:text-red-600/20 pointer-events-none">
              <MessageSquare className="w-24 h-24 sm:w-32 sm:h-32" />
            </div>

            <div className="relative z-10 flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-8 text-center sm:text-left">
              {/* Avatar */}
              <img
                src={REVIEWS[currentIndex].avatar}
                alt={REVIEWS[currentIndex].name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full object-cover border-4 border-red-600 shadow-md shrink-0"
              />

              <div className="flex-1 space-y-4">
                {/* Rating Stars */}
                <div className="flex items-center justify-center sm:justify-start gap-1">
                  {Array.from({ length: REVIEWS[currentIndex].rating }).map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                  <span className="ml-2 text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Avis vérifié</span>
                  </span>
                </div>

                {/* Comment */}
                <p className="text-zinc-700 dark:text-zinc-200 text-base sm:text-xl font-medium italic leading-relaxed">
                  &quot;{REVIEWS[currentIndex].comment}&quot;
                </p>

                {/* Author Info */}
                <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-zinc-200 dark:border-zinc-800">
                  <div>
                    <h4 className="font-heading font-black text-lg text-zinc-900 dark:text-white">
                      {REVIEWS[currentIndex].name}
                    </h4>
                    <span className="text-xs text-zinc-500 dark:text-zinc-400 block">
                      {REVIEWS[currentIndex].role}
                    </span>
                  </div>
                  <div className="text-xs font-bold bg-red-600/10 dark:bg-red-900/30 text-red-600 dark:text-red-400 px-3 py-1 rounded-full self-center sm:self-auto">
                    Plat adoré : {REVIEWS[currentIndex].dish}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prevReview}
              className="p-3.5 rounded-full bg-zinc-100 dark:bg-zinc-800 hover:bg-red-600 hover:text-white text-zinc-700 dark:text-zinc-300 transition-all shadow-md focus:outline-none"
              aria-label="Avis précédent"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-2">
              {REVIEWS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    playSound('click', soundEnabled);
                    setCurrentIndex(idx);
                  }}
                  className={`h-2.5 rounded-full transition-all duration-300 ${
                    idx === currentIndex ? 'w-8 bg-red-600' : 'w-2.5 bg-zinc-300 dark:bg-zinc-700'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={nextReview}
              className="p-3.5 rounded-full bg-zinc-100 dark:bg-zinc-800 hover:bg-red-600 hover:text-white text-zinc-700 dark:text-zinc-300 transition-all shadow-md focus:outline-none"
              aria-label="Avis suivant"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Call to leave review */}
        <div className="mt-12 text-center">
          <a
            href="https://maps.google.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-zinc-100 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:text-red-600 text-xs sm:text-sm font-bold border border-zinc-200 dark:border-zinc-800 transition-all"
          >
            <ThumbsUp className="w-4 h-4 text-red-600" />
            <span>Vous avez mangé chez nous ? Laissez votre avis sur Google Maps !</span>
          </a>
        </div>
      </div>
    </section>
  );
};
