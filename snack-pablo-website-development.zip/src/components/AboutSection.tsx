import React from 'react';
import { Flame, Clock, ShieldCheck, Award, HeartHandshake, CheckCircle2 } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="apropos" className="py-20 sm:py-28 bg-white dark:bg-zinc-950 transition-colors overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Side: Photo Mosaic */}
          <div className="lg:col-span-6 relative">
            <div className="grid grid-cols-2 gap-4 relative z-10">
              <div className="space-y-4">
                <div className="h-48 sm:h-64 rounded-3xl overflow-hidden shadow-xl transform -rotate-2 hover:rotate-0 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=600&q=80"
                    alt="Restaurant Ambiance Snack Pablo Martil"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="h-36 sm:h-48 rounded-3xl overflow-hidden shadow-xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&w=600&q=80"
                    alt="Préparation sur Plancha"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="h-36 sm:h-48 rounded-3xl overflow-hidden shadow-xl transform rotate-1 hover:rotate-0 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80"
                    alt="Smash Burger Gourmet"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="h-48 sm:h-64 rounded-3xl overflow-hidden shadow-xl transform -rotate-1 hover:rotate-0 transition-transform duration-500">
                  <img
                    src="https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=600&q=80"
                    alt="Tacos au Gratin Pablo"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Floating Experience Badge */}
            <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 sm:-left-6 sm:translate-x-0 z-20 bg-gradient-to-tr from-red-600 to-red-700 text-white p-6 rounded-3xl shadow-2xl border-4 border-white dark:border-zinc-900 flex items-center gap-4 max-w-xs">
              <div className="p-3 bg-white/20 rounded-2xl shrink-0">
                <Award className="w-8 h-8 text-yellow-300" />
              </div>
              <div>
                <div className="font-heading font-black text-3xl leading-none">100%</div>
                <div className="text-xs font-bold uppercase tracking-wider text-yellow-300 mt-1">Viande Fraîche & Halal</div>
              </div>
            </div>

            {/* Background Decorative Blob */}
            <div className="absolute -inset-4 bg-gradient-to-tr from-red-600/10 to-yellow-500/10 rounded-[3rem] blur-2xl -z-10" />
          </div>

          {/* Right Side: Narrative Content */}
          <div className="lg:col-span-6 space-y-6 pt-6 sm:pt-0">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-red-600/10 dark:bg-red-600/20 text-red-600 dark:text-red-400 text-xs font-black uppercase tracking-wider">
              <Flame className="w-3.5 h-3.5 fill-red-600" />
              <span>Notre Histoire à Martil</span>
            </div>

            <h2 className="font-heading font-black text-3xl sm:text-5xl text-zinc-900 dark:text-white uppercase tracking-tight leading-none">
              LE REPAIRE DU <span className="text-red-600">VRAI GOÛT</span> SUR LA CÔTE
            </h2>

            <p className="text-zinc-600 dark:text-zinc-300 text-sm sm:text-base leading-relaxed">
              Né d&apos;une passion pour la restauration rapide moderne et qualitative, <strong className="text-zinc-900 dark:text-white">Snack Pablo Martil</strong> s&apos;est imposé comme l&apos;adresse de référence pour tous les amoureux de <span className="text-red-600 font-semibold">Tacos au gratin</span>, de <span className="text-red-600 font-semibold">Smash Burgers</span> et de pizzas artisanales dans la région de Tétouan.
            </p>

            <p className="text-zinc-600 dark:text-zinc-300 text-sm sm:text-base leading-relaxed">
              Situé idéalement à quelques pas de la corniche et de la plage dorée de Martil, notre établissement vous accueille dans un cadre propre et climatisé, ou vous livre directement chez vous, que vous soyez au centre-ville, à Mdiq ou à Cabo Negro.
            </p>

            {/* Three Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-red-600/10 dark:bg-red-900/30 text-red-600 dark:text-red-400 flex items-center justify-center">
                  <Flame className="w-5 h-5 fill-red-600" />
                </div>
                <h3 className="font-heading font-bold text-base text-zinc-900 dark:text-white">
                  Sauce Fromagère Secrète
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Préparée chaque matin avec du vrai fromage affiné et de la crème fraîche pour un gratin parfait.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-yellow-500/10 dark:bg-yellow-500/20 text-yellow-500 flex items-center justify-center">
                  <Clock className="w-5 h-5" />
                </div>
                <h3 className="font-heading font-bold text-base text-zinc-900 dark:text-white">
                  Livraison Éclair 15 min
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Des scooters thermiques équipés de caissons isothermes pour que votre plat arrive bouillant.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 dark:bg-emerald-500/20 text-emerald-500 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h3 className="font-heading font-bold text-base text-zinc-900 dark:text-white">
                  Hygiène Irréprochable
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Des normes sanitaires strictes et une cuisine ouverte sur notre plancha pour une transparence totale.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 dark:bg-blue-500/20 text-blue-500 flex items-center justify-center">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <h3 className="font-heading font-bold text-base text-zinc-900 dark:text-white">
                  Esprit Convivial
                </h3>
                <p className="text-xs text-zinc-500 dark:text-zinc-400">
                  Une équipe jeune et souriante à votre écoute jusqu&apos;à 3h du matin tous les jours de la semaine !
                </p>
              </div>
            </div>

            {/* Bullet Points */}
            <div className="space-y-2 pt-2">
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-zinc-700 dark:text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Pain brioché et baguettes livrés frais par notre artisan boulanger local.</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-zinc-700 dark:text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Frites croustillantes double cuisson sans huile superflue.</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-zinc-700 dark:text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Emballages thermiques adaptés pour emporter sur la plage.</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
};
