import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  ShoppingBag, 
  Utensils, 
  Clock, 
  Star, 
  Sparkles, 
  ChevronDown,
  ShieldCheck
} from 'lucide-react';
import { playSound } from '../utils/sound';

interface HeroProps {
  onOrderNow: () => void;
  soundEnabled: boolean;
}

const HERO_IMAGES = [
  {
    url: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&w=1920&q=80',
    title: 'Tacos au Gratin Cheddar & Mozza',
    subtitle: 'La Spécialité Incontournable de Martil'
  },
  {
    url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=1920&q=80',
    title: 'Smash Burgers 100% Viande Fraîche',
    subtitle: 'Steaks dorés sur plaque et buns artisanaux'
  },
  {
    url: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=1920&q=80',
    title: 'Pizzas Artisanales au Feu de Bois',
    subtitle: 'Pâte à fermentation lente 48h et fromage fondant'
  },
  {
    url: 'https://images.unsplash.com/photo-1509722747041-616f39b57569?auto=format&fit=crop&w=1920&q=80',
    title: 'Bocadillos & Sandwichs du Nord',
    subtitle: 'Le goût authentique et généreux à chaque bouchée'
  }
];

export const Hero: React.FC<HeroProps> = ({ onOrderNow, soundEnabled }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_IMAGES.length);
    }, 5500);

    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      clearInterval(timer);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const scrollToMenu = () => {
    playSound('click', soundEnabled);
    const element = document.querySelector('#menu');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOrderBtn = () => {
    playSound('pop', soundEnabled);
    onOrderNow();
  };

  return (
    <section id="accueil" className="relative min-h-screen w-full flex items-center justify-center overflow-hidden bg-zinc-950">
      {/* Background Parallax & Ken Burns Zoom Carousel */}
      {HERO_IMAGES.map((img, idx) => {
        const isActive = idx === currentSlide;
        return (
          <div
            key={idx}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
            }`}
            style={{
              transform: `translateY(${scrollY * 0.4}px)`, // Parallax effect
            }}
          >
            <img
              src={img.url}
              alt={img.title}
              className={`w-full h-full object-cover object-center ${
                isActive ? 'animate-kenburns' : ''
              }`}
            />
          </div>
        );
      })}

      {/* Dark & Warm Red Gradients Overlay */}
      <div className="absolute inset-0 z-20 bg-gradient-to-t from-zinc-950 via-zinc-950/70 to-zinc-950/40" />
      <div className="absolute inset-0 z-20 bg-radial-gradient from-transparent via-black/40 to-black/80 pointer-events-none" />

      {/* Decorative Floating Glowing Orbs */}
      <div className="absolute top-1/4 left-10 w-72 h-72 bg-red-600/15 rounded-full blur-3xl z-20 animate-float pointer-events-none" />
      <div className="absolute bottom-1/3 right-10 w-80 h-80 bg-yellow-500/10 rounded-full blur-3xl z-20 animate-float pointer-events-none" style={{ animationDelay: '2s' }} />

      {/* Hero Content (Fade In + Slide Up) */}
      <div className="relative z-30 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-24 pb-16">
        {/* Top Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-zinc-900/90 border border-yellow-400/50 text-yellow-400 shadow-xl mb-6 animate-slide-up backdrop-blur-md">
          <Flame className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" />
          <span className="text-xs sm:text-sm font-extrabold tracking-wide uppercase">
            Le N°1 de la Restauration Rapide à Martil & Cabo Negro
          </span>
          <Sparkles className="w-4 h-4 text-yellow-400" />
        </div>

        {/* Main Headline */}
        <h1 className="font-heading font-black text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight text-white uppercase leading-none mb-6 animate-slide-up" style={{ animationDelay: '0.15s' }}>
          LE GOÛT INTENSE DU <br className="hidden sm:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-red-500 to-yellow-400 drop-shadow-[0_4px_10px_rgba(220,38,38,0.5)]">
            VRAI FAST FOOD
          </span>
        </h1>

        {/* Dynamic Subtitle from active slide */}
        <p className="max-w-2xl mx-auto text-lg sm:text-xl md:text-2xl text-zinc-300 font-medium mb-10 animate-slide-up leading-relaxed" style={{ animationDelay: '0.3s' }}>
          Découvrez nos <strong className="text-white font-bold">Tacos au gratin fondants</strong>, nos <strong className="text-white font-bold">Smash Burgers juteux</strong> & nos <strong className="text-white font-bold">Pizzas artisanales</strong>. Cuisinés sur commande avec notre célèbre sauce fromagère maison !
        </p>

        {/* Animated Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6 mb-16 animate-slide-up" style={{ animationDelay: '0.45s' }}>
          {/* Commander maintenant Button */}
          <button
            onClick={handleOrderBtn}
            className="w-full sm:w-auto px-8 sm:px-10 py-4 sm:py-5 rounded-full bg-gradient-to-r from-red-600 via-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white font-heading font-black text-lg sm:text-xl uppercase tracking-wider shadow-2xl shadow-red-600/50 hover:shadow-red-600/80 hover:scale-105 active:scale-95 transition-all duration-300 flex items-center justify-center gap-3 border border-red-400/30 group animate-pulse-glow"
          >
            <ShoppingBag className="w-6 h-6 group-hover:rotate-12 transition-transform" />
            <span>Commander Maintenant</span>
          </button>

          {/* Voir le Menu Button */}
          <button
            onClick={scrollToMenu}
            className="w-full sm:w-auto px-8 sm:px-10 py-4 sm:py-5 rounded-full bg-zinc-900/80 hover:bg-white text-white hover:text-zinc-950 font-heading font-bold text-lg sm:text-xl uppercase tracking-wider backdrop-blur-md border-2 border-white/20 hover:border-white hover:scale-105 active:scale-95 transition-all duration-300 flex items-center justify-center gap-3 group shadow-lg"
          >
            <Utensils className="w-6 h-6 text-yellow-400 group-hover:text-red-600 transition-colors" />
            <span>Voir le Menu</span>
          </button>
        </div>

        {/* Quick Stats & Trust Pillars */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-6 max-w-4xl mx-auto pt-8 border-t border-zinc-800/80 animate-slide-up" style={{ animationDelay: '0.6s' }}>
          <div className="bg-zinc-900/60 backdrop-blur-sm p-4 rounded-2xl border border-zinc-800/80 flex items-center gap-3 text-left">
            <div className="p-3 bg-red-600/20 text-red-500 rounded-xl">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <div className="font-heading font-extrabold text-base sm:text-lg text-white">15-20 Min</div>
              <div className="text-xs text-zinc-400">Livraison Rapide Martil</div>
            </div>
          </div>

          <div className="bg-zinc-900/60 backdrop-blur-sm p-4 rounded-2xl border border-zinc-800/80 flex items-center gap-3 text-left">
            <div className="p-3 bg-yellow-400/20 text-yellow-400 rounded-xl">
              <Star className="w-6 h-6 fill-yellow-400" />
            </div>
            <div>
              <div className="font-heading font-extrabold text-base sm:text-lg text-white">4.9 / 5 Note</div>
              <div className="text-xs text-zinc-400">Top Avis Clientèle</div>
            </div>
          </div>

          <div className="col-span-2 md:col-span-1 bg-zinc-900/60 backdrop-blur-sm p-4 rounded-2xl border border-zinc-800/80 flex items-center gap-3 text-left justify-center md:justify-start">
            <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="font-heading font-extrabold text-base sm:text-lg text-white">100% Halal Frais</div>
              <div className="text-xs text-zinc-400">Qualité & Hygiène Garantie</div>
            </div>
          </div>
        </div>

        {/* Slide indicators */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {HERO_IMAGES.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`h-2 rounded-full transition-all duration-300 ${
                i === currentSlide ? 'w-8 bg-red-600' : 'w-2 bg-zinc-600 hover:bg-zinc-400'
              }`}
              aria-label={`Aller au slide ${i + 1}`}
            />
          ))}
        </div>

        {/* Scroll down indicator */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 opacity-70 hover:opacity-100 transition-opacity cursor-pointer" onClick={scrollToMenu}>
          <span className="text-[10px] uppercase tracking-widest text-zinc-400 font-bold">Découvrir la carte</span>
          <ChevronDown className="w-5 h-5 text-red-500 animate-bounce" />
        </div>
      </div>
    </section>
  );
};
